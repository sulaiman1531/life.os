from fastapi import APIRouter, Depends, HTTPException, status, Header
from sqlalchemy.orm import Session
from database import get_db
import models
import schemas
from uuid import UUID

router = APIRouter()

@router.post("/register", response_model=schemas.UserResponse)
def register(user: schemas.UserCreate, db: Session = Depends(get_db)):
    db_user = db.query(models.User).filter(models.User.email == user.email).first()
    if db_user:
        raise HTTPException(status_code=400, detail="Email already registered")
    
    fake_hashed_password = user.password + "notreallyhashed"
    
    new_user = models.User(
        email=user.email, 
        hashed_password=fake_hashed_password, 
        full_name=user.full_name,
        role=user.role
    )
    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    return new_user

@router.post("/login")
def login(user: schemas.UserCreate, db: Session = Depends(get_db)):
    db_user = db.query(models.User).filter(models.User.email == user.email).first()
    if not db_user or db_user.hashed_password != user.password + "notreallyhashed":
        raise HTTPException(status_code=400, detail="Incorrect email or password")
    
    # Return user id as fake token for MVP, and role
    return {
        "access_token": str(db_user.id), 
        "token_type": "bearer",
        "role": db_user.role
    }

def get_current_user(authorization: str = Header(None), db: Session = Depends(get_db)):
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Not authenticated")
    
    token = authorization.split(" ")[1]
    try:
        user_id = UUID(token)
    except ValueError:
        raise HTTPException(status_code=401, detail="Invalid token")
        
    user = db.query(models.User).filter(models.User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
        
    return user

@router.post("/change-password")
def change_password(req: schemas.ChangePasswordRequest, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    if current_user.hashed_password != req.current_password + "notreallyhashed":
        raise HTTPException(status_code=400, detail="Incorrect current password")
    
    current_user.hashed_password = req.new_password + "notreallyhashed"
    db.commit()
    return {"message": "Password updated successfully"}

