from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from uuid import UUID

import models
import schemas
from database import get_db
from routers.auth import get_current_user

router = APIRouter()

@router.get("/", response_model=List[schemas.HabitResponse])
def get_habits(db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    return db.query(models.Habit).filter(models.Habit.user_id == current_user.id).all()

@router.post("/", response_model=schemas.HabitResponse)
def create_habit(habit: schemas.HabitCreate, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    db_habit = models.Habit(**habit.dict(), user_id=current_user.id)
    db.add(db_habit)
    db.commit()
    db.refresh(db_habit)
    return db_habit

@router.post("/{habit_id}/log", response_model=schemas.HabitLogResponse)
def log_habit(habit_id: UUID, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    db_habit = db.query(models.Habit).filter(models.Habit.id == habit_id, models.Habit.user_id == current_user.id).first()
    if not db_habit:
        raise HTTPException(status_code=404, detail="Habit not found")
        
    db_habit.streak += 1
    db_log = models.HabitLog(habit_id=habit_id)
    db.add(db_log)
    db.commit()
    db.refresh(db_log)
    return db_log

@router.delete("/{habit_id}")
def delete_habit(habit_id: UUID, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    db_habit = db.query(models.Habit).filter(models.Habit.id == habit_id, models.Habit.user_id == current_user.id).first()
    if not db_habit:
        raise HTTPException(status_code=404, detail="Habit not found")
        
    db.delete(db_habit)
    db.commit()
    return {"message": "Habit deleted"}
