from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy.orm import Session

import models
from database import get_db
from routers.auth import get_current_user
from ai_engine import process_intent_with_llm

router = APIRouter()

class ChatRequest(BaseModel):
    message: str

class ChatResponse(BaseModel):
    response: str
    action_taken: str | None = None

@router.post("/", response_model=ChatResponse)
def process_chat(request: ChatRequest, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    # Let the Agent autonomously handle everything including DB interactions
    result = process_intent_with_llm(request.message, db, current_user.id)
    
    return ChatResponse(
        response=result.get("response", "I'm here to help!"),
        action_taken=result.get("intent", "agent_action")
    )
