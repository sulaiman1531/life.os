from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import Dict, Any
from uuid import UUID

import models
from database import get_db
from routers.auth import get_current_user

router = APIRouter()

@router.get("/")
def get_settings(db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    return current_user.preferences

@router.put("/")
def update_settings(preferences: Dict[str, Any], db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    current_user.preferences = preferences
    db.commit()
    db.refresh(current_user)
    return current_user.preferences
