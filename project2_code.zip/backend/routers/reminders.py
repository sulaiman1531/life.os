from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from uuid import UUID

import models
import schemas
from database import get_db
from routers.auth import get_current_user

router = APIRouter()

@router.get("/", response_model=List[schemas.ReminderResponse])
def get_reminders(db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    return db.query(models.Reminder).filter(models.Reminder.user_id == current_user.id).all()

@router.post("/", response_model=schemas.ReminderResponse)
def create_reminder(reminder: schemas.ReminderCreate, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    db_reminder = models.Reminder(**reminder.dict(), user_id=current_user.id)
    db.add(db_reminder)
    db.commit()
    db.refresh(db_reminder)
    return db_reminder

@router.put("/{reminder_id}", response_model=schemas.ReminderResponse)
def update_reminder(reminder_id: UUID, reminder: schemas.ReminderUpdate, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    db_reminder = db.query(models.Reminder).filter(models.Reminder.id == reminder_id, models.Reminder.user_id == current_user.id).first()
    if not db_reminder:
        raise HTTPException(status_code=404, detail="Reminder not found")
    
    update_data = reminder.dict(exclude_unset=True)
    for key, value in update_data.items():
        setattr(db_reminder, key, value)
        
    db.commit()
    db.refresh(db_reminder)
    return db_reminder

@router.delete("/{reminder_id}")
def delete_reminder(reminder_id: UUID, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    db_reminder = db.query(models.Reminder).filter(models.Reminder.id == reminder_id, models.Reminder.user_id == current_user.id).first()
    if not db_reminder:
        raise HTTPException(status_code=404, detail="Reminder not found")
        
    db.delete(db_reminder)
    db.commit()
    return {"message": "Reminder deleted"}
