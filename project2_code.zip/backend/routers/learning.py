from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from uuid import UUID

import models
import schemas
from database import get_db
from routers.auth import get_current_user

router = APIRouter()

@router.get("/", response_model=List[schemas.LearningItemResponse])
def get_learning_items(db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    return db.query(models.LearningItem).filter(models.LearningItem.user_id == current_user.id).all()

@router.post("/", response_model=schemas.LearningItemResponse)
def create_learning_item(item: schemas.LearningItemCreate, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    db_item = models.LearningItem(**item.dict(), user_id=current_user.id)
    db.add(db_item)
    db.commit()
    db.refresh(db_item)
    return db_item

@router.put("/{item_id}", response_model=schemas.LearningItemResponse)
def update_learning_item(item_id: UUID, item: schemas.LearningItemUpdate, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    db_item = db.query(models.LearningItem).filter(models.LearningItem.id == item_id, models.LearningItem.user_id == current_user.id).first()
    if not db_item:
        raise HTTPException(status_code=404, detail="Learning item not found")
    
    update_data = item.dict(exclude_unset=True)
    for key, value in update_data.items():
        setattr(db_item, key, value)
        
    db.commit()
    db.refresh(db_item)
    return db_item

@router.delete("/{item_id}")
def delete_learning_item(item_id: UUID, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    db_item = db.query(models.LearningItem).filter(models.LearningItem.id == item_id, models.LearningItem.user_id == current_user.id).first()
    if not db_item:
        raise HTTPException(status_code=404, detail="Learning item not found")
        
    db.delete(db_item)
    db.commit()
    return {"message": "Learning item deleted"}
