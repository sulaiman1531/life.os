from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from uuid import UUID
from database import get_db
import models, schemas
from routers.auth import get_current_user

router = APIRouter()

@router.post("/", response_model=schemas.PlannerBlockResponse)
def create_block(block: schemas.PlannerBlockCreate, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    db_block = models.PlannerBlock(**block.dict(), owner_id=current_user.id)
    db.add(db_block)
    db.commit()
    db.refresh(db_block)
    return db_block

@router.get("/", response_model=List[schemas.PlannerBlockResponse])
def get_blocks(date: str = None, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    query = db.query(models.PlannerBlock).filter(models.PlannerBlock.owner_id == current_user.id)
    if date:
        query = query.filter(models.PlannerBlock.date == date)
    return query.all()
