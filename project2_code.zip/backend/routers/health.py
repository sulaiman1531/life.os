from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from uuid import UUID

import models
import schemas
from database import get_db
from routers.auth import get_current_user

router = APIRouter()

@router.get("/", response_model=List[schemas.HealthLogResponse])
def get_health_logs(db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    return db.query(models.HealthLog).filter(models.HealthLog.user_id == current_user.id).order_by(models.HealthLog.date.desc()).all()

@router.post("/", response_model=schemas.HealthLogResponse)
def create_health_log(log: schemas.HealthLogCreate, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    db_log = models.HealthLog(**log.dict(), user_id=current_user.id)
    db.add(db_log)
    db.commit()
    db.refresh(db_log)
    return db_log

@router.put("/{log_id}", response_model=schemas.HealthLogResponse)
def update_health_log(log_id: UUID, log: schemas.HealthLogUpdate, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    db_log = db.query(models.HealthLog).filter(models.HealthLog.id == log_id, models.HealthLog.user_id == current_user.id).first()
    if not db_log:
        raise HTTPException(status_code=404, detail="Health log not found")
    
    update_data = log.dict(exclude_unset=True)
    for key, value in update_data.items():
        setattr(db_log, key, value)
        
    db.commit()
    db.refresh(db_log)
    return db_log
