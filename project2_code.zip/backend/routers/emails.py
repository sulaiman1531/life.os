from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from database import get_db
import models
from routers.auth import get_current_user
from datetime import datetime, timedelta

router = APIRouter()

# Mock emails for the prototype
MOCK_EMAILS = [
    {
        "id": "1",
        "sender": "Tim Cook <tcook@apple.com>",
        "subject": "Great job on LIFE OS",
        "snippet": "Just wanted to say I love the new interface...",
        "body": "Hi there,\n\nI just saw a demo of your new autonomous LIFE OS platform and I have to say, the design is incredibly sleek. Would love to discuss acquiring it.\n\nBest,\nTim",
        "date": datetime.utcnow().isoformat(),
        "read": False,
    },
    {
        "id": "2",
        "sender": "GitHub <noreply@github.com>",
        "subject": "[GitHub] Your repository was starred",
        "snippet": "Congratulations! Someone starred your repo...",
        "body": "Hi,\n\nYour repository 'life-os' just received another star! Keep up the great open-source work.\n\n- GitHub Team",
        "date": (datetime.utcnow() - timedelta(hours=2)).isoformat(),
        "read": True,
    },
    {
        "id": "3",
        "sender": "Sam Altman <sam@openai.com>",
        "subject": "AGI Timeline",
        "snippet": "Can we accelerate the deployment?",
        "body": "I think we are moving too slowly. Let's schedule a call tomorrow to discuss how LIFE OS fits into our master plan.\n\nThanks,\nSam",
        "date": (datetime.utcnow() - timedelta(days=1)).isoformat(),
        "read": False,
    },
    {
        "id": "4",
        "sender": "Netflix <info@mailer.netflix.com>",
        "subject": "New arrivals this week",
        "snippet": "Check out what's new on Netflix...",
        "body": "Grab your popcorn! We just added some great new sci-fi movies that we think you'll love based on your watch history.",
        "date": (datetime.utcnow() - timedelta(days=2)).isoformat(),
        "read": True,
    }
]

@router.get("/")
def get_emails(current_user: models.User = Depends(get_current_user)):
    return MOCK_EMAILS

@router.put("/{email_id}/read")
def mark_read(email_id: str, current_user: models.User = Depends(get_current_user)):
    for email in MOCK_EMAILS:
        if email["id"] == email_id:
            email["read"] = True
            return email
    return {"error": "Email not found"}

@router.delete("/{email_id}")
def delete_email(email_id: str, current_user: models.User = Depends(get_current_user)):
    global MOCK_EMAILS
    MOCK_EMAILS = [e for e in MOCK_EMAILS if e["id"] != email_id]
    return {"success": True}
