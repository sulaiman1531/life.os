from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from database import get_db
import models
from routers.auth import get_current_user
from datetime import datetime, timedelta
import urllib.request
import json
from pydantic import BaseModel

router = APIRouter()

mock_state = {
    "read_ids": set(),
    "archived_ids": set()
}

class ItemUpdate(BaseModel):
    read: bool = None
    archived: bool = None

def generate_mock_feed(preferences: dict):
    feed = []
    
    # Slack
    if preferences.get("integration_slack", False):
        feed.extend([
            {
                "id": "slack-1",
                "source": "slack",
                "title": "#engineering",
                "snippet": "@here The latest build is deployed to staging. Please test your features.",
                "timestamp": (datetime.utcnow() - timedelta(minutes=15)).isoformat(),
                "read": False,
                "icon_bg": "#4A154B",
                "ai_priority": "FYI"
            },
            {
                "id": "slack-2",
                "source": "slack",
                "title": "Direct Message from Sarah",
                "snippet": "Hey, do you have a minute to review the PR for the new dashboard?",
                "timestamp": (datetime.utcnow() - timedelta(hours=1)).isoformat(),
                "read": True,
                "icon_bg": "#4A154B",
                "ai_priority": "Urgent"
            }
        ])

    # Trello
    if preferences.get("integration_trello", False):
        feed.extend([
            {
                "id": "trello-1",
                "source": "trello",
                "title": "Backend Optimization Board",
                "snippet": "Mike moved card 'Optimize Postgres Queries' to DONE",
                "timestamp": (datetime.utcnow() - timedelta(minutes=45)).isoformat(),
                "read": False,
                "icon_bg": "#0052CC",
                "ai_priority": "Later"
            }
        ])

    # WhatsApp
    if preferences.get("integration_whatsapp", False):
        feed.extend([
            {
                "id": "wa-1",
                "source": "whatsapp",
                "title": "Family Group",
                "snippet": "Mom: Are we still on for dinner tonight?",
                "timestamp": (datetime.utcnow() - timedelta(minutes=5)).isoformat(),
                "read": False,
                "icon_bg": "#25D366",
                "ai_priority": "Urgent"
            }
        ])

    # Gmail
    if preferences.get("integration_gmail", False):
        feed.extend([
            {
                "id": "gmail-1",
                "source": "gmail",
                "title": "Tim Cook <tcook@apple.com>",
                "snippet": "Great job on LIFE OS. Let's discuss acquiring it.",
                "timestamp": (datetime.utcnow() - timedelta(hours=3)).isoformat(),
                "read": False,
                "icon_bg": "#EA4335",
                "ai_priority": "Urgent"
            }
        ])

    # Omni-Integrations Expansion
    feed.extend([
        {
            "id": "github-1",
            "source": "github",
            "title": "Pull Request #420",
            "snippet": "Added Jarvis Voice Commands via Web Speech API.",
            "timestamp": (datetime.utcnow() - timedelta(minutes=30)).isoformat(),
            "read": False,
            "icon_bg": "#24292e",
            "ai_priority": "Later"
        },
        {
            "id": "jira-1",
            "source": "jira",
            "title": "LIFE-902",
            "snippet": "Critical Bug: Unified Workspace filter buttons are unresponsive.",
            "timestamp": (datetime.utcnow() - timedelta(minutes=10)).isoformat(),
            "read": False,
            "icon_bg": "#0052CC",
            "ai_priority": "Urgent"
        },
        {
            "id": "calendar-1",
            "source": "calendar",
            "title": "Upcoming Meeting",
            "snippet": "Investor Pitch with Sequoia Capital starts in 15 minutes.",
            "timestamp": (datetime.utcnow() + timedelta(minutes=15)).isoformat(),
            "read": False,
            "icon_bg": "#4285F4",
            "ai_priority": "Urgent"
        },
        {
            "id": "health-1",
            "source": "health",
            "title": "Burnout Warning",
            "snippet": "Your sleep score was 62%. Heart rate variability is low. Recommend enabling Focus Mode.",
            "timestamp": (datetime.utcnow() - timedelta(hours=4)).isoformat(),
            "read": False,
            "icon_bg": "#FF2D55",
            "ai_priority": "FYI"
        }
    ])

    # Sort by timestamp descending (newest first)
    feed.sort(key=lambda x: x["timestamp"], reverse=True)
    
    # Apply mock state
    processed_feed = []
    for item in feed:
        if item["id"] in mock_state["archived_ids"]:
            continue
        if item["id"] in mock_state["read_ids"]:
            item["read"] = True
        processed_feed.append(item)
        
    return processed_feed

@router.get("/")
def get_workspace_feed(current_user: models.User = Depends(get_current_user)):
    # In a real app, you would fetch real data from webhooks/APIs
    # Here, we generate a mock feed based on which integrations they enabled
    prefs = current_user.preferences or {}
    feed = generate_mock_feed(prefs)
    
    if not feed:
        return []
        
    return feed

@router.put("/{item_id}")
def update_workspace_item(item_id: str, action: ItemUpdate):
    if action.read:
        mock_state["read_ids"].add(item_id)
    if action.archived:
        mock_state["archived_ids"].add(item_id)
    return {"status": "ok"}
