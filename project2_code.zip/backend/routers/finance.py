from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from uuid import UUID
from database import get_db
import models, schemas
from routers.auth import get_current_user

router = APIRouter()

@router.post("/", response_model=schemas.FinanceTransactionResponse)
def create_transaction(transaction: schemas.FinanceTransactionCreate, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    db_transaction = models.FinanceTransaction(**transaction.dict(), owner_id=current_user.id)
    db.add(db_transaction)
    db.commit()
    db.refresh(db_transaction)
    return db_transaction

@router.get("/", response_model=List[schemas.FinanceTransactionResponse])
def get_transactions(db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    return db.query(models.FinanceTransaction).filter(models.FinanceTransaction.owner_id == current_user.id).order_by(models.FinanceTransaction.date.desc()).all()
