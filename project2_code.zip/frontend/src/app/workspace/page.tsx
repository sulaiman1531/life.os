"use client";

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { fetchApi } from "@/lib/api";
import { Search, Inbox, MessageSquare, Layout, Mail, Check, ArrowRight, Loader2, LayoutGrid, Sparkles, Send, GitPullRequest, Calendar, Heart, AlertCircle } from "lucide-react";
import Link from "next/link";

export default function WorkspacePage() {
 const queryClient = useQueryClient();
 const [filter, setFilter] = useState("all");
 const [replyingTo, setReplyingTo] = useState<string | null>(null);
 const [isDrafting, setIsDrafting] = useState(false);
 const [replyText, setReplyText] = useState("");
 const { data: feed = [], isLoading } = useQuery({
 queryKey: ["workspace"],
 queryFn: () => fetchApi("/workspace/"),
 refetchInterval: 5000, // mock real-time polling
 });

 const getSourceIcon = (source: string) => {
 switch(source) {
 case 'slack': return <MessageSquare className="w-4 h-4 text-white" />;
 case 'trello': return <Layout className="w-4 h-4 text-white" />;
 case 'whatsapp': return <MessageSquare className="w-4 h-4 text-white" />;
 case 'gmail': return <Mail className="w-4 h-4 text-white" />;
 case 'github': return <GitPullRequest className="w-4 h-4 text-white" />;
 case 'jira': return <LayoutGrid className="w-4 h-4 text-white" />;
 case 'calendar': return <Calendar className="w-4 h-4 text-white" />;
 case 'health': return <Heart className="w-4 h-4 text-white" />;
 default: return <Inbox className="w-5 h-5 text-white" />;
 }
 };

 const handleDraftReply = (item: any) => {
 setReplyingTo(item.id);
 setIsDrafting(true);
 setReplyText("");
 // Simulate Agentic AI drafting
 setTimeout(() => {
 setReplyText(`Hi there,\n\nThanks for reaching out about this. Let me check my calendar and I will get back to you shortly.\n\nBest,\nAdmin`);
 setIsDrafting(false);
 }, 1500);
 };

 const getSourceLabel = (source: string) => {
 return source.charAt(0).toUpperCase() + source.slice(1);
 };

 const updateItem = useMutation({
 mutationFn: ({ id, action }: { id: string, action: any }) => fetchApi(`/workspace/${id}`, {
 method: "PUT",
 body: JSON.stringify(action)
 }),
 onSuccess: () => queryClient.invalidateQueries({ queryKey: ["workspace"] })
 });

 const filteredFeed = feed.filter((item: any) => filter === "all" || item.source === filter);

 const formatDate = (dateStr: string) => {
 const d = new Date(dateStr);
 const now = new Date();
 const diffMs = now.getTime() - d.getTime();
 const diffMins = Math.floor(diffMs / 60000);
 const diffHrs = Math.floor(diffMins / 60);

 if (diffMins < 60) return `${diffMins}m ago`;
 if (diffHrs < 24) return `${diffHrs}h ago`;
 return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
 };

 if (isLoading) {
 return (
 <div className="flex h-full items-center justify-center">
 <Loader2 className="w-8 h-8 animate-spin text-white/30" />
 </div>
 );
 }

 return (
 <div className="flex flex-col h-full space-y-6 animate-in fade-in duration-500 max-w-5xl mx-auto w-full">
 
 <div className="flex items-center justify-between">
 <div>
 <h1 className="text-3xl font-bold tracking-tight text-white mb-2 flex items-center">
 <LayoutGrid className="w-8 h-8 mr-3 text-pink-400" />
 Unified Workspace
 </h1>
 <p className="text-white/50">Your Omni-Channel Command Center.</p>
 </div>
 <Link href="/settings" className="px-4 py-2 bg-white/5 hover:bg-white/10 text-white rounded-lg transition-colors border border-white/10 text-sm font-medium">
 Manage Integrations
 </Link>
 </div>

 {feed.length === 0 ? (
 <div className="flex-1 glass-card border border-white/10 rounded-2xl flex flex-col items-center justify-center text-center p-12">
 <div className="w-20 h-20 bg-white/5 rounded-full flex items-center justify-center mb-6">
 <LayoutGrid className="w-10 h-10 text-white/20" />
 </div>
 <h3 className="text-xl font-bold text-white mb-2">No active integrations</h3>
 <p className="text-white/50 max-w-md mb-8">
 Your Workspace is empty. Connect Slack, Trello, WhatsApp, and Gmail in Settings to see all your updates flow into a single stream.
 </p>
 <Link href="/settings" className="px-6 py-3 bg-pink-500 hover:bg-pink-600 text-white font-bold rounded-lg transition-colors">
 Connect Apps
 </Link>
 </div>
 ) : (
 <div className="flex-1 glass-card border border-white/10 rounded-2xl overflow-hidden flex flex-col">
 <div className="p-4 border-b border-white/10 flex items-center justify-between bg-white/5">
 <div className="relative w-64">
 <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-white/40" />
 <input 
 type="text"
 placeholder="Search all apps..."
 className="w-full bg-white/5 border border-white/10 rounded-lg pl-9 pr-4 py-2 text-sm text-white placeholder-white/30 focus:outline-none focus:border-pink-500/50 transition-colors"
 />
 </div>
 <div className="flex items-center space-x-2 text-sm text-white/50 font-medium">
 <button 
 onClick={() => setFilter("all")} 
 className={`px-3 py-1.5 rounded transition-colors ${filter === "all" ? "bg-white/10 text-white" : "hover:bg-white/5"}`}
 >All</button>
 <button 
 onClick={() => setFilter("slack")} 
 className={`px-3 py-1.5 rounded transition-colors ${filter === "slack" ? "bg-[#E01E5A]/20 text-[#E01E5A]" : "hover:bg-white/5"}`}
 >Slack</button>
 <button 
 onClick={() => setFilter("whatsapp")} 
 className={`px-3 py-1.5 rounded transition-colors ${filter === "whatsapp" ? "bg-[#25D366]/20 text-[#25D366]" : "hover:bg-white/5"}`}
 >WhatsApp</button>
 <button 
 onClick={() => setFilter("gmail")} 
 className={`px-3 py-1.5 rounded transition-colors ${filter === "gmail" ? "bg-[#EA4335]/20 text-[#EA4335]" : "hover:bg-white/5"}`}
 >Gmail</button>
 <button 
 onClick={() => setFilter("github")} 
 className={`px-3 py-1.5 rounded transition-colors ${filter === "github" ? "bg-[#24292e]/20 text-white" : "hover:bg-white/5"}`}
 >GitHub</button>
 <button 
 onClick={() => setFilter("jira")} 
 className={`px-3 py-1.5 rounded transition-colors ${filter === "jira" ? "bg-[#0052CC]/20 text-[#0052CC]" : "hover:bg-white/5"}`}
 >Jira</button>
 <button 
 onClick={() => setFilter("trello")} 
 className={`px-3 py-1.5 rounded transition-colors ${filter === "trello" ? "bg-[#0079BF]/20 text-[#0079BF]" : "hover:bg-white/5"}`}
 >Trello</button>
 <button 
 onClick={() => setFilter("calendar")} 
 className={`px-3 py-1.5 rounded transition-colors ${filter === "calendar" ? "bg-[#4285F4]/20 text-[#4285F4]" : "hover:bg-white/5"}`}
 >Calendar</button>
 <button 
 onClick={() => setFilter("health")} 
 className={`px-3 py-1.5 rounded transition-colors ${filter === "health" ? "bg-[#FF2D55]/20 text-[#FF2D55]" : "hover:bg-white/5"}`}
 >Health</button>
 </div>
 </div>
 
 <div className="flex-1 overflow-y-auto p-4 space-y-3">
 {filteredFeed.map((item: any) => (
 <div 
 key={item.id} 
 className={`group flex items-start p-4 rounded-xl border transition-all ${!item.read ? 'bg-white/10 border-white/20' : 'bg-white/5 border-white/5'}`}
 >
 <div 
 className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 mt-1 shadow-inner"
 style={{ backgroundColor: item.icon_bg }}
 title={getSourceLabel(item.source)}
 >
 {getSourceIcon(item.source)}
 </div>
 
 <div className="ml-4 flex-1 min-w-0">
 <div className="flex items-start justify-between mb-1">
 <div className="flex flex-col">
 <h4 className={`text-sm mb-1 ${!item.read ? 'font-bold text-white' : 'font-medium text-white/80'}`}>
 {item.title}
 </h4>
 <p className="text-white/60 mb-3 text-sm">{item.snippet}</p>
 <div className="flex items-center space-x-3">
 <span className={`text-[10px] uppercase tracking-wider font-bold px-2 py-1 rounded ${
 item.source === 'slack' ? 'bg-[#E01E5A]/20 text-[#E01E5A]' :
 item.source === 'trello' || item.source === 'jira' ? 'bg-[#0052CC]/20 text-[#0052CC]' :
 item.source === 'whatsapp' ? 'bg-[#25D366]/20 text-[#25D366]' :
 item.source === 'github' ? 'bg-white/20 text-white' :
 item.source === 'calendar' ? 'bg-[#4285F4]/20 text-[#4285F4]' :
 item.source === 'health' ? 'bg-[#FF2D55]/20 text-[#FF2D55]' :
 'bg-[#EA4335]/20 text-[#EA4335]'
 }`}>
 {item.source}
 </span>
 
 {/* AI Priority Badge */}
 {item.ai_priority && (
 <span className={`text-[10px] uppercase tracking-wider font-bold px-2 py-1 rounded border flex items-center ${
 item.ai_priority === 'Urgent' ? 'bg-red-500/10 text-red-400 border-red-500/30' :
 item.ai_priority === 'Later' ? 'bg-orange-500/10 text-orange-400 border-orange-500/30' :
 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
 }`}>
 <Sparkles className="w-3 h-3 mr-1" />
 {item.ai_priority}
 </span>
 )}

 {!item.read && (
 <button 
 onClick={(e) => { e.preventDefault(); updateItem.mutate({ id: item.id, action: { read: true } }); }}
 className="text-xs text-white/40 hover:text-white transition-colors"
 >
 Mark as read
 </button>
 )}
 </div>
 </div>
 
 <div className="flex flex-col space-y-2 ml-4 flex-shrink-0">
 {['slack', 'whatsapp', 'gmail'].includes(item.source) && replyingTo !== item.id && (
 <button 
 onClick={() => handleDraftReply(item)}
 className="bg-white/5 hover:bg-violet-500/20 text-violet-400 border border-violet-500/30 px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center transition-colors"
 >
 <Sparkles className="w-3 h-3 mr-1.5" />
 Draft Reply
 </button>
 )}
 <button 
 onClick={(e) => { e.preventDefault(); updateItem.mutate({ id: item.id, action: { archived: true } }); }}
 className="w-8 h-8 rounded-lg bg-white/5 hover:bg-emerald-500/20 text-white/40 hover:text-emerald-400 border border-white/5 hover:border-emerald-500/30 flex items-center justify-center transition-colors"
 title="Archive/Done"
 >
 <Check className="w-4 h-4" />
 </button>
 </div>
 </div>

 {replyingTo === item.id && (
 <div className="mt-4 p-4 rounded-xl border border-violet-500/30 bg-violet-500/5">
 <div className="flex items-center text-xs font-semibold text-violet-400 mb-2">
 <Sparkles className="w-3 h-3 mr-1" />
 Jarvis is drafting a response...
 </div>
 <div className="relative">
 {isDrafting && (
 <div className="absolute inset-0 bg-[#0A0A0A]/50 backdrop-blur-[1px] flex items-center justify-center rounded-lg z-10 border border-white/10">
 <Loader2 className="w-5 h-5 text-violet-400 animate-spin" />
 </div>
 )}
 <textarea 
 value={replyText}
 onChange={(e) => setReplyText(e.target.value)}
 className="w-full bg-[#0A0A0A] border border-white/10 rounded-lg p-3 text-sm text-white/90 placeholder-white/30 focus:outline-none focus:border-violet-500/50 min-h-[100px] resize-none"
 placeholder="AI is thinking..."
 />
 </div>
 <div className="flex items-center justify-end space-x-2 mt-3">
 <button onClick={() => setReplyingTo(null)} className="px-3 py-1.5 text-xs text-white/40 hover:text-white transition-colors">
 Cancel
 </button>
 <button 
 disabled={isDrafting}
 onClick={() => setReplyingTo(null)}
 className="bg-violet-600 hover:bg-violet-500 disabled:opacity-50 text-white px-4 py-1.5 rounded-lg text-xs font-semibold flex items-center transition-colors"
 >
 <Send className="w-3 h-3 mr-1.5" />
 Send Reply
 </button>
 </div>
 </div>
 )}
 </div>
 </div>
 ))}
 </div>
 </div>
 )}
 </div>
 );
}
