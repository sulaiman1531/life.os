import type { Metadata } from "next";
import localFont from "next/font/local";
import "./globals.css";
import { cn } from "@/lib/utils";

const geistSans = localFont({
 src: "./fonts/GeistVF.woff",
 variable: "--font-geist-sans",
 weight: "100 900",
});
const geistMono = localFont({
 src: "./fonts/GeistMonoVF.woff",
 variable: "--font-geist-mono",
 weight: "100 900",
});

import Providers from "@/components/Providers";
import ProtectedRoute from "@/components/ProtectedRoute";
import CommandPalette from "@/components/CommandPalette";
import Sidebar from "@/components/Sidebar";
import TopBar from "@/components/TopBar";
import NotificationPanel from "@/components/NotificationPanel";
import ShortcutModal from "@/components/ShortcutModal";

export const metadata: Metadata = {
 title: "LIFE OS",
 description: "AI Powered Life Operating System",
 manifest: "/manifest.json",
};

export const viewport = {
 themeColor: "#0A0A0A",
};

export default function RootLayout({
 children,
}: Readonly<{
 children: React.ReactNode;
}>) {
 return (
 <html lang="en" className={cn("font-sans", "dark")}>
 <body className={`${geistSans.variable} ${geistMono.variable} antialiased bg-[#0A0A0A] text-white overflow-hidden`}>
 <Providers>
 <ShortcutModal />
 <ProtectedRoute>
 {children}
 </ProtectedRoute>
 </Providers>
 </body>
 </html>
 );
}
