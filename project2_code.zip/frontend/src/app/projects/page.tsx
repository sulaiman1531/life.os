"use client";

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { fetchApi } from "@/lib/api";
import { FolderOpen, Plus, X, MoreVertical, Layers } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function ProjectsPage() {
 const queryClient = useQueryClient();
 const [isModalOpen, setIsModalOpen] = useState(false);
 const [name, setName] = useState("");
 const [description, setDescription] = useState("");

 const { data: projects = [] } = useQuery({
 queryKey: ["projects"],
 queryFn: () => fetchApi("/projects/"),
 });

 const addProject = useMutation({
 mutationFn: (newProj: any) => fetchApi("/projects/", {
 method: "POST",
 body: JSON.stringify(newProj)
 }),
 onSuccess: () => {
 queryClient.invalidateQueries({ queryKey: ["projects"] });
 setIsModalOpen(false);
 setName("");
 setDescription("");
 },
 });

 const handleAddSubmit = (e: React.FormEvent) => {
 e.preventDefault();
 if (name.trim()) {
 addProject.mutate({ name, description, status: "active", progress: 0 });
 }
 };

 return (
 <div className="flex flex-col h-full space-y-8 animate-in fade-in duration-500 relative">
 
 {/* Project Modal */}
 <AnimatePresence>
 {isModalOpen && (
 <motion.div 
 initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
 className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4"
 >
 <motion.div 
 initial={{ scale: 0.95, opacity: 0, y: 20 }} animate={{ scale: 1, opacity: 1, y: 0 }} exit={{ scale: 0.95, opacity: 0, y: 20 }}
 className="w-full max-w-md bg-[#0A0A0A] border border-white/10 rounded-2xl p-6 shadow-2xl relative overflow-hidden"
 >
 <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/10 rounded-full blur-3xl"></div>
 
 <div className="flex justify-between items-center mb-6 relative z-10">
 <h3 className="text-xl font-bold flex items-center">
 <FolderOpen className="w-5 h-5 text-blue-500 mr-2" />
 New Project
 </h3>
 <button onClick={() => setIsModalOpen(false)} className="text-white/40 hover:text-white transition-colors">
 <X className="w-5 h-5" />
 </button>
 </div>

 <form onSubmit={handleAddSubmit} className="relative z-10 space-y-4">
 <div>
 <input 
 type="text" autoFocus required
 placeholder="Project name..."
 className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-white/30 focus:outline-none focus:border-blue-500/50 transition-colors"
 value={name}
 onChange={(e) => setName(e.target.value)}
 />
 </div>
 <div>
 <textarea 
 placeholder="Brief description..."
 className="w-full h-24 bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-white/30 focus:outline-none focus:border-blue-500/50 transition-colors resize-none"
 value={description}
 onChange={(e) => setDescription(e.target.value)}
 />
 </div>
 <button 
 type="submit" 
 disabled={addProject.isPending}
 className="w-full bg-blue-600 hover:bg-blue-500 text-white font-semibold py-3 rounded-xl transition-colors mt-2"
 >
 {addProject.isPending ? "Creating..." : "Create Project"}
 </button>
 </form>
 </motion.div>
 </motion.div>
 )}
 </AnimatePresence>

 <div className="flex justify-between items-end">
 <div>
 <h1 className="text-3xl font-bold tracking-tight text-white mb-2">Projects</h1>
 <p className="text-white/50">High-level initiatives and milestones.</p>
 </div>
 <button onClick={() => setIsModalOpen(true)} className="flex items-center space-x-2 text-sm text-blue-400 bg-blue-500/10 hover:bg-blue-500/20 px-4 py-2 rounded-xl border border-blue-500/20 transition-colors">
 <Plus className="w-4 h-4" /> <span>New Project</span>
 </button>
 </div>

 {projects.length === 0 ? (
 <div className="flex-1 flex flex-col items-center justify-center border border-white/5 border-dashed rounded-2xl mt-8 opacity-50">
 <Layers className="w-16 h-16 text-white/20 mb-4" />
 <p className="text-lg font-medium text-white/60">No active projects</p>
 <p className="text-sm text-white/40 mt-1">Create one to start tracking large initiatives.</p>
 </div>
 ) : (
 <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
 {projects.map((p: any) => (
 <div key={p.id} className="glass-card border border-white/10 rounded-2xl p-6 group hover:border-blue-500/30 transition-all cursor-pointer relative overflow-hidden">
 <div className="absolute top-0 right-0 w-24 h-24 bg-blue-500/5 rounded-full blur-2xl group-hover:bg-blue-500/10 transition-all"></div>
 <div className="flex justify-between items-start mb-4">
 <div className="w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center">
 <FolderOpen className="w-5 h-5 text-blue-400" />
 </div>
 <button className="text-white/30 hover:text-white"><MoreVertical className="w-4 h-4" /></button>
 </div>
 <h3 className="text-lg font-bold text-white mb-1">{p.name}</h3>
 <p className="text-xs text-white/40 mb-6 line-clamp-2 h-8">{p.description || "No description provided."}</p>
 
 <div className="space-y-2">
 <div className="flex justify-between text-xs text-white/60">
 <span>Progress</span>
 <span>{p.progress}%</span>
 </div>
 <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden">
 <div className="h-full bg-blue-500 rounded-full" style={{ width: `${p.progress}%` }}></div>
 </div>
 </div>
 </div>
 ))}
 </div>
 )}

 </div>
 );
}
