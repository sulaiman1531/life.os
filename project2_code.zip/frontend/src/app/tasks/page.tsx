"use client";

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { fetchApi } from "@/lib/api";
import { CheckSquare, Plus, Clock, AlertCircle, X, Check, ArrowRightCircle } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function TasksPage() {
 const queryClient = useQueryClient();
 const [isModalOpen, setIsModalOpen] = useState(false);
 const [title, setTitle] = useState("");
 const [priority, setPriority] = useState("medium");
 const [description, setDescription] = useState("");

 const { data: tasks = [] } = useQuery({
 queryKey: ["tasks"],
 queryFn: () => fetchApi("/tasks/"),
 });

 const addTask = useMutation({
 mutationFn: (newTask: any) => fetchApi("/tasks/", {
 method: "POST",
 body: JSON.stringify(newTask)
 }),
 onSuccess: () => {
 queryClient.invalidateQueries({ queryKey: ["tasks"] });
 setIsModalOpen(false);
 setTitle("");
 setDescription("");
 },
 });

 const completeTask = useMutation({
 mutationFn: (taskId: string) => fetchApi(`/tasks/${taskId}`, {
 method: "PUT",
 body: JSON.stringify({ status: "done" })
 }),
 onSuccess: () => queryClient.invalidateQueries({ queryKey: ["tasks"] }),
 });

 const updateTaskStatus = useMutation({
 mutationFn: ({ taskId, status }: { taskId: string; status: string }) => fetchApi(`/tasks/${taskId}`, {
 method: "PUT",
 body: JSON.stringify({ status })
 }),
 onSuccess: () => queryClient.invalidateQueries({ queryKey: ["tasks"] }),
 });

 const handleDragStart = (e: React.DragEvent, taskId: string) => {
 e.dataTransfer.setData("taskId", taskId);
 };

 const handleDrop = (e: React.DragEvent, status: string) => {
 e.preventDefault();
 const taskId = e.dataTransfer.getData("taskId");
 if (taskId) {
 updateTaskStatus.mutate({ taskId, status });
 }
 };

 const handleDragOver = (e: React.DragEvent) => {
 e.preventDefault();
 };

 const handleAddSubmit = (e: React.FormEvent) => {
 e.preventDefault();
 if (title.trim()) {
 addTask.mutate({ title, description, priority, status: "todo" });
 }
 };

 const todo = tasks.filter((t: any) => t.status === "todo" || !t.status);
 const inProgress = tasks.filter((t: any) => t.status === "in_progress");
 const done = tasks.filter((t: any) => t.status === "done" || t.completed); // handle old completed schema

 return (
 <div className="flex flex-col h-full space-y-8 animate-in fade-in duration-500 relative">
 
 {/* Task Modal */}
 <AnimatePresence>
 {isModalOpen && (
 <motion.div 
 initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
 className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4"
 >
 <motion.div 
 initial={{ scale: 0.95, opacity: 0, y: 20 }} animate={{ scale: 1, opacity: 1, y: 0 }} exit={{ scale: 0.95, opacity: 0, y: 20 }}
 className="w-full max-w-md bg-[#0A0A0A] border border-white/10 rounded-2xl p-6 shadow-2xl relative overflow-hidden"
 >
 <div className="absolute top-0 right-0 w-32 h-32 bg-violet-500/10 rounded-full blur-3xl"></div>
 
 <div className="flex justify-between items-center mb-6 relative z-10">
 <h3 className="text-xl font-bold flex items-center">
 <CheckSquare className="w-5 h-5 text-violet-500 mr-2" />
 New Task
 </h3>
 <button onClick={() => setIsModalOpen(false)} className="text-white/40 hover:text-white transition-colors">
 <X className="w-5 h-5" />
 </button>
 </div>

 <form onSubmit={handleAddSubmit} className="relative z-10 space-y-4">
 <div>
 <input 
 type="text" autoFocus required
 placeholder="Task title..."
 className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-white/30 focus:outline-none focus:border-violet-500/50 transition-colors"
 value={title}
 onChange={(e) => setTitle(e.target.value)}
 />
 </div>
 <div>
 <textarea 
 placeholder="Description (optional)..."
 className="w-full h-24 bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-white/30 focus:outline-none focus:border-violet-500/50 transition-colors resize-none"
 value={description}
 onChange={(e) => setDescription(e.target.value)}
 />
 </div>
 <div>
 <select 
 className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-violet-500/50 transition-colors appearance-none"
 value={priority}
 onChange={(e) => setPriority(e.target.value)}
 >
 <option value="low" className="bg-black">Low Priority</option>
 <option value="medium" className="bg-black">Medium Priority</option>
 <option value="high" className="bg-black">High Priority</option>
 </select>
 </div>
 <button 
 type="submit" 
 disabled={addTask.isPending}
 className="w-full bg-violet-600 hover:bg-violet-500 text-white font-semibold py-3 rounded-xl transition-colors mt-2"
 >
 {addTask.isPending ? "Adding..." : "Add Task"}
 </button>
 </form>
 </motion.div>
 </motion.div>
 )}
 </AnimatePresence>

 <div className="flex justify-between items-end">
 <div>
 <h1 className="text-3xl font-bold tracking-tight text-white mb-2">Master Task List</h1>
 <p className="text-white/50">Manage your action items.</p>
 </div>
 <button onClick={() => setIsModalOpen(true)} className="flex items-center space-x-2 text-sm text-violet-400 bg-violet-500/10 hover:bg-violet-500/20 px-4 py-2 rounded-xl border border-violet-500/20 transition-colors">
 <Plus className="w-4 h-4" /> <span>New Task</span>
 </button>
 </div>

 <div className="grid grid-cols-1 md:grid-cols-3 gap-6 h-full">
 
 {/* To Do Column */}
 <div 
 className="flex flex-col bg-white/[0.02] border border-white/5 rounded-2xl p-5 relative h-[600px] overflow-hidden transition-colors hover:bg-white/[0.03]"
 onDrop={(e) => handleDrop(e, "todo")}
 onDragOver={handleDragOver}
 >
 <div className="flex items-center justify-between mb-6">
 <h3 className="font-semibold text-white/80 flex items-center">
 <AlertCircle className="w-4 h-4 mr-2 text-amber-500" />
 To Do
 </h3>
 <span className="bg-white/10 text-white/60 px-2 py-0.5 rounded text-xs font-bold">{todo.length}</span>
 </div>
 
 <div className="flex-1 overflow-y-auto space-y-3 scrollbar-none pr-2">
 {todo.length === 0 && <p className="text-sm text-white/30 text-center mt-10">You're all caught up!</p>}
 {todo.map((task: any) => (
 <div 
 key={task.id} 
 draggable
 onDragStart={(e) => handleDragStart(e, task.id)}
 className="glass-card p-4 rounded-xl border border-white/10 hover:border-violet-500/30 transition-colors cursor-grab active:cursor-grabbing group flex items-start justify-between"
 >
 <div>
 <h4 className="font-medium text-white text-sm">{task.title}</h4>
 {task.description && <p className="text-xs text-white/50 mt-1 line-clamp-2">{task.description}</p>}
 <div className="flex items-center space-x-3 mt-3">
 <span className={`text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded border ${
 task.priority === 'high' ? 'bg-red-500/20 text-red-400 border-red-500/30' :
 task.priority === 'medium' ? 'bg-amber-500/20 text-amber-400 border-amber-500/30' :
 'bg-white/10 text-white/50 border-white/10'
 }`}>
 {task.priority || "Medium"}
 </span>
 </div>
 </div>
 </div>
 ))}
 </div>
 </div>

 {/* In Progress Column */}
 <div 
 className="flex flex-col bg-white/[0.02] border border-white/5 rounded-2xl p-5 relative h-[600px] overflow-hidden transition-colors hover:bg-white/[0.03]"
 onDrop={(e) => handleDrop(e, "in_progress")}
 onDragOver={handleDragOver}
 >
 <div className="flex items-center justify-between mb-6">
 <h3 className="font-semibold text-white/80 flex items-center">
 <ArrowRightCircle className="w-4 h-4 mr-2 text-blue-500" />
 In Progress
 </h3>
 <span className="bg-white/10 text-white/60 px-2 py-0.5 rounded text-xs font-bold">{inProgress.length}</span>
 </div>
 
 <div className="flex-1 overflow-y-auto space-y-3 scrollbar-none pr-2">
 {inProgress.length === 0 && <p className="text-sm text-white/30 text-center mt-10">Drag tasks here to start working.</p>}
 {inProgress.map((task: any) => (
 <div 
 key={task.id} 
 draggable
 onDragStart={(e) => handleDragStart(e, task.id)}
 className="glass-card p-4 rounded-xl border border-blue-500/30 bg-blue-500/5 hover:border-blue-500/50 transition-colors cursor-grab active:cursor-grabbing group flex items-start justify-between relative overflow-hidden"
 >
 <div className="absolute top-0 left-0 w-1 h-full bg-blue-500"></div>
 <div className="pl-2">
 <h4 className="font-medium text-white text-sm">{task.title}</h4>
 {task.description && <p className="text-xs text-white/50 mt-1 line-clamp-2">{task.description}</p>}
 <div className="flex items-center space-x-3 mt-3">
 <span className={`text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded border ${
 task.priority === 'high' ? 'bg-red-500/20 text-red-400 border-red-500/30' :
 task.priority === 'medium' ? 'bg-amber-500/20 text-amber-400 border-amber-500/30' :
 'bg-white/10 text-white/50 border-white/10'
 }`}>
 {task.priority || "Medium"}
 </span>
 </div>
 </div>
 </div>
 ))}
 </div>
 </div>

 {/* Done Column */}
 <div 
 className="flex flex-col bg-white/[0.02] border border-white/5 rounded-2xl p-5 relative h-[600px] overflow-hidden transition-colors hover:bg-white/[0.03]"
 onDrop={(e) => handleDrop(e, "done")}
 onDragOver={handleDragOver}
 >
 <div className="flex items-center justify-between mb-6">
 <h3 className="font-semibold text-white/80 flex items-center">
 <CheckSquare className="w-4 h-4 mr-2 text-emerald-500" />
 Done
 </h3>
 <span className="bg-white/10 text-white/60 px-2 py-0.5 rounded text-xs font-bold">{done.length}</span>
 </div>
 
 <div className="flex-1 overflow-y-auto space-y-3 scrollbar-none pr-2 opacity-60">
 {done.length === 0 && <p className="text-sm text-white/30 text-center mt-10">No completed tasks yet.</p>}
 {done.map((task: any) => (
 <div 
 key={task.id} 
 draggable
 onDragStart={(e) => handleDragStart(e, task.id)}
 className="glass-card p-4 rounded-xl border border-emerald-500/10 bg-emerald-500/5 hover:border-emerald-500/30 transition-colors cursor-grab active:cursor-grabbing flex items-center justify-between"
 >
 <div>
 <h4 className="font-medium text-white/80 line-through text-sm">{task.title}</h4>
 </div>
 <Check className="w-4 h-4 text-emerald-500" />
 </div>
 ))}
 </div>
 </div>

 </div>
 </div>
 );
}
