"use client";

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { fetchApi } from "@/lib/api";
import { motion } from "framer-motion";
import { Settings as SettingsIcon, Bell, Volume2, Moon, Palette, Shield, Key, Loader2, Check, MessageSquare, Layout, Mail, LayoutGrid, Sparkles, Wand2 } from "lucide-react";

export default function SettingsPage() {
 const queryClient = useQueryClient();
 const [currentPassword, setCurrentPassword] = useState("");
 const [newPassword, setNewPassword] = useState("");
 const [confirmPassword, setConfirmPassword] = useState("");
 const [passwordError, setPasswordError] = useState("");
 const [passwordSuccess, setPasswordSuccess] = useState(false);
 
 // Magic Connect State
 const [isScanning, setIsScanning] = useState(false);
 const [scanComplete, setScanComplete] = useState(false);
 const [otpSent, setOtpSent] = useState(false);
 const [otpValue, setOtpValue] = useState("");
 const [magicConnected, setMagicConnected] = useState(false);
 
 const { data: preferences = {} } = useQuery({
 queryKey: ["settings"],
 queryFn: () => fetchApi("/settings/"),
 });

 const updateSettings = useMutation({
 mutationFn: (newPrefs: any) => fetchApi("/settings/", {
 method: "PUT",
 body: JSON.stringify(newPrefs)
 }),
 onSuccess: () => queryClient.invalidateQueries({ queryKey: ["settings"] }),
 });

 const changePassword = useMutation({
 mutationFn: (data: any) => fetchApi("/auth/change-password", {
 method: "POST",
 body: JSON.stringify(data)
 }),
 onSuccess: () => {
 setPasswordSuccess(true);
 setCurrentPassword("");
 setNewPassword("");
 setConfirmPassword("");
 setPasswordError("");
 setTimeout(() => setPasswordSuccess(false), 3000);
 },
 onError: (error: any) => {
 setPasswordError(error.message || "Failed to change password");
 }
 });

 const handlePasswordSubmit = (e: React.FormEvent) => {
 e.preventDefault();
 setPasswordError("");
 setPasswordSuccess(false);

 if (newPassword !== confirmPassword) {
 setPasswordError("New passwords do not match.");
 return;
 }

 if (newPassword.length < 6) {
 setPasswordError("Password must be at least 6 characters.");
 return;
 }

 changePassword.mutate({ current_password: currentPassword, new_password: newPassword });
 };

 const handleToggle = (key: string) => {
 const current = preferences[key] ?? true; // default true if undefined
 updateSettings.mutate({ ...preferences, [key]: !current });
 };

 return (
 <div className="flex flex-col h-full space-y-8 animate-in fade-in duration-500 max-w-4xl mx-auto w-full">
 
 <div>
 <h1 className="text-3xl font-bold tracking-tight text-white mb-2">Settings</h1>
 <p className="text-white/50">Manage your application preferences.</p>
 </div>

 <div className="space-y-6">
 
 {/* Notifications */}
 <div className="glass-card border border-white/10 rounded-2xl p-6">
 <h2 className="text-lg font-bold text-white mb-6 flex items-center">
 <Bell className="w-5 h-5 mr-2 text-violet-400" />
 Notifications
 </h2>
 
 <div className="space-y-4">
 <div className="flex items-center justify-between p-4 bg-white/5 rounded-xl border border-white/5">
 <div>
 <h4 className="text-white font-medium">Push Notifications</h4>
 <p className="text-xs text-white/50 mt-0.5">Allow LIFE OS to send you reminders via browser push.</p>
 </div>
 <button 
 onClick={() => handleToggle("push_notifications")}
 className={`w-12 h-6 rounded-full transition-colors relative ${preferences.push_notifications !== false ? 'bg-violet-500' : 'bg-white/10'}`}
 >
 <div className={`absolute top-1 left-1 bg-white w-4 h-4 rounded-full transition-transform ${preferences.push_notifications !== false ? 'translate-x-6' : ''}`}></div>
 </button>
 </div>

 <div className="flex items-center justify-between p-4 bg-white/5 rounded-xl border border-white/5">
 <div>
 <h4 className="text-white font-medium flex items-center"><Volume2 className="w-4 h-4 mr-2"/> UI Sounds</h4>
 <p className="text-xs text-white/50 mt-0.5">Play sounds when completing tasks and receiving notifications.</p>
 </div>
 <button 
 onClick={() => handleToggle("ui_sounds")}
 className={`w-12 h-6 rounded-full transition-colors relative ${preferences.ui_sounds !== false ? 'bg-violet-500' : 'bg-white/10'}`}
 >
 <div className={`absolute top-1 left-1 bg-white w-4 h-4 rounded-full transition-transform ${preferences.ui_sounds !== false ? 'translate-x-6' : ''}`}></div>
 </button>
 </div>
 </div>
 </div>

 {/* Magic Connect / Workspace Integrations */}
 <div className="glass-card border border-white/10 rounded-2xl p-6 relative overflow-hidden">
 <div className="absolute top-0 right-0 -mr-12 -mt-12 w-48 h-48 bg-fuchsia-500/10 rounded-full blur-3xl pointer-events-none"></div>
 
 <h2 className="text-lg font-bold text-white mb-2 flex items-center">
 <Wand2 className="w-5 h-5 mr-2 text-fuchsia-400" />
 Magic Connect (Auto-Discovery)
 </h2>
 <p className="text-sm text-white/50 mb-6">We securely scan your email domain to find apps your team already uses.</p>
 
 {!scanComplete && !isScanning && (
 <button 
 onClick={() => {
 setIsScanning(true);
 setTimeout(() => {
 setIsScanning(false);
 setScanComplete(true);
 }, 2500);
 }}
 className="bg-white/5 hover:bg-white/10 border border-white/10 text-white font-medium py-3 px-6 rounded-xl transition-all flex items-center justify-center w-full sm:w-auto"
 >
 <Sparkles className="w-4 h-4 mr-2 text-fuchsia-400" />
 Scan my email for apps
 </button>
 )}

 {isScanning && (
 <div className="flex flex-col items-center justify-center py-8">
 <Loader2 className="w-8 h-8 text-fuchsia-400 animate-spin mb-4" />
 <p className="text-sm text-white/70 animate-pulse">Scanning admin@lifeos.com domain...</p>
 </div>
 )}

 {scanComplete && !magicConnected && (
 <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="bg-black/30 border border-fuchsia-500/20 rounded-xl p-5">
 <h3 className="text-white font-medium mb-2 flex items-center">
 <Check className="w-4 h-4 mr-2 text-emerald-400" />
 Found 4 matching accounts!
 </h3>
 <div className="flex space-x-3 mb-6 mt-4">
 <div className="w-8 h-8 rounded bg-[#4A154B] flex items-center justify-center"><MessageSquare className="w-4 h-4 text-white" /></div>
 <div className="w-8 h-8 rounded bg-[#24292e] flex items-center justify-center"><LayoutGrid className="w-4 h-4 text-white" /></div>
 <div className="w-8 h-8 rounded bg-[#0052CC] flex items-center justify-center"><Layout className="w-4 h-4 text-white" /></div>
 <div className="w-8 h-8 rounded bg-[#EA4335] flex items-center justify-center"><Mail className="w-4 h-4 text-white" /></div>
 </div>

 {!otpSent ? (
 <button 
 onClick={() => setOtpSent(true)}
 className="bg-fuchsia-600 hover:bg-fuchsia-500 text-white font-medium py-2 px-4 rounded-lg transition-colors text-sm"
 >
 Send OTP to connect all
 </button>
 ) : (
 <div className="flex items-center space-x-3">
 <input 
 type="text" 
 placeholder="Enter 6-digit OTP"
 value={otpValue}
 onChange={(e) => setOtpValue(e.target.value)}
 className="bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-fuchsia-500/50"
 />
 <button 
 onClick={() => {
 setMagicConnected(true);
 updateSettings.mutate({ 
 ...preferences, 
 integration_slack: true,
 integration_trello: true,
 integration_whatsapp: true,
 integration_gmail: true
 });
 }}
 className="bg-emerald-600 hover:bg-emerald-500 text-white font-medium py-2 px-4 rounded-lg transition-colors text-sm"
 >
 Verify & Connect
 </button>
 </div>
 )}
 </motion.div>
 )}

 {magicConnected && (
 <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="bg-emerald-500/10 border border-emerald-500/20 rounded-xl p-5 flex items-center text-emerald-400">
 <Check className="w-5 h-5 mr-3" />
 <div>
 <h4 className="font-medium">All accounts synced successfully</h4>
 <p className="text-xs text-emerald-400/70 mt-1">Slack, GitHub, Jira, and Gmail are now piping into your OS.</p>
 </div>
 </motion.div>
 )}

 </div>

 {/* Appearance */}
 <div className="glass-card border border-white/10 rounded-2xl p-6">
 <h2 className="text-lg font-bold text-white mb-6 flex items-center">
 <Palette className="w-5 h-5 mr-2 text-blue-400" />
 Appearance
 </h2>
 
 <div className="space-y-4">
 <div className="flex items-center justify-between p-4 bg-white/5 rounded-xl border border-white/5">
 <div>
 <h4 className="text-white font-medium flex items-center"><Moon className="w-4 h-4 mr-2"/> Dark Mode</h4>
 <p className="text-xs text-white/50 mt-0.5">LIFE OS currently only supports true black dark mode for optimal focus.</p>
 </div>
 <button disabled className="w-12 h-6 rounded-full bg-blue-500 relative opacity-50 cursor-not-allowed">
 <div className="absolute top-1 left-1 bg-white w-4 h-4 rounded-full translate-x-6"></div>
 </button>
 </div>
 </div>
 </div>
 
 {/* Account */}
 <div className="glass-card border border-white/10 rounded-2xl p-6">
 <h2 className="text-lg font-bold text-white mb-6 flex items-center">
 <Shield className="w-5 h-5 mr-2 text-emerald-400" />
 Account
 </h2>
 <div className="p-4 bg-white/5 rounded-xl border border-white/5 mb-4">
 <h4 className="text-white font-medium">Logged in as</h4>
 <p className="text-sm text-white/70 mt-1 font-mono">admin@lifeos.com</p>
 </div>

 <div className="pt-4 border-t border-white/10">
 <h3 className="text-md font-semibold text-white mb-4 flex items-center">
 <Key className="w-4 h-4 mr-2 text-white/50" />
 Change Password
 </h3>
 
 <form onSubmit={handlePasswordSubmit} className="space-y-4 max-w-sm">
 <div>
 <input 
 type="password" 
 placeholder="Current Password" 
 required
 value={currentPassword}
 onChange={e => setCurrentPassword(e.target.value)}
 className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder-white/30 focus:outline-none focus:border-violet-500/50"
 />
 </div>
 <div>
 <input 
 type="password" 
 placeholder="New Password" 
 required
 value={newPassword}
 onChange={e => setNewPassword(e.target.value)}
 className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder-white/30 focus:outline-none focus:border-violet-500/50"
 />
 </div>
 <div>
 <input 
 type="password" 
 placeholder="Confirm New Password" 
 required
 value={confirmPassword}
 onChange={e => setConfirmPassword(e.target.value)}
 className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder-white/30 focus:outline-none focus:border-violet-500/50"
 />
 </div>
 
 {passwordError && <p className="text-xs text-red-400">{passwordError}</p>}
 {passwordSuccess && <p className="text-xs text-emerald-400 flex items-center"><Check className="w-3 h-3 mr-1"/> Password updated successfully</p>}
 
 <button 
 type="submit" 
 disabled={changePassword.isPending}
 className="w-full bg-white/10 hover:bg-white/20 text-white font-medium py-2 rounded-lg transition-colors flex items-center justify-center text-sm"
 >
 {changePassword.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : "Update Password"}
 </button>
 </form>
 </div>
 </div>

 </div>

 </div>
 );
}
