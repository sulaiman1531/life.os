"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Zap, Plus, ArrowRight, Save, Layout, MessageSquare, Calendar, GitPullRequest, BrainCircuit, Target, Check, Trash2, Webhook } from "lucide-react";

type Rule = {
 id: string;
 triggerApp: string;
 triggerEvent: string;
 actionApp: string;
 actionEvent: string;
 active: boolean;
};

const defaultRules: Rule[] = [
 {
 id: "1",
 triggerApp: "jira",
 triggerEvent: "High Priority Ticket Assigned",
 actionApp: "slack",
 actionEvent: "Draft message to Manager",
 active: true,
 },
 {
 id: "2",
 triggerApp: "system",
 triggerEvent: "Deep Work Mode Activated",
 actionApp: "slack",
 actionEvent: "Set status to 'In Deep Work 🔴'",
 active: true,
 }
];

const apps = [
 { id: "jira", name: "Jira", icon: <Layout className="w-4 h-4" />, color: "#0052CC" },
 { id: "slack", name: "Slack", icon: <MessageSquare className="w-4 h-4" />, color: "#E01E5A" },
 { id: "calendar", name: "Calendar", icon: <Calendar className="w-4 h-4" />, color: "#4285F4" },
 { id: "github", name: "GitHub", icon: <GitPullRequest className="w-4 h-4" />, color: "#24292e" },
 { id: "system", name: "Life OS", icon: <Target className="w-4 h-4" />, color: "#8b5cf6" },
];

export default function AutomationsPage() {
 const [rules, setRules] = useState<Rule[]>(defaultRules);
 const [isBuilding, setIsBuilding] = useState(false);
 
 // New Rule State
 const [triggerApp, setTriggerApp] = useState("jira");
 const [triggerEvent, setTriggerEvent] = useState("");
 const [actionApp, setActionApp] = useState("slack");
 const [actionEvent, setActionEvent] = useState("");

 const toggleRule = (id: string) => {
 setRules(rules.map(r => r.id === id ? { ...r, active: !r.active } : r));
 };

 const deleteRule = (id: string) => {
 setRules(rules.filter(r => r.id !== id));
 };

 const handleSaveRule = () => {
 if (!triggerEvent || !actionEvent) return;
 
 const newRule: Rule = {
 id: Date.now().toString(),
 triggerApp,
 triggerEvent,
 actionApp,
 actionEvent,
 active: true
 };
 
 setRules([...rules, newRule]);
 setIsBuilding(false);
 setTriggerEvent("");
 setActionEvent("");
 };

 const getAppColor = (appId: string) => apps.find(a => a.id === appId)?.color || "#333";
 const getAppIcon = (appId: string) => apps.find(a => a.id === appId)?.icon || <Webhook className="w-4 h-4" />;
 const getAppName = (appId: string) => apps.find(a => a.id === appId)?.name || "App";

 return (
 <div className="flex flex-col h-full space-y-8 animate-in fade-in duration-500 max-w-5xl mx-auto w-full">
 
 <div className="flex justify-between items-end">
 <div>
 <h1 className="text-3xl font-bold tracking-tight text-white mb-2 flex items-center">
 <Zap className="w-6 h-6 mr-3 text-amber-400" />
 AI Automations
 </h1>
 <p className="text-white/50">Build intelligent rules to let Jarvis handle your busywork.</p>
 </div>
 
 {!isBuilding && (
 <button 
 onClick={() => setIsBuilding(true)}
 className="bg-white text-black hover:bg-white/90 px-4 py-2 rounded-lg text-sm font-medium transition-colors flex items-center"
 >
 <Plus className="w-4 h-4 mr-2" />
 New Automation
 </button>
 )}
 </div>

 <AnimatePresence mode="wait">
 {isBuilding && (
 <motion.div 
 initial={{ opacity: 0, height: 0, scale: 0.95 }}
 animate={{ opacity: 1, height: "auto", scale: 1 }}
 exit={{ opacity: 0, height: 0, scale: 0.95 }}
 className="glass-card border border-amber-500/30 rounded-2xl p-6 relative overflow-hidden"
 >
 <div className="absolute top-0 right-0 w-64 h-64 bg-amber-500/10 rounded-full blur-[80px] pointer-events-none"></div>
 
 <div className="flex items-center justify-between mb-6 relative z-10">
 <h2 className="text-lg font-bold text-white flex items-center">
 <BrainCircuit className="w-5 h-5 mr-2 text-amber-400" />
 Rule Builder
 </h2>
 <button onClick={() => setIsBuilding(false)} className="p-2 text-white/50 hover:text-white rounded-full hover:bg-white/5">
 <X className="w-5 h-5" />
 </button>
 </div>

 <div className="grid grid-cols-1 md:grid-cols-5 gap-4 items-center relative z-10">
 {/* Trigger */}
 <div className="md:col-span-2 bg-black/40 border border-white/10 p-5 rounded-xl">
 <div className="text-xs font-bold text-white/40 uppercase tracking-wider mb-4">IF THIS HAPPENS</div>
 <select 
 value={triggerApp}
 onChange={(e) => setTriggerApp(e.target.value)}
 className="w-full bg-white/5 border border-white/10 rounded-lg p-3 text-sm text-white focus:outline-none focus:border-amber-500/50 mb-3"
 >
 {apps.map(app => (
 <option key={app.id} value={app.id} className="bg-[#121212]">{app.name}</option>
 ))}
 </select>
 <input 
 type="text" 
 placeholder="e.g. High Priority Ticket Assigned"
 value={triggerEvent}
 onChange={(e) => setTriggerEvent(e.target.value)}
 className="w-full bg-white/5 border border-white/10 rounded-lg p-3 text-sm text-white focus:outline-none focus:border-amber-500/50"
 />
 </div>

 {/* Arrow */}
 <div className="md:col-span-1 flex justify-center py-4">
 <div className="w-12 h-12 rounded-full bg-amber-500/10 border border-amber-500/20 flex items-center justify-center">
 <ArrowRight className="w-5 h-5 text-amber-400" />
 </div>
 </div>

 {/* Action */}
 <div className="md:col-span-2 bg-black/40 border border-white/10 p-5 rounded-xl">
 <div className="text-xs font-bold text-white/40 uppercase tracking-wider mb-4">THEN DO THIS</div>
 <select 
 value={actionApp}
 onChange={(e) => setActionApp(e.target.value)}
 className="w-full bg-white/5 border border-white/10 rounded-lg p-3 text-sm text-white focus:outline-none focus:border-amber-500/50 mb-3"
 >
 {apps.map(app => (
 <option key={app.id} value={app.id} className="bg-[#121212]">{app.name}</option>
 ))}
 </select>
 <input 
 type="text" 
 placeholder="e.g. Draft Slack message to Manager"
 value={actionEvent}
 onChange={(e) => setActionEvent(e.target.value)}
 className="w-full bg-white/5 border border-white/10 rounded-lg p-3 text-sm text-white focus:outline-none focus:border-amber-500/50"
 />
 </div>
 </div>

 <div className="mt-6 flex justify-end relative z-10">
 <button 
 onClick={handleSaveRule}
 disabled={!triggerEvent || !actionEvent}
 className="bg-amber-500 hover:bg-amber-400 disabled:opacity-50 disabled:cursor-not-allowed text-black font-bold py-2 px-6 rounded-lg transition-colors flex items-center"
 >
 <Save className="w-4 h-4 mr-2" />
 Save Automation
 </button>
 </div>
 </motion.div>
 )}
 </AnimatePresence>

 <div className="space-y-4">
 {rules.map((rule) => (
 <motion.div 
 key={rule.id}
 initial={{ opacity: 0, y: 10 }}
 animate={{ opacity: 1, y: 0 }}
 className={`glass-card p-5 rounded-xl border transition-all ${rule.active ? 'border-white/10' : 'border-white/5 opacity-60'}`}
 >
 <div className="flex items-center justify-between">
 
 <div className="flex items-center space-x-6 flex-1">
 {/* Trigger Side */}
 <div className="flex items-center space-x-3 w-5/12">
 <div className="w-10 h-10 rounded-lg flex items-center justify-center shadow-lg" style={{ backgroundColor: getAppColor(rule.triggerApp) }}>
 {getAppIcon(rule.triggerApp)}
 </div>
 <div>
 <span className="text-[10px] uppercase font-bold tracking-wider text-white/40 block mb-0.5">IF {getAppName(rule.triggerApp)}</span>
 <span className={`text-sm font-medium ${rule.active ? 'text-white' : 'text-white/50'}`}>{rule.triggerEvent}</span>
 </div>
 </div>

 {/* Arrow */}
 <div className="w-1/12 flex justify-center">
 <ArrowRight className={`w-4 h-4 ${rule.active ? 'text-amber-400' : 'text-white/20'}`} />
 </div>

 {/* Action Side */}
 <div className="flex items-center space-x-3 w-5/12">
 <div className="w-10 h-10 rounded-lg flex items-center justify-center shadow-lg" style={{ backgroundColor: getAppColor(rule.actionApp) }}>
 {getAppIcon(rule.actionApp)}
 </div>
 <div>
 <span className="text-[10px] uppercase font-bold tracking-wider text-white/40 block mb-0.5">THEN {getAppName(rule.actionApp)}</span>
 <span className={`text-sm font-medium ${rule.active ? 'text-white' : 'text-white/50'}`}>{rule.actionEvent}</span>
 </div>
 </div>
 </div>

 {/* Controls */}
 <div className="flex items-center space-x-4 ml-6 pl-6 border-l border-white/5">
 <button 
 onClick={() => toggleRule(rule.id)}
 className={`w-12 h-6 rounded-full transition-colors relative ${rule.active ? 'bg-amber-500' : 'bg-white/10'}`}
 >
 <div className={`absolute top-1 left-1 bg-white w-4 h-4 rounded-full transition-transform ${rule.active ? 'translate-x-6' : ''}`}></div>
 </button>
 <button 
 onClick={() => deleteRule(rule.id)}
 className="p-2 text-white/30 hover:text-red-400 transition-colors rounded-lg hover:bg-white/5"
 >
 <Trash2 className="w-4 h-4" />
 </button>
 </div>

 </div>
 </motion.div>
 ))}
 
 {rules.length === 0 && !isBuilding && (
 <div className="text-center py-16 border border-dashed border-white/10 rounded-2xl bg-white/[0.02]">
 <Webhook className="w-12 h-12 mx-auto text-white/20 mb-4" />
 <h3 className="text-white font-medium mb-1">No automations found</h3>
 <p className="text-white/40 text-sm mb-6">Create your first rule to let AI handle your busywork.</p>
 <button 
 onClick={() => setIsBuilding(true)}
 className="bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-lg text-sm transition-colors"
 >
 Create Automation
 </button>
 </div>
 )}
 </div>

 </div>
 );
}
