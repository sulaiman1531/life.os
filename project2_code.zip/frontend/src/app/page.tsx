"use client";

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { fetchApi } from "@/lib/api";
import { Clock, Plus, Activity, Calendar as CalIcon, TrendingUp, CheckSquare, Check, X, LayoutGrid, MessageSquare, Layout, Mail } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import Link from "next/link";
import ActivityHeatmap from "@/components/ActivityHeatmap";

const container = {
 hidden: { opacity: 0 },
 show: { opacity: 1, transition: { staggerChildren: 0.1, delayChildren: 0.1 } }
};

const item = {
 hidden: { opacity: 0, y: 20 },
 show: { opacity: 1, y: 0, transition: { type: "spring", stiffness: 300, damping: 24 } }
};

export default function Dashboard() {
 const queryClient = useQueryClient();
 const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
 const [newTaskTitle, setNewTaskTitle] = useState("");
 const [newTaskPriority, setNewTaskPriority] = useState("normal");

 const { data: tasks = [] } = useQuery({
 queryKey: ["tasks"],
 queryFn: () => fetchApi("/tasks/"),
 });

 const { data: workspaceFeed = [] } = useQuery({
 queryKey: ["workspace"],
 queryFn: () => fetchApi("/workspace/"),
 refetchInterval: 5000,
 });

 const getSourceIcon = (source: string) => {
 switch(source) {
 case 'slack': return <MessageSquare className="w-3 h-3 text-white" />;
 case 'trello': return <Layout className="w-3 h-3 text-white" />;
 case 'whatsapp': return <MessageSquare className="w-3 h-3 text-white" />;
 case 'gmail': return <Mail className="w-3 h-3 text-white" />;
 default: return <LayoutGrid className="w-3 h-3 text-white" />;
 }
 };

 const { data: preferences = {} } = useQuery({
 queryKey: ["settings"],
 queryFn: () => fetchApi("/settings/"),
 });

 const updateSettings = useMutation({
 mutationFn: (newPrefs: any) => fetchApi("/settings/", {
 method: "PUT",
 body: JSON.stringify(newPrefs)
 }),
 onSuccess: () => queryClient.invalidateQueries({ queryKey: ["settings"] }),
 });

 const [showXP, setShowXP] = useState(false);

 const toggleTask = useMutation({
 mutationFn: (task: any) => fetchApi(`/tasks/${task.id}`, {
 method: "PUT",
 body: JSON.stringify({ ...task, completed: !task.completed })
 }),
 onSuccess: (data, variables) => {
 queryClient.invalidateQueries({ queryKey: ["tasks"] });
 }
 });

 const addTask = useMutation({
 mutationFn: (task: any) => fetchApi("/tasks/", {
 method: "POST",
 body: JSON.stringify(task)
 }),
 onSuccess: () => {
 queryClient.invalidateQueries({ queryKey: ["tasks"] });
 setIsTaskModalOpen(false);
 setNewTaskTitle("");
 },
 });

 const handleManualTaskSubmit = (e: React.FormEvent) => {
 e.preventDefault();
 if (newTaskTitle.trim()) {
 addTask.mutate({ title: newTaskTitle, priority: newTaskPriority, status: "todo" });
 }
 };

 const pendingTasks = tasks.filter((t: any) => t.status === "todo" || t.status === "in_progress" || !t.status);
 const completedToday = tasks.filter((t: any) => t.status === "done").length; // naive implementation for demo

 return (
 <motion.div variants={container} initial="hidden" animate="show" className="flex flex-col space-y-8 relative">
 
 {/* Manual Task Modal */}
 <AnimatePresence>
 {isTaskModalOpen && (
 <motion.div 
 initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
 className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4"
 >
 <motion.div 
 initial={{ scale: 0.95, opacity: 0, y: 20 }} animate={{ scale: 1, opacity: 1, y: 0 }} exit={{ scale: 0.95, opacity: 0, y: 20 }}
 className="w-full max-w-md bg-[#0A0A0A] border border-white/10 rounded-2xl p-6 shadow-2xl relative overflow-hidden"
 >
 <div className="absolute top-0 right-0 w-32 h-32 bg-violet-500/10 rounded-full blur-3xl"></div>
 
 <div className="flex justify-between items-center mb-6 relative z-10">
 <h3 className="text-xl font-bold">Add Manual Task</h3>
 <button onClick={() => setIsTaskModalOpen(false)} className="text-white/40 hover:text-white transition-colors">
 <X className="w-5 h-5" />
 </button>
 </div>

 <form onSubmit={handleManualTaskSubmit} className="relative z-10 space-y-4">
 <div>
 <input 
 type="text" autoFocus required
 placeholder="Task title..."
 className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-white/30 focus:outline-none focus:border-violet-500/50 transition-colors"
 value={newTaskTitle}
 onChange={(e) => setNewTaskTitle(e.target.value)}
 />
 </div>
 <div>
 <select 
 className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-violet-500/50 transition-colors appearance-none"
 value={newTaskPriority}
 onChange={(e) => setNewTaskPriority(e.target.value)}
 >
 <option value="normal" className="bg-black">Normal Priority</option>
 <option value="high" className="bg-black">High Priority</option>
 <option value="low" className="bg-black">Low Priority</option>
 </select>
 </div>
 <button 
 type="submit" 
 disabled={addTask.isPending}
 className="w-full bg-violet-600 hover:bg-violet-500 text-white font-semibold py-3 rounded-xl transition-colors"
 >
 {addTask.isPending ? "Adding..." : "Add Task"}
 </button>
 </form>
 </motion.div>
 </motion.div>
 )}
 </AnimatePresence>

 {/* Header */}
 <motion.div variants={item} className="flex justify-between items-end">
 <div>
 <h1 className="text-3xl font-bold tracking-tight text-white mb-1">Overview</h1>
 <p className="text-white/50">Your personal intelligence command center.</p>
 </div>
 <div className="flex items-center space-x-3 text-sm text-white/50">
 <Clock className="w-4 h-4" />
 <span>{new Date().toLocaleDateString("en-US", { weekday: 'long', month: 'long', day: 'numeric' })}</span>
 </div>
 </motion.div>

 {/* Bento Grid */}
 <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
 
 {/* Metric Cards Row */}
 <div className="col-span-1 md:col-span-3 grid grid-cols-1 md:grid-cols-3 gap-6">
 <motion.div variants={item} className="glass-card p-6 border border-white/10 relative overflow-hidden group hover:border-violet-500/50 transition-colors">
 <div className="absolute top-0 right-0 -mr-8 -mt-8 w-32 h-32 bg-violet-500/10 rounded-full blur-2xl group-hover:bg-violet-500/20 transition-all"></div>
 <div className="flex items-center space-x-3 text-violet-400 mb-4">
 <Activity className="w-5 h-5" />
 <h3 className="font-semibold text-sm">Active Tasks</h3>
 </div>
 <p className="text-4xl font-bold text-white">{pendingTasks.length}</p>
 <p className="text-xs text-white/40 mt-2">+{completedToday} completed today</p>
 </motion.div>
 
 <motion.div variants={item} className="col-span-1 md:col-span-2">
 <ActivityHeatmap tasks={tasks} />
 </motion.div>
 </div>

 {/* Pending Action Items (2 Columns) */}
 <motion.div variants={item} className="col-span-1 md:col-span-2 glass-card border border-white/10 p-6 flex flex-col h-[500px]">
 <div className="flex items-center justify-between mb-6">
 <div className="flex items-center space-x-4">
 <h2 className="font-semibold text-lg text-white">Pending Action Items</h2>
 </div>
 <button onClick={() => setIsTaskModalOpen(true)} className="text-xs text-violet-400 hover:text-violet-300 transition-colors flex items-center space-x-1">
 <Plus className="w-3 h-3" />
 <span>Add Manual</span>
 </button>
 </div>
 <div className="flex-1 overflow-y-auto space-y-3 pr-2 scrollbar-none">
 {pendingTasks.length === 0 ? (
 <div className="h-full flex flex-col items-center justify-center text-white/30 text-sm">
 <CheckSquare className="w-10 h-10 mb-3 opacity-50" />
 <p>No tasks yet. Ask Jarvis to add one.</p>
 </div>
 ) : (
 pendingTasks.map((task: any) => (
 <div key={task.id} className="flex items-center justify-between p-4 rounded-xl bg-white/5 hover:bg-white/10 border border-white/5 transition-all group">
 <div className="flex items-center space-x-4">
 <button onClick={() => toggleTask.mutate(task)} className="w-5 h-5 rounded border border-white/20 group-hover:border-violet-500 cursor-pointer flex items-center justify-center transition-colors hover:bg-violet-500/20">
 <Check className="w-3 h-3 opacity-0 group-hover:opacity-100 text-violet-400 transition-opacity" />
 </button>
 <div>
 <p className="text-sm font-medium text-white">{task.title}</p>
 <p className="text-xs text-white/40">Created {new Date(task.created_at).toLocaleDateString()}</p>
 </div>
 </div>
 <div className={`px-2 py-1 rounded text-[10px] font-bold uppercase tracking-wider ${
 task.priority === 'high' ? 'bg-red-500/20 text-red-400 border border-red-500/30' :
 task.priority === 'medium' ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' :
 'bg-white/10 text-white/50 border border-white/10'
 }`}>
 {task.priority || "Normal"}
 </div>
 </div>
 ))
 )}
 </div>
 </motion.div>

 {/* Live Integrations Feed Widget (1 Column) */}
 <motion.div variants={item} className="col-span-1 md:col-span-1 glass-card border border-white/10 flex flex-col h-[500px] overflow-hidden">
 <div className="p-4 border-b border-white/10 bg-white/5 flex items-center justify-between">
 <h2 className="font-semibold text-sm text-white flex items-center">
 <LayoutGrid className="w-4 h-4 mr-2 text-pink-400" />
 Live Feed
 </h2>
 <Link href="/workspace" className="text-[10px] text-white/50 hover:text-white transition-colors uppercase tracking-widest font-bold">
 View All
 </Link>
 </div>
 
 <div className="flex-1 overflow-y-auto p-3 space-y-2 scrollbar-none">
 {workspaceFeed.length === 0 ? (
 <div className="h-full flex flex-col items-center justify-center text-white/30 text-xs text-center px-4">
 <LayoutGrid className="w-8 h-8 mb-3 opacity-50" />
 <p>No active integrations. Connect apps in Settings.</p>
 </div>
 ) : (
 workspaceFeed.slice(0, 6).map((item: any) => (
 <div key={item.id} className="p-3 rounded-lg bg-white/5 border border-white/5 hover:border-white/10 transition-colors">
 <div className="flex items-center space-x-2 mb-1.5">
 <div 
 className="w-5 h-5 rounded flex items-center justify-center shadow-inner"
 style={{ backgroundColor: item.icon_bg }}
 >
 {getSourceIcon(item.source)}
 </div>
 <span className="text-xs font-bold text-white/80 truncate">{item.title}</span>
 </div>
 <p className="text-xs text-white/60 line-clamp-2">{item.snippet}</p>
 </div>
 ))
 )}
 </div>
 </motion.div>

 </div>
 </motion.div>
 );
}
