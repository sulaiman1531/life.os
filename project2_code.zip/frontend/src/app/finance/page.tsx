"use client";

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { fetchApi } from "@/lib/api";
import { DollarSign, TrendingUp, ArrowUpRight, ArrowDownRight, Wallet, CreditCard, Plus, X } from "lucide-react";
import { Area, AreaChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { motion, AnimatePresence } from "framer-motion";

const mockData = [
 { name: "Mon", balance: 4000 },
 { name: "Tue", balance: 4500 },
 { name: "Wed", balance: 4200 },
 { name: "Thu", balance: 5100 },
 { name: "Fri", balance: 4800 },
 { name: "Sat", balance: 5800 },
 { name: "Sun", balance: 6200 },
];

export default function FinancePage() {
 const queryClient = useQueryClient();
 const [isModalOpen, setIsModalOpen] = useState(false);
 const [txTitle, setTxTitle] = useState("");
 const [txAmount, setTxAmount] = useState("");
 const [txType, setTxType] = useState("out");

 const { data: transactions = [] } = useQuery({
 queryKey: ["finance"],
 queryFn: () => fetchApi("/finance/"),
 });

 const addTransaction = useMutation({
 mutationFn: (newTx: any) => fetchApi("/finance/", {
 method: "POST",
 body: JSON.stringify(newTx)
 }),
 onSuccess: () => {
 queryClient.invalidateQueries({ queryKey: ["finance"] });
 setIsModalOpen(false);
 setTxTitle("");
 setTxAmount("");
 },
 });

 const handleTxSubmit = (e: React.FormEvent) => {
 e.preventDefault();
 if (txTitle && txAmount) {
 addTransaction.mutate({
 title: txTitle,
 amount: parseFloat(txAmount),
 type: txType
 });
 }
 };

 const currentBalance = 6200.00 + transactions.reduce((acc: number, tx: any) => tx.type === 'in' ? acc + tx.amount : acc - tx.amount, 0);

 return (
 <div className="flex flex-col h-full space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700 relative">
 
 {/* Transaction Modal */}
 <AnimatePresence>
 {isModalOpen && (
 <motion.div 
 initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
 className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4"
 >
 <motion.div 
 initial={{ scale: 0.95, opacity: 0, y: 20 }} animate={{ scale: 1, opacity: 1, y: 0 }} exit={{ scale: 0.95, opacity: 0, y: 20 }}
 className="w-full max-w-md bg-[#0A0A0A] border border-white/10 rounded-2xl p-6 shadow-2xl relative overflow-hidden"
 >
 <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full blur-3xl"></div>
 
 <div className="flex justify-between items-center mb-6 relative z-10">
 <h3 className="text-xl font-bold flex items-center">
 <DollarSign className="w-5 h-5 text-emerald-500 mr-2" />
 New Transaction
 </h3>
 <button onClick={() => setIsModalOpen(false)} className="text-white/40 hover:text-white transition-colors">
 <X className="w-5 h-5" />
 </button>
 </div>

 <form onSubmit={handleTxSubmit} className="relative z-10 space-y-4">
 <div>
 <input 
 type="text" autoFocus required
 placeholder="e.g., Grocery Store"
 className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-white/30 focus:outline-none focus:border-emerald-500/50 transition-colors"
 value={txTitle}
 onChange={(e) => setTxTitle(e.target.value)}
 />
 </div>
 <div className="flex space-x-4">
 <div className="flex-1">
 <input 
 type="number" step="0.01" required
 placeholder="Amount ($)"
 className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-white/30 focus:outline-none focus:border-emerald-500/50 transition-colors"
 value={txAmount}
 onChange={(e) => setTxAmount(e.target.value)}
 />
 </div>
 <div className="flex-1">
 <select 
 className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-emerald-500/50 transition-colors appearance-none"
 value={txType}
 onChange={(e) => setTxType(e.target.value)}
 >
 <option value="out" className="bg-black">Expense (-)</option>
 <option value="in" className="bg-black">Income (+)</option>
 </select>
 </div>
 </div>
 <button 
 type="submit" 
 disabled={addTransaction.isPending}
 className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-semibold py-3 rounded-xl transition-colors mt-2"
 >
 {addTransaction.isPending ? "Logging..." : "Log Transaction"}
 </button>
 </form>
 </motion.div>
 </motion.div>
 )}
 </AnimatePresence>

 <div className="flex justify-between items-end">
 <div>
 <h1 className="text-3xl font-bold tracking-tight text-white mb-2">Net Worth</h1>
 <div className="flex items-center space-x-3">
 <span className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-teal-400">
 ${currentBalance.toFixed(2)}
 </span>
 <span className="flex items-center text-xs font-semibold text-emerald-400 bg-emerald-400/10 px-2 py-1 rounded-full border border-emerald-400/20">
 <TrendingUp className="w-3 h-3 mr-1" />
 +12.5%
 </span>
 </div>
 </div>
 </div>

 {/* Main Chart Area */}
 <div className="glass-card border border-white/10 h-80 rounded-2xl p-6 relative overflow-hidden group">
 <div className="absolute top-0 right-0 -mr-16 -mt-16 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl opacity-50"></div>
 <ResponsiveContainer width="100%" height="100%">
 <AreaChart data={mockData} margin={{ top: 10, right: 0, left: 0, bottom: 0 }}>
 <defs>
 <linearGradient id="colorBalance" x1="0" y1="0" x2="0" y2="1">
 <stop offset="5%" stopColor="#34d399" stopOpacity={0.3} />
 <stop offset="95%" stopColor="#34d399" stopOpacity={0} />
 </linearGradient>
 </defs>
 <XAxis dataKey="name" stroke="#ffffff30" fontSize={12} tickLine={false} axisLine={false} />
 <YAxis hide />
 <Tooltip 
 contentStyle={{ backgroundColor: '#0A0A0A', borderColor: '#ffffff20', borderRadius: '8px' }}
 itemStyle={{ color: '#34d399' }}
 />
 <Area 
 type="monotone" 
 dataKey="balance" 
 stroke="#34d399" 
 strokeWidth={3}
 fillOpacity={1} 
 fill="url(#colorBalance)" 
 />
 </AreaChart>
 </ResponsiveContainer>
 </div>

 {/* Grid */}
 <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
 
 {/* Recent Transactions */}
 <div className="glass-card border border-white/10 rounded-2xl p-6">
 <div className="flex items-center justify-between mb-6">
 <h2 className="text-lg font-semibold flex items-center">
 <CreditCard className="w-5 h-5 mr-2 text-white/50" />
 Recent Transactions
 </h2>
 <button onClick={() => setIsModalOpen(true)} className="p-1.5 bg-white/5 hover:bg-white/10 rounded-md transition-colors"><Plus className="w-4 h-4 text-white/50" /></button>
 </div>
 <div className="space-y-4 max-h-60 overflow-y-auto scrollbar-none pr-2">
 {transactions.length === 0 && <p className="text-sm text-white/40">No recent transactions.</p>}
 {transactions.map((tx: any) => (
 <div key={tx.id} className="flex items-center justify-between p-3 rounded-xl bg-white/5 hover:bg-white/10 transition-colors">
 <div className="flex items-center space-x-4">
 <div className={`p-2 rounded-full ${tx.type === 'in' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'}`}>
 {tx.type === 'in' ? <ArrowDownRight className="w-4 h-4" /> : <ArrowUpRight className="w-4 h-4" />}
 </div>
 <div>
 <p className="text-sm font-medium">{tx.title}</p>
 <p className="text-xs text-white/40">{new Date(tx.date).toLocaleDateString()}</p>
 </div>
 </div>
 <span className={`text-sm font-bold ${tx.type === 'in' ? 'text-emerald-400' : 'text-white'}`}>
 {tx.type === 'in' ? '+' : '-'}${tx.amount.toFixed(2)}
 </span>
 </div>
 ))}
 </div>
 </div>

 {/* Assets & Goals */}
 <div className="glass-card border border-white/10 rounded-2xl p-6">
 <h2 className="text-lg font-semibold mb-6 flex items-center">
 <Wallet className="w-5 h-5 mr-2 text-white/50" />
 Accounts
 </h2>
 <div className="space-y-4">
 <div className="p-4 rounded-xl bg-gradient-to-r from-blue-900/40 to-indigo-900/40 border border-blue-500/20 flex justify-between items-center">
 <div>
 <p className="text-sm text-blue-200">Checking •••• 4092</p>
 <p className="text-2xl font-bold text-white mt-1">${(4850.20 + (currentBalance - 6200)).toFixed(2)}</p>
 </div>
 <div className="w-10 h-6 bg-white/20 rounded-md"></div>
 </div>
 
 <div className="p-4 rounded-xl bg-gradient-to-r from-orange-900/40 to-rose-900/40 border border-orange-500/20 flex justify-between items-center">
 <div>
 <p className="text-sm text-orange-200">Savings •••• 1198</p>
 <p className="text-2xl font-bold text-white mt-1">$12,000.00</p>
 </div>
 <div className="w-10 h-6 bg-white/20 rounded-md"></div>
 </div>
 </div>
 </div>
 </div>

 </div>
 );
}
