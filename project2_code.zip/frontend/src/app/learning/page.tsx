"use client";

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { fetchApi } from "@/lib/api";
import { GraduationCap, Plus, X, Book, Video, Globe } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function LearningPage() {
 const queryClient = useQueryClient();
 const [isModalOpen, setIsModalOpen] = useState(false);
 const [title, setTitle] = useState("");
 const [type, setType] = useState("course");
 const [url, setUrl] = useState("");

 const { data: items = [] } = useQuery({
 queryKey: ["learning_items"],
 queryFn: () => fetchApi("/learning/"),
 });

 const addItem = useMutation({
 mutationFn: (newItem: any) => fetchApi("/learning/", {
 method: "POST",
 body: JSON.stringify(newItem)
 }),
 onSuccess: () => {
 queryClient.invalidateQueries({ queryKey: ["learning_items"] });
 setIsModalOpen(false);
 setTitle("");
 setUrl("");
 },
 });

 const handleAddSubmit = (e: React.FormEvent) => {
 e.preventDefault();
 if (title.trim()) {
 addItem.mutate({ 
 title, 
 type, 
 url,
 status: "in_progress",
 progress: 0 
 });
 }
 };

 return (
 <div className="flex flex-col h-full space-y-8 animate-in fade-in duration-500 relative">
 
 <AnimatePresence>
 {isModalOpen && (
 <motion.div 
 initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
 className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4"
 >
 <motion.div 
 initial={{ scale: 0.95, opacity: 0, y: 20 }} animate={{ scale: 1, opacity: 1, y: 0 }} exit={{ scale: 0.95, opacity: 0, y: 20 }}
 className="w-full max-w-md bg-[#0A0A0A] border border-white/10 rounded-2xl p-6 shadow-2xl relative overflow-hidden"
 >
 <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/10 rounded-full blur-3xl"></div>
 
 <div className="flex justify-between items-center mb-6 relative z-10">
 <h3 className="text-xl font-bold flex items-center">
 <GraduationCap className="w-5 h-5 text-amber-500 mr-2" />
 New Resource
 </h3>
 <button onClick={() => setIsModalOpen(false)} className="text-white/40 hover:text-white transition-colors">
 <X className="w-5 h-5" />
 </button>
 </div>

 <form onSubmit={handleAddSubmit} className="relative z-10 space-y-4">
 <div>
 <input 
 type="text" autoFocus required
 placeholder="Book or course title..."
 className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-white/30 focus:outline-none focus:border-amber-500/50 transition-colors"
 value={title}
 onChange={(e) => setTitle(e.target.value)}
 />
 </div>
 <div>
 <select 
 className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-amber-500/50 transition-colors appearance-none"
 value={type}
 onChange={(e) => setType(e.target.value)}
 >
 <option value="course" className="bg-black">Course</option>
 <option value="book" className="bg-black">Book</option>
 <option value="article" className="bg-black">Article</option>
 </select>
 </div>
 <div>
 <input 
 type="url"
 placeholder="Link (optional)..."
 className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-white/30 focus:outline-none focus:border-amber-500/50 transition-colors"
 value={url}
 onChange={(e) => setUrl(e.target.value)}
 />
 </div>
 <button 
 type="submit" 
 disabled={addItem.isPending}
 className="w-full bg-amber-600 hover:bg-amber-500 text-white font-semibold py-3 rounded-xl transition-colors mt-2"
 >
 {addItem.isPending ? "Adding..." : "Add Resource"}
 </button>
 </form>
 </motion.div>
 </motion.div>
 )}
 </AnimatePresence>

 <div className="flex justify-between items-end">
 <div>
 <h1 className="text-3xl font-bold tracking-tight text-white mb-2">Learning</h1>
 <p className="text-white/50">Books, courses, and knowledge capture.</p>
 </div>
 <button onClick={() => setIsModalOpen(true)} className="flex items-center space-x-2 text-sm text-amber-400 bg-amber-500/10 hover:bg-amber-500/20 px-4 py-2 rounded-xl border border-amber-500/20 transition-colors">
 <Plus className="w-4 h-4" /> <span>Add Resource</span>
 </button>
 </div>

 {items.length === 0 ? (
 <div className="flex-1 flex flex-col items-center justify-center border border-white/5 border-dashed rounded-2xl mt-8 opacity-50">
 <Book className="w-16 h-16 text-white/20 mb-4" />
 <p className="text-lg font-medium text-white/60">No learning resources</p>
 <p className="text-sm text-white/40 mt-1">Add a book or course to start tracking.</p>
 </div>
 ) : (
 <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
 {items.map((item: any) => (
 <div key={item.id} className="glass-card border border-white/10 rounded-2xl p-6 group hover:border-amber-500/30 transition-all cursor-pointer relative overflow-hidden">
 <div className="absolute top-0 right-0 w-24 h-24 bg-amber-500/5 rounded-full blur-2xl group-hover:bg-amber-500/10 transition-all"></div>
 <div className="flex justify-between items-start mb-4">
 <div className="w-10 h-10 rounded-xl bg-amber-500/10 flex items-center justify-center">
 {item.type === 'book' ? <Book className="w-5 h-5 text-amber-400" /> : 
 item.type === 'course' ? <Video className="w-5 h-5 text-amber-400" /> : 
 <Globe className="w-5 h-5 text-amber-400" />}
 </div>
 <span className="text-[10px] uppercase font-bold text-amber-400 bg-amber-500/10 px-2 py-1 rounded-md border border-amber-500/20">
 {item.type}
 </span>
 </div>
 <h3 className="text-lg font-bold text-white mb-6 line-clamp-2 h-14">{item.title}</h3>
 
 <div className="space-y-2">
 <div className="flex justify-between text-xs text-white/60">
 <span>Progress</span>
 <span>{item.progress}%</span>
 </div>
 <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden">
 <div className="h-full bg-amber-500 rounded-full" style={{ width: `${item.progress}%` }}></div>
 </div>
 </div>
 {item.url && (
 <a href={item.url} target="_blank" rel="noopener noreferrer" className="mt-4 block text-xs text-amber-400 hover:underline">
 Open link &rarr;
 </a>
 )}
 </div>
 ))}
 </div>
 )}

 </div>
 );
}
