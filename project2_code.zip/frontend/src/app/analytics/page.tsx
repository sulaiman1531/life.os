"use client";

import { motion } from "framer-motion";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area, BarChart, Bar, Cell } from "recharts";
import { Activity, Zap, Clock, BrainCircuit, Target, Flame } from "lucide-react";

// Mock data for the charts
const productivityData = [
 { name: "Mon", tasks: 4, focus: 2 },
 { name: "Tue", tasks: 7, focus: 4 },
 { name: "Wed", tasks: 5, focus: 3 },
 { name: "Thu", tasks: 12, focus: 6 },
 { name: "Fri", tasks: 8, focus: 4 },
 { name: "Sat", tasks: 2, focus: 1 },
 { name: "Sun", tasks: 3, focus: 2 },
];

const timeDistribution = [
 { name: "Deep Work", value: 60, color: "#8b5cf6" }, // Violet
 { name: "Meetings", value: 20, color: "#f43f5e" }, // Rose
 { name: "Admin/Email", value: 15, color: "#3b82f6" },// Blue
 { name: "Breaks", value: 5, color: "#10b981" }, // Emerald
];

const container = {
 hidden: { opacity: 0 },
 show: { opacity: 1, transition: { staggerChildren: 0.1 } }
};

const item = {
 hidden: { opacity: 0, y: 20 },
 show: { opacity: 1, y: 0, transition: { type: "spring", stiffness: 300, damping: 24 } }
};

export default function AnalyticsPage() {
 const burnoutRisk = 24; // percentage

 return (
 <motion.div variants={container} initial="hidden" animate="show" className="flex flex-col space-y-8">
 
 {/* Header */}
 <motion.div variants={item} className="flex justify-between items-end">
 <div>
 <h1 className="text-3xl font-bold tracking-tight text-white mb-1">Life Analytics</h1>
 <p className="text-white/50">Your personal productivity quantified.</p>
 </div>
 </motion.div>

 {/* Top Metrics Row */}
 <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
 <motion.div variants={item} className="glass-card p-6 border border-white/10 relative overflow-hidden group">
 <div className="absolute top-0 right-0 -mr-4 -mt-4 w-24 h-24 bg-violet-500/10 rounded-full blur-xl"></div>
 <div className="flex items-center space-x-3 text-violet-400 mb-2">
 <Zap className="w-5 h-5" />
 <h3 className="font-semibold text-sm">Productivity Score</h3>
 </div>
 <p className="text-4xl font-bold text-white">87<span className="text-lg text-white/40">/100</span></p>
 <p className="text-xs text-emerald-400 mt-2 flex items-center">
 <TrendingUpIcon className="w-3 h-3 mr-1" /> +12% vs last week
 </p>
 </motion.div>

 <motion.div variants={item} className="glass-card p-6 border border-white/10 relative overflow-hidden group">
 <div className="absolute top-0 right-0 -mr-4 -mt-4 w-24 h-24 bg-emerald-500/10 rounded-full blur-xl"></div>
 <div className="flex items-center space-x-3 text-emerald-400 mb-2">
 <Clock className="w-5 h-5" />
 <h3 className="font-semibold text-sm">Deep Work</h3>
 </div>
 <p className="text-4xl font-bold text-white">22<span className="text-lg text-white/40"> hrs</span></p>
 <p className="text-xs text-emerald-400 mt-2 flex items-center">
 <TrendingUpIcon className="w-3 h-3 mr-1" /> +4 hrs vs last week
 </p>
 </motion.div>

 <motion.div variants={item} className="glass-card p-6 border border-white/10 relative overflow-hidden group">
 <div className="absolute top-0 right-0 -mr-4 -mt-4 w-24 h-24 bg-orange-500/10 rounded-full blur-xl"></div>
 <div className="flex items-center space-x-3 text-orange-400 mb-2">
 <Flame className="w-5 h-5" />
 <h3 className="font-semibold text-sm">Current Streak</h3>
 </div>
 <p className="text-4xl font-bold text-white">4<span className="text-lg text-white/40"> days</span></p>
 <p className="text-xs text-white/40 mt-2 flex items-center">
 Best streak: 12 days
 </p>
 </motion.div>

 <motion.div variants={item} className="glass-card p-6 border border-white/10 relative overflow-hidden group">
 <div className="absolute top-0 right-0 -mr-4 -mt-4 w-24 h-24 bg-rose-500/10 rounded-full blur-xl"></div>
 <div className="flex items-center justify-between mb-2">
 <div className="flex items-center space-x-3 text-rose-400">
 <BrainCircuit className="w-5 h-5" />
 <h3 className="font-semibold text-sm">Burnout Risk</h3>
 </div>
 <span className="text-xs font-bold px-2 py-1 bg-rose-500/20 text-rose-400 rounded">Low</span>
 </div>
 <p className="text-4xl font-bold text-white">{burnoutRisk}<span className="text-lg text-white/40">%</span></p>
 <div className="h-1.5 w-full bg-black/40 rounded-full mt-3 overflow-hidden">
 <div className="h-full bg-gradient-to-r from-emerald-400 via-amber-400 to-rose-500" style={{ width: `${burnoutRisk}%` }}></div>
 </div>
 </motion.div>
 </div>

 {/* Main Charts Row */}
 <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
 
 {/* Productivity Trend */}
 <motion.div variants={item} className="col-span-1 lg:col-span-2 glass-card p-6 border border-white/10 flex flex-col h-[400px]">
 <h2 className="font-semibold text-lg text-white mb-6 flex items-center">
 <Activity className="w-5 h-5 mr-2 text-violet-400" />
 Output Trend (7 Days)
 </h2>
 <div className="flex-1 w-full h-full min-h-0">
 <ResponsiveContainer width="100%" height="100%">
 <AreaChart data={productivityData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
 <defs>
 <linearGradient id="colorTasks" x1="0" y1="0" x2="0" y2="1">
 <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.3}/>
 <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0}/>
 </linearGradient>
 <linearGradient id="colorFocus" x1="0" y1="0" x2="0" y2="1">
 <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
 <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
 </linearGradient>
 </defs>
 <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" vertical={false} />
 <XAxis dataKey="name" stroke="rgba(255,255,255,0.3)" fontSize={12} tickLine={false} axisLine={false} />
 <YAxis stroke="rgba(255,255,255,0.3)" fontSize={12} tickLine={false} axisLine={false} />
 <Tooltip 
 contentStyle={{ backgroundColor: '#111', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px', color: '#fff' }}
 itemStyle={{ color: '#fff' }}
 />
 <Area type="monotone" dataKey="tasks" name="Tasks Completed" stroke="#8b5cf6" strokeWidth={3} fillOpacity={1} fill="url(#colorTasks)" />
 <Area type="monotone" dataKey="focus" name="Focus Hrs" stroke="#10b981" strokeWidth={3} fillOpacity={1} fill="url(#colorFocus)" />
 </AreaChart>
 </ResponsiveContainer>
 </div>
 </motion.div>

 {/* Time Distribution */}
 <motion.div variants={item} className="col-span-1 glass-card p-6 border border-white/10 flex flex-col h-[400px]">
 <h2 className="font-semibold text-lg text-white mb-6 flex items-center">
 <Target className="w-5 h-5 mr-2 text-pink-400" />
 Time Allocation
 </h2>
 <div className="flex-1 w-full h-full min-h-0 flex flex-col">
 <ResponsiveContainer width="100%" height="100%">
 <BarChart data={timeDistribution} layout="vertical" margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
 <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" horizontal={true} vertical={false} />
 <XAxis type="number" hide />
 <YAxis dataKey="name" type="category" stroke="rgba(255,255,255,0.5)" fontSize={12} tickLine={false} axisLine={false} />
 <Tooltip 
 cursor={{fill: 'rgba(255,255,255,0.05)'}}
 contentStyle={{ backgroundColor: '#111', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px', color: '#fff' }}
 />
 <Bar dataKey="value" name="% of Time" radius={[0, 4, 4, 0]} barSize={24}>
 {timeDistribution.map((entry, index) => (
 <Cell key={`cell-${index}`} fill={entry.color} />
 ))}
 </Bar>
 </BarChart>
 </ResponsiveContainer>
 </div>
 </motion.div>

 </div>
 </motion.div>
 );
}

// Helper icon component
function TrendingUpIcon(props: any) {
 return (
 <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
 <polyline points="22 7 13.5 15.5 8.5 10.5 2 17" />
 <polyline points="16 7 22 7 22 13" />
 </svg>
 );
}
