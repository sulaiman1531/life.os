"use client";

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { fetchApi } from "@/lib/api";
import { Search, Mail, Archive, Trash2, Reply, Forward, MoreVertical, Loader2 } from "lucide-react";

export default function EmailsPage() {
 const queryClient = useQueryClient();
 const [selectedEmailId, setSelectedEmailId] = useState<string | null>(null);

 const { data: emails = [], isLoading } = useQuery({
 queryKey: ["emails"],
 queryFn: () => fetchApi("/emails/"),
 });

 const deleteEmail = useMutation({
 mutationFn: (id: string) => fetchApi(`/emails/${id}`, { method: "DELETE" }),
 onSuccess: () => {
 queryClient.invalidateQueries({ queryKey: ["emails"] });
 setSelectedEmailId(null);
 }
 });

 const markRead = useMutation({
 mutationFn: (id: string) => fetchApi(`/emails/${id}/read`, { method: "PUT" }),
 onSuccess: () => queryClient.invalidateQueries({ queryKey: ["emails"] })
 });

 const selectedEmail = emails.find((e: any) => e.id === selectedEmailId);

 const handleSelect = (email: any) => {
 setSelectedEmailId(email.id);
 if (!email.read) {
 markRead.mutate(email.id);
 }
 };

 const formatDate = (dateStr: string) => {
 const d = new Date(dateStr);
 return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
 };

 if (isLoading) {
 return (
 <div className="flex h-full items-center justify-center">
 <Loader2 className="w-8 h-8 animate-spin text-white/30" />
 </div>
 );
 }

 return (
 <div className="flex flex-col h-full space-y-6 animate-in fade-in duration-500">
 
 <div className="flex items-center justify-between">
 <div>
 <h1 className="text-3xl font-bold tracking-tight text-white mb-2 flex items-center">
 <Mail className="w-8 h-8 mr-3 text-blue-400" />
 Mail
 </h1>
 <p className="text-white/50">Centralized inbox for your communications.</p>
 </div>
 </div>

 <div className="flex flex-1 overflow-hidden glass-card border border-white/10 rounded-2xl">
 {/* Inbox List (Left Pane) */}
 <div className="w-1/3 min-w-[300px] border-r border-white/10 flex flex-col bg-white/5">
 <div className="p-4 border-b border-white/10 relative">
 <Search className="w-4 h-4 absolute left-7 top-1/2 -translate-y-1/2 text-white/40" />
 <input 
 type="text"
 placeholder="Search mail..."
 className="w-full bg-white/5 border border-white/10 rounded-lg pl-9 pr-4 py-2 text-sm text-white placeholder-white/30 focus:outline-none focus:border-blue-500/50 transition-colors"
 />
 </div>
 <div className="flex-1 overflow-y-auto scrollbar-none">
 {emails.length === 0 ? (
 <div className="p-8 text-center text-white/40 text-sm">Inbox is zero!</div>
 ) : (
 emails.map((email: any) => (
 <button
 key={email.id}
 onClick={() => handleSelect(email)}
 className={`w-full text-left p-4 border-b border-white/5 transition-colors ${selectedEmailId === email.id ? 'bg-blue-500/10 border-l-2 border-l-blue-500' : 'hover:bg-white/5'} ${!email.read ? 'bg-white/5' : ''}`}
 >
 <div className="flex justify-between items-baseline mb-1">
 <span className={`text-sm truncate pr-2 ${!email.read ? 'font-bold text-white' : 'font-medium text-white/70'}`}>
 {email.sender.split(' <')[0]}
 </span>
 <span className={`text-[10px] flex-shrink-0 ${!email.read ? 'text-blue-400 font-bold' : 'text-white/40'}`}>
 {formatDate(email.date)}
 </span>
 </div>
 <div className={`text-xs mb-1 truncate ${!email.read ? 'font-bold text-white/90' : 'text-white/60'}`}>
 {email.subject}
 </div>
 <div className="text-xs text-white/40 truncate">
 {email.snippet}
 </div>
 </button>
 ))
 )}
 </div>
 </div>

 {/* Reading Pane (Right Pane) */}
 <div className="flex-1 flex flex-col bg-[#0A0A0A]/50">
 {selectedEmail ? (
 <>
 {/* Toolbar */}
 <div className="h-14 border-b border-white/10 flex items-center justify-between px-6 bg-white/5">
 <div className="flex items-center space-x-2">
 <button className="p-2 rounded-lg hover:bg-white/10 text-white/60 transition-colors" title="Reply">
 <Reply className="w-4 h-4" />
 </button>
 <button className="p-2 rounded-lg hover:bg-white/10 text-white/60 transition-colors" title="Forward">
 <Forward className="w-4 h-4" />
 </button>
 </div>
 <div className="flex items-center space-x-2">
 <button className="p-2 rounded-lg hover:bg-white/10 text-white/60 transition-colors" title="Archive">
 <Archive className="w-4 h-4" />
 </button>
 <button 
 onClick={() => deleteEmail.mutate(selectedEmail.id)}
 className="p-2 rounded-lg hover:bg-red-500/20 text-white/60 hover:text-red-400 transition-colors" 
 title="Delete"
 >
 <Trash2 className="w-4 h-4" />
 </button>
 <button className="p-2 rounded-lg hover:bg-white/10 text-white/60 transition-colors" title="More">
 <MoreVertical className="w-4 h-4" />
 </button>
 </div>
 </div>
 
 {/* Email Content */}
 <div className="flex-1 overflow-y-auto p-8">
 <div className="max-w-3xl mx-auto">
 <h2 className="text-2xl font-bold text-white mb-6">{selectedEmail.subject}</h2>
 
 <div className="flex items-center justify-between mb-8 pb-6 border-b border-white/10">
 <div className="flex items-center space-x-4">
 <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center text-white font-bold">
 {selectedEmail.sender.charAt(0)}
 </div>
 <div>
 <div className="text-sm font-medium text-white">{selectedEmail.sender.split(' <')[0]}</div>
 <div className="text-xs text-white/50">{selectedEmail.sender.split('<')[1]?.replace('>','')}</div>
 </div>
 </div>
 <div className="text-xs text-white/40">
 {formatDate(selectedEmail.date)}
 </div>
 </div>

 <div className="text-white/80 whitespace-pre-wrap leading-relaxed text-sm">
 {selectedEmail.body}
 </div>
 </div>
 </div>
 </>
 ) : (
 <div className="flex-1 flex flex-col items-center justify-center text-white/20">
 <Mail className="w-16 h-16 mb-4 opacity-50" />
 <p>Select an item to read</p>
 </div>
 )}
 </div>
 </div>
 </div>
 );
}
