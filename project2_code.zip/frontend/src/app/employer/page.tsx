"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useRouter } from "next/navigation";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area, Cell } from "recharts";
import { Users, Clock, ShieldCheck, Activity, LogOut, Briefcase, Zap, AlertTriangle, Search, User, Sparkles, ArrowRight } from "lucide-react";

// Mock Data for Admin
const organizationData = {
 name: "Organization Output",
 activeEmployees: 24,
 totalHours: 759,
 avgEfficiency: 92,
 burnoutAlerts: 2,
 activityData: [
 { name: "Mon", hours: 142 },
 { name: "Tue", hours: 156 },
 { name: "Wed", hours: 164 },
 { name: "Thu", hours: 159 },
 { name: "Fri", hours: 138 },
 ],
 appUsage: [
 { name: "GitHub", value: 35, color: "#24292e" },
 { name: "Jira", value: 25, color: "#0052CC" },
 { name: "Slack", value: 20, color: "#E01E5A" },
 { name: "VS Code", value: 15, color: "#007ACC" },
 { name: "Other", value: 5, color: "#9ca3af" },
 ]
};

const employeeDB: Record<string, any> = {
 "EMP001": {
 name: "Alex Mercer (EMP001)",
 role: "Senior Engineer",
 activeEmployees: 1,
 totalHours: 42,
 avgEfficiency: 95,
 burnoutAlerts: 0,
 activityData: [
 { name: "Mon", hours: 8.5 },
 { name: "Tue", hours: 9 },
 { name: "Wed", hours: 8.2 },
 { name: "Thu", hours: 8 },
 { name: "Fri", hours: 8.3 },
 ],
 appUsage: [
 { name: "VS Code", value: 60, color: "#007ACC" },
 { name: "GitHub", value: 20, color: "#24292e" },
 { name: "Slack", value: 15, color: "#E01E5A" },
 { name: "Jira", value: 5, color: "#0052CC" },
 ]
 },
 "EMP002": {
 name: "Sarah Chen (EMP002)",
 role: "Product Manager",
 activeEmployees: 1,
 totalHours: 54, // High hours
 avgEfficiency: 82,
 burnoutAlerts: 1, // Burnout risk
 activityData: [
 { name: "Mon", hours: 10 },
 { name: "Tue", hours: 11 },
 { name: "Wed", hours: 10.5 },
 { name: "Thu", hours: 11.5 },
 { name: "Fri", hours: 11 },
 ],
 appUsage: [
 { name: "Jira", value: 45, color: "#0052CC" },
 { name: "Slack", value: 30, color: "#E01E5A" },
 { name: "Gmail", value: 15, color: "#EA4335" },
 { name: "Zoom", value: 10, color: "#2D8CFF" },
 ]
 }
};

const container = {
 hidden: { opacity: 0 },
 show: { opacity: 1, transition: { staggerChildren: 0.1 } }
};

const item = {
 hidden: { opacity: 0, y: 20 },
 show: { opacity: 1, y: 0, transition: { type: "spring", stiffness: 300, damping: 24 } }
};

export default function EmployerDashboard() {
 const router = useRouter();
 const [searchQuery, setSearchQuery] = useState("");
 const [employeeData, setEmployeeData] = useState<any>(null);

 const handleLogout = () => {
 localStorage.removeItem("token");
 localStorage.removeItem("role");
 router.push("/login");
 };

 const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
 const val = e.target.value;
 setSearchQuery(val);
 if (employeeDB[val.toUpperCase()]) {
 setEmployeeData(employeeDB[val.toUpperCase()]);
 } else {
 setEmployeeData(null);
 }
 };

 const currentData = employeeData || organizationData;
 const isEmployeeView = !!employeeData;

 return (
 <div className="min-h-screen bg-[#0A0A0A] text-white flex flex-col">
 {/* Admin Top Navigation */}
 <header className="h-16 border-b border-white/5 bg-black/40 flex items-center justify-between px-8">
 <div className="flex items-center space-x-3">
 <div className="w-8 h-8 rounded-lg bg-emerald-500/20 flex items-center justify-center">
 <Briefcase className="w-4 h-4 text-emerald-400" />
 </div>
 <span className="font-bold tracking-widest uppercase text-sm">Life OS Enterprise</span>
 <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-white/10 text-white/60 uppercase tracking-wider ml-2">Admin Center</span>
 </div>
 <button onClick={handleLogout} className="flex items-center space-x-2 text-sm text-white/50 hover:text-white transition-colors">
 <LogOut className="w-4 h-4" />
 <span>Secure Logout</span>
 </button>
 </header>

 {/* Dashboard Content */}
 <main className="flex-1 p-8 max-w-7xl mx-auto w-full">
 <motion.div variants={container} initial="hidden" animate="show" className="space-y-8">
 
 <motion.div variants={item} className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
 <div>
 <h1 className="text-3xl font-bold tracking-tight text-white mb-2">Workforce Analytics</h1>
 <p className="text-white/50 flex items-center">
 <ShieldCheck className="w-4 h-4 mr-1.5 text-emerald-400" />
 Privacy-First Mode Active. Content is hidden; only time metrics are visible.
 </p>
 </div>
 
 <div className="relative w-full md:w-72">
 <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
 <Search className="w-4 h-4 text-white/30" />
 </div>
 <input
 type="text"
 value={searchQuery}
 onChange={handleSearch}
 className="w-full bg-white/5 border border-white/10 rounded-lg py-2.5 pl-10 pr-4 text-sm text-white placeholder-white/30 focus:outline-none focus:border-emerald-500/50 transition-colors"
 placeholder="Search employee code (e.g., EMP001)"
 />
 </div>
 </motion.div>

 <AnimatePresence mode="wait">
 <motion.div
 key={isEmployeeView ? currentData.name : "org"}
 initial={{ opacity: 0, y: 10 }}
 animate={{ opacity: 1, y: 0 }}
 exit={{ opacity: 0, y: -10 }}
 transition={{ duration: 0.3 }}
 className="space-y-8"
 >
 {isEmployeeView && (
 <div className="flex items-center space-x-4 bg-emerald-500/10 border border-emerald-500/20 p-4 rounded-xl">
 <div className="w-12 h-12 rounded-full bg-emerald-500/20 flex items-center justify-center">
 <User className="w-6 h-6 text-emerald-400" />
 </div>
 <div>
 <h2 className="text-xl font-bold text-white">{currentData.name}</h2>
 <p className="text-emerald-400/80 text-sm">{currentData.role}</p>
 </div>
 </div>
 )}

 {/* Top Metrics Row */}
 <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
 {!isEmployeeView ? (
 <div className="glass-card p-6 border border-emerald-500/20 relative overflow-hidden group">
 <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/10 rounded-full blur-xl"></div>
 <div className="flex items-center space-x-3 text-emerald-400 mb-2">
 <Users className="w-5 h-5" />
 <h3 className="font-semibold text-sm">Active Employees</h3>
 </div>
 <p className="text-4xl font-bold text-white">{currentData.activeEmployees}</p>
 </div>
 ) : (
 <div className="glass-card p-6 border border-emerald-500/20 relative overflow-hidden group">
 <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/10 rounded-full blur-xl"></div>
 <div className="flex items-center space-x-3 text-emerald-400 mb-2">
 <Activity className="w-5 h-5" />
 <h3 className="font-semibold text-sm">Status</h3>
 </div>
 <p className="text-4xl font-bold text-white flex items-center">
 <span className="w-3 h-3 rounded-full bg-emerald-500 mr-3 animate-pulse"></span>
 Online
 </p>
 </div>
 )}

 <div className="glass-card p-6 border border-white/10 relative overflow-hidden group">
 <div className="flex items-center space-x-3 text-violet-400 mb-2">
 <Clock className="w-5 h-5" />
 <h3 className="font-semibold text-sm">Total Hours (Week)</h3>
 </div>
 <p className="text-4xl font-bold text-white">{currentData.totalHours}<span className="text-lg text-white/40"> hrs</span></p>
 </div>

 <div className="glass-card p-6 border border-white/10 relative overflow-hidden group">
 <div className="flex items-center space-x-3 text-blue-400 mb-2">
 <Zap className="w-5 h-5" />
 <h3 className="font-semibold text-sm">Avg Efficiency</h3>
 </div>
 <p className="text-4xl font-bold text-white">{currentData.avgEfficiency}<span className="text-lg text-white/40">%</span></p>
 </div>

 <div className={`glass-card p-6 border relative overflow-hidden group ${currentData.burnoutAlerts > 0 ? 'border-orange-500/50 bg-orange-500/5' : 'border-white/10'}`}>
 <div className="flex items-center space-x-3 text-orange-400 mb-2">
 <AlertTriangle className="w-5 h-5" />
 <h3 className="font-semibold text-sm">Burnout Risk</h3>
 </div>
 <p className="text-4xl font-bold text-white">{currentData.burnoutAlerts > 0 ? 'High' : 'Low'}</p>
 <p className="text-xs text-orange-400/80 mt-1">
 {currentData.burnoutAlerts > 0 ? 'Requires 1-on-1 check-in immediately' : 'Optimal working condition'}
 </p>
 </div>
 </div>

 {/* Charts Row */}
 <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[400px]">
 {/* Team/Employee Activity Trend */}
 <div className="col-span-1 lg:col-span-2 glass-card p-6 border border-white/10 flex flex-col h-full">
 <h2 className="font-semibold text-lg text-white mb-6 flex items-center">
 <Activity className="w-5 h-5 mr-2 text-violet-400" />
 {isEmployeeView ? "Weekly Work Trend" : "Organization Output Trend"}
 </h2>
 <div className="flex-1 w-full min-h-0">
 <ResponsiveContainer width="100%" height="100%">
 <AreaChart data={currentData.activityData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
 <defs>
 <linearGradient id="colorHours" x1="0" y1="0" x2="0" y2="1">
 <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
 <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
 </linearGradient>
 </defs>
 <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" vertical={false} />
 <XAxis dataKey="name" stroke="rgba(255,255,255,0.3)" fontSize={12} tickLine={false} axisLine={false} />
 <YAxis stroke="rgba(255,255,255,0.3)" fontSize={12} tickLine={false} axisLine={false} />
 <Tooltip 
 contentStyle={{ backgroundColor: '#111', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px', color: '#fff' }}
 itemStyle={{ color: '#fff' }}
 />
 <Area type="monotone" dataKey="hours" name="Hours" stroke="#10b981" strokeWidth={3} fillOpacity={1} fill="url(#colorHours)" />
 </AreaChart>
 </ResponsiveContainer>
 </div>
 </div>

 {/* App Usage Distribution */}
 <div className="col-span-1 glass-card p-6 border border-white/10 flex flex-col h-full">
 <h2 className="font-semibold text-lg text-white mb-6 flex items-center">
 <Briefcase className="w-5 h-5 mr-2 text-blue-400" />
 Time Allocation by Tool
 </h2>
 <div className="flex-1 w-full min-h-0 flex flex-col">
 <ResponsiveContainer width="100%" height="100%">
 <BarChart data={currentData.appUsage} layout="vertical" margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
 <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" horizontal={true} vertical={false} />
 <XAxis type="number" hide />
 <YAxis dataKey="name" type="category" stroke="rgba(255,255,255,0.5)" fontSize={12} tickLine={false} axisLine={false} />
 <Tooltip 
 cursor={{fill: 'rgba(255,255,255,0.05)'}}
 contentStyle={{ backgroundColor: '#111', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px', color: '#fff' }}
 />
 <Bar dataKey="value" name="% of Time" radius={[0, 4, 4, 0]} barSize={24}>
 {currentData.appUsage.map((entry: any, index: number) => (
 <Cell key={`cell-${index}`} fill={entry.color} />
 ))}
 </Bar>
 </BarChart>
 </ResponsiveContainer>
 </div>
 </div>
 </div>

 {/* Predictive AI Engine Panel */}
 <div className="glass-card p-6 border border-fuchsia-500/20 relative overflow-hidden">
 <div className="absolute top-0 right-0 w-64 h-64 bg-fuchsia-500/10 rounded-full blur-[80px] pointer-events-none"></div>
 <div className="relative z-10">
 <h2 className="text-xl font-bold text-white mb-2 flex items-center">
 <Sparkles className="w-5 h-5 mr-2 text-fuchsia-400" />
 AI Predictive Insights
 </h2>
 <p className="text-white/50 text-sm mb-6">Analyzing historical velocity, burnout indicators, and task assignments to predict future outcomes.</p>
 
 <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
 {/* Insight 1 */}
 <div className="bg-black/40 border border-orange-500/30 rounded-xl p-5 shadow-[0_0_15px_rgba(249,115,22,0.05)]">
 <div className="flex items-start justify-between mb-3">
 <div className="flex items-center space-x-2 text-orange-400 font-semibold text-sm uppercase tracking-wider">
 <AlertTriangle className="w-4 h-4" />
 <span>Delivery Risk Detected</span>
 </div>
 <span className="text-xs bg-orange-500/20 text-orange-400 px-2 py-0.5 rounded font-mono">Q3 Release</span>
 </div>
 <p className="text-white text-sm leading-relaxed mb-4">
 Based on <span className="font-bold text-white">Sarah Chen's (EMP002)</span> current high-burnout indicators (54 hrs/wk), the "Frontend Refactor" milestone is predicted to be delayed by <strong className="text-orange-400">4 days</strong>.
 </p>
 <button className="w-full flex items-center justify-center space-x-2 bg-white/5 hover:bg-white/10 border border-white/10 py-2 rounded-lg text-sm transition-colors text-white/80 hover:text-white">
 <ArrowRight className="w-4 h-4 text-emerald-400" />
 <span>Simulate shifting 2 tickets to Alex Mercer</span>
 </button>
 </div>

 {/* Insight 2 */}
 <div className="bg-black/40 border border-emerald-500/30 rounded-xl p-5 shadow-[0_0_15px_rgba(16,185,129,0.05)]">
 <div className="flex items-start justify-between mb-3">
 <div className="flex items-center space-x-2 text-emerald-400 font-semibold text-sm uppercase tracking-wider">
 <Activity className="w-4 h-4" />
 <span>Optimization Opportunity</span>
 </div>
 <span className="text-xs bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded font-mono">Velocity</span>
 </div>
 <p className="text-white text-sm leading-relaxed mb-4">
 The team's average efficiency peaks between <strong className="text-emerald-400">9:00 AM and 11:30 AM</strong>. Moving the daily standup to 1:00 PM is predicted to increase overall weekly output by <strong>+8%</strong>.
 </p>
 <button className="w-full flex items-center justify-center space-x-2 bg-emerald-600 hover:bg-emerald-500 py-2 rounded-lg text-sm transition-colors text-white">
 <Sparkles className="w-4 h-4" />
 <span>Apply Schedule Recommendation</span>
 </button>
 </div>
 </div>
 </div>
 </div>
 </motion.div>
 </AnimatePresence>

 </motion.div>
 </main>
 </div>
 );
}
