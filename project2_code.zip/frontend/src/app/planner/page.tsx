"use client";

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { fetchApi } from "@/lib/api";
import { Calendar as CalendarIcon, ChevronLeft, ChevronRight, Clock, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function PlannerPage() {
 const queryClient = useQueryClient();
 const [currentDate, setCurrentDate] = useState(new Date());
 
 const [isModalOpen, setIsModalOpen] = useState(false);
 const [selectedHour, setSelectedHour] = useState(8);
 const [blockTitle, setBlockTitle] = useState("");
 const [duration, setDuration] = useState(1);

 // Format YYYY-MM-DD
 const dateString = currentDate.toISOString().split('T')[0];

 const { data: blocks = [] } = useQuery({
 queryKey: ["planner", dateString],
 queryFn: () => fetchApi(`/planner/?date=${dateString}`),
 });

 const addBlock = useMutation({
 mutationFn: (newBlock: any) => fetchApi("/planner/", {
 method: "POST",
 body: JSON.stringify(newBlock)
 }),
 onSuccess: () => {
 queryClient.invalidateQueries({ queryKey: ["planner"] });
 setIsModalOpen(false);
 setBlockTitle("");
 },
 });

 const handleDayChange = (days: number) => {
 const next = new Date(currentDate);
 next.setDate(currentDate.getDate() + days);
 setCurrentDate(next);
 };

 const openModal = (hour: number) => {
 setSelectedHour(hour);
 setIsModalOpen(true);
 };

 const handleScheduleSubmit = (e: React.FormEvent) => {
 e.preventDefault();
 if (blockTitle.trim()) {
 addBlock.mutate({
 title: blockTitle,
 start_time: `${selectedHour.toString().padStart(2, '0')}:00`,
 end_time: `${(selectedHour + duration).toString().padStart(2, '0')}:00`,
 date: dateString
 });
 }
 };

 const hours = Array.from({ length: 14 }, (_, i) => i + 8); // 8 AM to 9 PM

 return (
 <div className="flex h-full w-full flex-col animate-in fade-in duration-500 relative">
 
 {/* Planner Modal */}
 <AnimatePresence>
 {isModalOpen && (
 <motion.div 
 initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
 className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4"
 >
 <motion.div 
 initial={{ scale: 0.95, opacity: 0, y: 20 }} animate={{ scale: 1, opacity: 1, y: 0 }} exit={{ scale: 0.95, opacity: 0, y: 20 }}
 className="w-full max-w-md bg-[#0A0A0A] border border-white/10 rounded-2xl p-6 shadow-2xl relative overflow-hidden"
 >
 <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/10 rounded-full blur-3xl"></div>
 
 <div className="flex justify-between items-center mb-6 relative z-10">
 <h3 className="text-xl font-bold flex items-center">
 <Clock className="w-5 h-5 text-blue-500 mr-2" />
 Schedule Block
 </h3>
 <button onClick={() => setIsModalOpen(false)} className="text-white/40 hover:text-white transition-colors">
 <X className="w-5 h-5" />
 </button>
 </div>

 <form onSubmit={handleScheduleSubmit} className="relative z-10 space-y-4">
 <div>
 <input 
 type="text" autoFocus required
 placeholder="e.g., Client Meeting..."
 className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-white/30 focus:outline-none focus:border-blue-500/50 transition-colors"
 value={blockTitle}
 onChange={(e) => setBlockTitle(e.target.value)}
 />
 </div>
 <div className="flex space-x-4">
 <div className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white/50">
 {selectedHour === 12 ? "12:00 PM" : selectedHour > 12 ? `${selectedHour - 12}:00 PM` : `${selectedHour}:00 AM`}
 </div>
 <div className="flex-1">
 <select 
 className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500/50 transition-colors appearance-none"
 value={duration}
 onChange={(e) => setDuration(Number(e.target.value))}
 >
 <option value={1} className="bg-black">1 Hour</option>
 <option value={2} className="bg-black">2 Hours</option>
 <option value={3} className="bg-black">3 Hours</option>
 </select>
 </div>
 </div>
 <button 
 type="submit" 
 disabled={addBlock.isPending}
 className="w-full bg-blue-600 hover:bg-blue-500 text-white font-semibold py-3 rounded-xl transition-colors mt-2"
 >
 {addBlock.isPending ? "Scheduling..." : "Lock in Calendar"}
 </button>
 </form>
 </motion.div>
 </motion.div>
 )}
 </AnimatePresence>

 {/* Header */}
 <div className="flex items-center justify-between mb-8">
 <div>
 <h1 className="text-3xl font-bold tracking-tight mb-2 text-white">Daily Planner</h1>
 <p className="text-white/50">Schedule your deep work blocks.</p>
 </div>
 <div className="flex items-center space-x-4 bg-white/5 p-1 rounded-lg border border-white/10">
 <button onClick={() => handleDayChange(-1)} className="p-2 hover:bg-white/10 rounded-md transition-colors"><ChevronLeft className="w-4 h-4" /></button>
 <span className="text-sm font-medium px-2 min-w-[120px] text-center">
 {currentDate.toLocaleDateString("en-US", { weekday: 'short', month: 'short', day: 'numeric' })}
 </span>
 <button onClick={() => handleDayChange(1)} className="p-2 hover:bg-white/10 rounded-md transition-colors"><ChevronRight className="w-4 h-4" /></button>
 </div>
 </div>

 {/* Timeline Grid */}
 <div className="flex-1 overflow-y-auto glass-card border border-white/10 rounded-xl relative scrollbar-none">
 
 {/* Time slots */}
 <div className="relative">
 {hours.map((hour) => (
 <div key={hour} className="flex border-b border-white/5 h-20 group relative">
 <div className="w-20 flex-shrink-0 border-r border-white/5 flex justify-center py-2 text-xs font-medium text-white/40">
 {hour === 12 ? "12 PM" : hour > 12 ? `${hour - 12} PM` : `${hour} AM`}
 </div>
 <div onClick={() => openModal(hour)} className="flex-1 relative cursor-pointer hover:bg-white/[0.02] transition-colors">
 {/* Plus button on hover */}
 <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 pointer-events-none">
 <span className="text-xs font-semibold text-violet-500 bg-violet-500/10 px-2 py-1 rounded">+ Schedule block</span>
 </div>
 </div>
 </div>
 ))}

 {/* Current Time Indicator Line (Only show if date is today) */}
 {new Date().toDateString() === currentDate.toDateString() && (
 <div className="absolute top-[210px] left-20 right-0 h-px bg-violet-500/50 z-10 pointer-events-none">
 <div className="absolute -left-2 -top-1.5 w-3 h-3 bg-violet-500 rounded-full animate-pulse border-2 border-[#0A0A0A]" />
 </div>
 )}

 {/* Render Actual Scheduled Blocks */}
 {blocks.map((block: any, idx: number) => {
 const startHour = parseInt(block.start_time.split(':')[0]);
 const endHour = parseInt(block.end_time.split(':')[0]);
 if (startHour < 8 || startHour > 21) return null;
 
 const topPos = (startHour - 8) * 80;
 const height = (endHour - startHour) * 80;
 
 return (
 <div key={block.id} style={{ top: `${topPos + 4}px`, height: `${height - 8}px` }} className="absolute left-[90px] right-6 bg-blue-500/20 border border-blue-500/30 rounded-lg p-3 z-0 flex flex-col justify-between group hover:bg-blue-500/30 transition-colors pointer-events-none">
 <div className="flex items-start justify-between">
 <div>
 <h4 className="text-sm font-semibold text-blue-100">{block.title}</h4>
 <p className="text-xs text-blue-300 mt-1">{block.start_time} - {block.end_time}</p>
 </div>
 <Clock className="w-4 h-4 text-blue-400" />
 </div>
 </div>
 )
 })}
 </div>

 </div>
 </div>
 );
}
