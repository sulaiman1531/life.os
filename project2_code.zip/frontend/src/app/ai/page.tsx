"use client";

import { useState, useRef, useEffect } from "react";
import { Send, Bot, User, Loader2, Sparkles } from "lucide-react";
import { fetchApi } from "@/lib/api";

export default function AIPage() {
 const [messages, setMessages] = useState<{ role: string; content: string }[]>([]);
 const [input, setInput] = useState("");
 const [isLoading, setIsLoading] = useState(false);
 const messagesEndRef = useRef<HTMLDivElement>(null);

 const scrollToBottom = () => {
 messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
 };

 useEffect(() => {
 scrollToBottom();
 }, [messages]);

 const handleSubmit = async (e: React.FormEvent) => {
 e.preventDefault();
 if (!input.trim() || isLoading) return;

 const userMsg = input.trim();
 setInput("");
 setMessages((prev) => [...prev, { role: "user", content: userMsg }]);
 setIsLoading(true);

 try {
 const data = await fetchApi("/chat/", {
 method: "POST",
 body: JSON.stringify({ message: userMsg }),
 });
 setMessages((prev) => [...prev, { role: "ai", content: data.reply }]);
 } catch (error) {
 console.error(error);
 setMessages((prev) => [...prev, { role: "ai", content: "Sorry, I encountered an error. Is the Gemini API configured?" }]);
 } finally {
 setIsLoading(false);
 }
 };

 return (
 <div className="flex flex-col h-full animate-in fade-in duration-500 pb-4 max-w-5xl mx-auto w-full">
 
 <div className="flex items-center mb-6 pb-6 border-b border-white/10">
 <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#A855F7] to-[#3B82F6] flex items-center justify-center mr-4">
 <Sparkles className="w-6 h-6 text-white" />
 </div>
 <div>
 <h1 className="text-2xl font-bold tracking-tight text-white">AI Assistant</h1>
 <p className="text-white/50 text-sm">Powered by Google Gemini. Ask me to query your notes, tasks, or plan your day.</p>
 </div>
 </div>

 <div className="flex-1 overflow-y-auto pr-4 space-y-6 scrollbar-thin scrollbar-thumb-white/10 pb-10">
 {messages.length === 0 && (
 <div className="h-full flex flex-col items-center justify-center text-center opacity-50">
 <Bot className="w-16 h-16 text-white/20 mb-4" />
 <h3 className="text-xl text-white font-medium">How can I help you today?</h3>
 <p className="text-white/50 mt-2 max-w-sm text-sm">I have access to your tasks, notes, habits, and planner blocks.</p>
 </div>
 )}
 
 {messages.map((m, i) => (
 <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
 <div className={`flex max-w-[80%] ${m.role === "user" ? "flex-row-reverse" : "flex-row"}`}>
 
 <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 mt-1 ${
 m.role === "user" ? "bg-white/10 ml-3" : "bg-gradient-to-br from-[#A855F7] to-[#3B82F6] mr-3"
 }`}>
 {m.role === "user" ? <User className="w-4 h-4 text-white" /> : <Sparkles className="w-4 h-4 text-white" />}
 </div>
 
 <div className={`p-4 rounded-2xl ${
 m.role === "user" 
 ? "bg-white/10 text-white rounded-tr-sm" 
 : "glass-card border border-white/10 text-white/90 rounded-tl-sm leading-relaxed whitespace-pre-wrap"
 }`}>
 {m.content}
 </div>
 
 </div>
 </div>
 ))}
 {isLoading && (
 <div className="flex justify-start">
 <div className="flex max-w-[80%] flex-row">
 <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#A855F7] to-[#3B82F6] flex items-center justify-center flex-shrink-0 mt-1 mr-3">
 <Sparkles className="w-4 h-4 text-white" />
 </div>
 <div className="p-4 rounded-2xl glass-card border border-white/10 text-white/90 rounded-tl-sm flex items-center space-x-2">
 <Loader2 className="w-4 h-4 animate-spin text-white/50" />
 <span className="text-white/50 text-sm">Thinking...</span>
 </div>
 </div>
 </div>
 )}
 <div ref={messagesEndRef} />
 </div>

 <div className="pt-4 border-t border-white/10 mt-auto">
 <form onSubmit={handleSubmit} className="relative">
 <input
 type="text"
 className="w-full bg-white/5 border border-white/10 rounded-2xl pl-5 pr-14 py-4 text-white placeholder-white/30 focus:outline-none focus:border-violet-500/50 focus:bg-white/10 transition-all shadow-inner"
 placeholder="Ask AI anything..."
 value={input}
 onChange={(e) => setInput(e.target.value)}
 disabled={isLoading}
 />
 <button
 type="submit"
 disabled={isLoading || !input.trim()}
 className="absolute right-2 top-2 p-2.5 bg-violet-600 hover:bg-violet-500 disabled:bg-white/5 disabled:text-white/20 text-white rounded-xl transition-colors"
 >
 <Send className="w-4 h-4" />
 </button>
 </form>
 <p className="text-center text-[10px] text-white/30 mt-3">AI can make mistakes. Verify important information.</p>
 </div>

 </div>
 );
}
