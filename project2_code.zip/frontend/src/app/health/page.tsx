"use client";

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { fetchApi } from "@/lib/api";
import { Heart, Activity, Droplets, Moon, Footprints, Flame } from "lucide-react";
import { format } from "date-fns";

export default function HealthPage() {
 const queryClient = useQueryClient();
 const todayDate = format(new Date(), 'yyyy-MM-dd');
 
 const { data: logs = [] } = useQuery({
 queryKey: ["health_logs"],
 queryFn: () => fetchApi("/health/"),
 });

 const addLog = useMutation({
 mutationFn: (newLog: any) => fetchApi("/health/", {
 method: "POST",
 body: JSON.stringify(newLog)
 }),
 onSuccess: () => queryClient.invalidateQueries({ queryKey: ["health_logs"] }),
 });

 const updateLog = useMutation({
 mutationFn: ({ id, data }: { id: string, data: any }) => fetchApi(`/health/${id}`, {
 method: "PUT",
 body: JSON.stringify(data)
 }),
 onSuccess: () => queryClient.invalidateQueries({ queryKey: ["health_logs"] }),
 });

 const todayLog = logs.find((l: any) => l.date === todayDate) || {
 water_ml: 0,
 sleep_hours: 0,
 steps: 0,
 calories: 0
 };

 const handleUpdate = (field: string, value: number) => {
 if (todayLog.id) {
 updateLog.mutate({ id: todayLog.id, data: { ...todayLog, [field]: value } });
 } else {
 addLog.mutate({ date: todayDate, [field]: value });
 }
 };

 return (
 <div className="flex flex-col h-full space-y-8 animate-in fade-in duration-500">
 
 <div className="flex justify-between items-end">
 <div>
 <h1 className="text-3xl font-bold tracking-tight text-white mb-2">Health & Wellness</h1>
 <p className="text-white/50">Track your daily vitals and biometrics.</p>
 </div>
 </div>

 <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
 
 {/* Water */}
 <div className="glass-card border border-sky-500/20 rounded-2xl p-6 relative overflow-hidden group">
 <div className="absolute -right-4 -bottom-4 w-32 h-32 bg-sky-500/10 rounded-full blur-3xl group-hover:bg-sky-500/20 transition-all"></div>
 <div className="flex items-center space-x-3 mb-4">
 <Droplets className="w-5 h-5 text-sky-400" />
 <h3 className="font-semibold text-white">Hydration</h3>
 </div>
 <div className="text-4xl font-light text-white mb-1">{todayLog.water_ml} <span className="text-lg text-white/30">ml</span></div>
 <div className="flex space-x-2 mt-4">
 <button onClick={() => handleUpdate("water_ml", todayLog.water_ml + 250)} className="flex-1 bg-white/5 hover:bg-white/10 text-white/80 py-1 rounded border border-white/10 text-sm transition-colors">+250</button>
 <button onClick={() => handleUpdate("water_ml", todayLog.water_ml + 500)} className="flex-1 bg-white/5 hover:bg-white/10 text-white/80 py-1 rounded border border-white/10 text-sm transition-colors">+500</button>
 </div>
 </div>

 {/* Sleep */}
 <div className="glass-card border border-indigo-500/20 rounded-2xl p-6 relative overflow-hidden group">
 <div className="absolute -right-4 -bottom-4 w-32 h-32 bg-indigo-500/10 rounded-full blur-3xl group-hover:bg-indigo-500/20 transition-all"></div>
 <div className="flex items-center space-x-3 mb-4">
 <Moon className="w-5 h-5 text-indigo-400" />
 <h3 className="font-semibold text-white">Sleep</h3>
 </div>
 <div className="text-4xl font-light text-white mb-1">{todayLog.sleep_hours} <span className="text-lg text-white/30">hrs</span></div>
 <div className="flex space-x-2 mt-4">
 <button onClick={() => handleUpdate("sleep_hours", Math.max(0, todayLog.sleep_hours - 0.5))} className="flex-1 bg-white/5 hover:bg-white/10 text-white/80 py-1 rounded border border-white/10 text-sm transition-colors">-</button>
 <button onClick={() => handleUpdate("sleep_hours", todayLog.sleep_hours + 0.5)} className="flex-1 bg-white/5 hover:bg-white/10 text-white/80 py-1 rounded border border-white/10 text-sm transition-colors">+</button>
 </div>
 </div>

 {/* Steps */}
 <div className="glass-card border border-emerald-500/20 rounded-2xl p-6 relative overflow-hidden group">
 <div className="absolute -right-4 -bottom-4 w-32 h-32 bg-emerald-500/10 rounded-full blur-3xl group-hover:bg-emerald-500/20 transition-all"></div>
 <div className="flex items-center space-x-3 mb-4">
 <Footprints className="w-5 h-5 text-emerald-400" />
 <h3 className="font-semibold text-white">Steps</h3>
 </div>
 <div className="text-4xl font-light text-white mb-1">{todayLog.steps}</div>
 <div className="flex space-x-2 mt-4">
 <button onClick={() => handleUpdate("steps", todayLog.steps + 500)} className="flex-1 bg-white/5 hover:bg-white/10 text-white/80 py-1 rounded border border-white/10 text-sm transition-colors">+500</button>
 <button onClick={() => handleUpdate("steps", todayLog.steps + 1000)} className="flex-1 bg-white/5 hover:bg-white/10 text-white/80 py-1 rounded border border-white/10 text-sm transition-colors">+1000</button>
 </div>
 </div>

 {/* Calories */}
 <div className="glass-card border border-orange-500/20 rounded-2xl p-6 relative overflow-hidden group">
 <div className="absolute -right-4 -bottom-4 w-32 h-32 bg-orange-500/10 rounded-full blur-3xl group-hover:bg-orange-500/20 transition-all"></div>
 <div className="flex items-center space-x-3 mb-4">
 <Flame className="w-5 h-5 text-orange-400" />
 <h3 className="font-semibold text-white">Calories</h3>
 </div>
 <div className="text-4xl font-light text-white mb-1">{todayLog.calories} <span className="text-lg text-white/30">kcal</span></div>
 <div className="flex space-x-2 mt-4">
 <button onClick={() => handleUpdate("calories", todayLog.calories + 100)} className="flex-1 bg-white/5 hover:bg-white/10 text-white/80 py-1 rounded border border-white/10 text-sm transition-colors">+100</button>
 <button onClick={() => handleUpdate("calories", todayLog.calories + 500)} className="flex-1 bg-white/5 hover:bg-white/10 text-white/80 py-1 rounded border border-white/10 text-sm transition-colors">+500</button>
 </div>
 </div>
 </div>
 
 {/* Historic Data placeholder */}
 <div className="mt-8 border border-white/5 rounded-2xl p-8 flex flex-col items-center justify-center opacity-50 bg-white/[0.02]">
 <Activity className="w-12 h-12 text-white/20 mb-4" />
 <h3 className="text-white font-medium">History Trends</h3>
 <p className="text-white/40 text-sm mt-2">Log data for a few days to see trends here.</p>
 </div>

 </div>
 );
}
