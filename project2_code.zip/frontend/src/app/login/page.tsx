"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { BrainCircuit, Fingerprint, Lock, Mail, ArrowRight, Sparkles, User } from "lucide-react";

export default function LoginPage() {
 const [isLogin, setIsLogin] = useState(true);
 const [email, setEmail] = useState("test@example.com");
 const [password, setPassword] = useState("password");
 const [fullName, setFullName] = useState("");
 const [role, setRole] = useState("employee");
 const [error, setError] = useState("");
 const [isLoading, setIsLoading] = useState(false);
 const router = useRouter();

 const handleSubmit = async (e: React.FormEvent) => {
 e.preventDefault();
 setError("");
 setIsLoading(true);

 try {
 const endpoint = isLogin ? "/auth/login" : "/auth/register";
 const body = isLogin 
 ? { email, password, full_name: "", role: "employee" } 
 : { email, password, full_name: fullName, role };

 const res = await fetch(`http://localhost:8000/api${endpoint}`, {
 method: "POST",
 headers: { "Content-Type": "application/json" },
 body: JSON.stringify(body)
 });

 if (!res.ok) {
 const data = await res.json();
 throw new Error(data.detail || "Authentication failed");
 }

 const data = await res.json();
 
 if (isLogin) {
 localStorage.setItem("token", data.access_token);
 localStorage.setItem("role", data.role || "employee");
 router.push(data.role === "employer" ? "/employer" : "/workspace");
 } else {
 localStorage.setItem("token", data.id || data.access_token);
 localStorage.setItem("role", data.role || "employee");
 router.push(data.role === "employer" ? "/employer" : "/workspace");
 }
 } catch (err: any) {
 setError(err.message);
 } finally {
 setIsLoading(false);
 }
 };

 return (
 <div className="min-h-screen bg-[#0A0A0A] text-white flex overflow-hidden">
 
 {/* Left Panel - Branding & Animation (Hidden on mobile) */}
 <div className="hidden lg:flex w-1/2 relative flex-col justify-between p-12 border-r border-white/5 bg-black/40 overflow-hidden">
 {/* Background Effects */}
 <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
 <motion.div 
 animate={{ 
 scale: [1, 1.2, 1],
 opacity: [0.3, 0.5, 0.3],
 }}
 transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
 className="absolute -top-[20%] -left-[10%] w-[70%] h-[70%] rounded-full bg-violet-600/20 blur-[120px]"
 />
 <motion.div 
 animate={{ 
 scale: [1, 1.5, 1],
 opacity: [0.2, 0.4, 0.2],
 }}
 transition={{ duration: 10, repeat: Infinity, ease: "easeInOut", delay: 2 }}
 className="absolute bottom-[10%] -right-[20%] w-[60%] h-[60%] rounded-full bg-emerald-600/20 blur-[120px]"
 />
 <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 brightness-100 contrast-150"></div>
 </div>

 {/* Logo */}
 <motion.div 
 initial={{ opacity: 0, y: 20 }}
 animate={{ opacity: 1, y: 0 }}
 transition={{ duration: 0.8 }}
 className="relative z-10 flex items-center space-x-3"
 >
 <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-violet-500 to-indigo-600 flex items-center justify-center shadow-lg shadow-violet-500/20">
 <BrainCircuit className="w-6 h-6 text-white" />
 </div>
 <span className="text-xl font-bold tracking-widest uppercase">LIFE OS</span>
 </motion.div>

 {/* Hero Copy */}
 <motion.div 
 initial={{ opacity: 0, y: 30 }}
 animate={{ opacity: 1, y: 0 }}
 transition={{ duration: 0.8, delay: 0.2 }}
 className="relative z-10 max-w-md"
 >
 <h1 className="text-5xl font-extrabold tracking-tight mb-6 leading-tight">
 The Autonomous <br/>
 <span className="text-transparent bg-clip-text bg-gradient-to-r from-violet-400 to-emerald-400">
 Intelligence Layer
 </span>
 </h1>
 <p className="text-lg text-white/50 leading-relaxed">
 More than a dashboard. A completely private, localized OS powered by LangChain and FAISS vector memory that actually does the work for you.
 </p>
 
 <div className="mt-10 flex items-center space-x-4 text-sm font-medium text-white/40">
 <div className="flex items-center space-x-2">
 <Sparkles className="w-4 h-4 text-violet-400" />
 <span>RAG Memory</span>
 </div>
 <div className="w-1 h-1 rounded-full bg-white/20"></div>
 <div className="flex items-center space-x-2">
 <Lock className="w-4 h-4 text-emerald-400" />
 <span>100% Private</span>
 </div>
 </div>
 </motion.div>
 
 {/* Footer */}
 <div className="relative z-10 text-sm text-white/30 font-medium tracking-wide">
 © 2026 LIFE OS ENTERPRISE
 </div>
 </div>

 {/* Right Panel - Form */}
 <div className="w-full lg:w-1/2 flex items-center justify-center p-8 relative">
 <motion.div 
 initial={{ opacity: 0, scale: 0.95 }}
 animate={{ opacity: 1, scale: 1 }}
 transition={{ duration: 0.5 }}
 className="w-full max-w-md"
 >
 <div className="mb-10 text-center lg:text-left">
 <h2 className="text-3xl font-bold mb-2">
 {isLogin ? "Welcome back" : "Initialize access"}
 </h2>
 <p className="text-white/50">
 {isLogin ? "Enter your credentials to access your OS." : "Create your master node account."}
 </p>
 </div>

 <form onSubmit={handleSubmit} className="space-y-5">
 {!isLogin && (
 <motion.div 
 initial={{ opacity: 0, height: 0 }}
 animate={{ opacity: 1, height: "auto" }}
 className="space-y-2"
 >
 <label className="text-xs font-semibold uppercase tracking-wider text-white/50 ml-1">Master Name</label>
 <div className="relative group">
 <div className="absolute inset-y-0 left-0 flex items-center pl-4 pointer-events-none">
 <User className="w-5 h-5 text-white/30 group-focus-within:text-violet-400 transition-colors" />
 </div>
 <input
 type="text"
 value={fullName}
 onChange={(e) => setFullName(e.target.value)}
 className="w-full bg-white/[0.03] border border-white/10 rounded-xl py-3.5 pl-11 pr-4 text-white placeholder-white/20 focus:outline-none focus:border-violet-500/50 focus:bg-white/[0.05] transition-all"
 placeholder="John Doe"
 required={!isLogin}
 />
 </div>
 </motion.div>
 )}

 {!isLogin && (
 <motion.div 
 initial={{ opacity: 0, height: 0 }}
 animate={{ opacity: 1, height: "auto" }}
 className="space-y-2"
 >
 <label className="text-xs font-semibold uppercase tracking-wider text-white/50 ml-1">Account Type</label>
 <div className="flex bg-white/[0.03] border border-white/10 rounded-xl p-1">
 <button
 type="button"
 onClick={() => setRole("employee")}
 className={`flex-1 py-2 text-sm font-medium rounded-lg transition-all ${
 role === "employee" ? "bg-violet-600 text-white shadow-lg" : "text-white/50 hover:text-white"
 }`}
 >
 Employee
 </button>
 <button
 type="button"
 onClick={() => setRole("employer")}
 className={`flex-1 py-2 text-sm font-medium rounded-lg transition-all ${
 role === "employer" ? "bg-emerald-600 text-white shadow-lg" : "text-white/50 hover:text-white"
 }`}
 >
 Employer (Admin)
 </button>
 </div>
 </motion.div>
 )}

 <div className="space-y-2">
 <label className="text-xs font-semibold uppercase tracking-wider text-white/50 ml-1">Email Coordinates</label>
 <div className="relative group">
 <div className="absolute inset-y-0 left-0 flex items-center pl-4 pointer-events-none">
 <Mail className="w-5 h-5 text-white/30 group-focus-within:text-violet-400 transition-colors" />
 </div>
 <input
 type="email"
 value={email}
 onChange={(e) => setEmail(e.target.value)}
 className="w-full bg-white/[0.03] border border-white/10 rounded-xl py-3.5 pl-11 pr-4 text-white placeholder-white/20 focus:outline-none focus:border-violet-500/50 focus:bg-white/[0.05] transition-all"
 placeholder="admin@lifeos.dev"
 required
 />
 </div>
 </div>

 <div className="space-y-2">
 <div className="flex justify-between items-center ml-1">
 <label className="text-xs font-semibold uppercase tracking-wider text-white/50">Security Key</label>
 {isLogin && <a href="#" className="text-xs text-violet-400 hover:text-violet-300 transition-colors">Lost access?</a>}
 </div>
 <div className="relative group">
 <div className="absolute inset-y-0 left-0 flex items-center pl-4 pointer-events-none">
 <Lock className="w-5 h-5 text-white/30 group-focus-within:text-violet-400 transition-colors" />
 </div>
 <input
 type="password"
 value={password}
 onChange={(e) => setPassword(e.target.value)}
 className="w-full bg-white/[0.03] border border-white/10 rounded-xl py-3.5 pl-11 pr-4 text-white placeholder-white/20 focus:outline-none focus:border-violet-500/50 focus:bg-white/[0.05] transition-all"
 placeholder="••••••••••••"
 required
 />
 </div>
 </div>

 {error && (
 <motion.div 
 initial={{ opacity: 0 }}
 animate={{ opacity: 1 }}
 className="p-3 bg-red-500/10 border border-red-500/20 rounded-lg flex items-center space-x-2 text-red-400 text-sm"
 >
 <Fingerprint className="w-4 h-4" />
 <span>{error}</span>
 </motion.div>
 )}

 <button
 type="submit"
 disabled={isLoading}
 className="w-full relative group overflow-hidden rounded-xl p-[1px] mt-4"
 >
 <span className="absolute inset-0 bg-gradient-to-r from-violet-500 via-fuchsia-500 to-emerald-500 opacity-70 group-hover:opacity-100 transition-opacity duration-300"></span>
 <div className="relative flex items-center justify-center bg-black px-4 py-3.5 rounded-xl transition-all duration-300 group-hover:bg-opacity-0">
 <span className="font-semibold text-white tracking-wide mr-2 text-sm uppercase">
 {isLoading ? "Authenticating..." : (isLogin ? "Enter System" : "Initialize Account")}
 </span>
 {!isLoading && <ArrowRight className="w-4 h-4 text-white group-hover:translate-x-1 transition-transform" />}
 </div>
 </button>
 </form>

 <div className="mt-8 text-center">
 <button 
 type="button"
 onClick={() => setIsLogin(!isLogin)}
 className="text-sm text-white/40 hover:text-white transition-colors"
 >
 {isLogin ? "Need a master node? Sign up here." : "Already initialized? Log in."}
 </button>
 </div>
 </motion.div>
 </div>
 
 </div>
 );
}
