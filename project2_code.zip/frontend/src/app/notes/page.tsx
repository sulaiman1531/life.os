"use client";

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { fetchApi } from "@/lib/api";
import { FileText, Plus, Search, Trash2 } from "lucide-react";
import NoteEditor from "@/components/NoteEditor";

export default function NotesPage() {
 const queryClient = useQueryClient();
 const [activeNote, setActiveNote] = useState<any>(null);
 const [searchQuery, setSearchQuery] = useState("");

 const { data: notes = [] } = useQuery({
 queryKey: ["notes"],
 queryFn: () => fetchApi("/notes/"),
 });

 const addNote = useMutation({
 mutationFn: (newNote: any) => fetchApi("/notes/", {
 method: "POST",
 body: JSON.stringify(newNote)
 }),
 onSuccess: (data) => {
 queryClient.invalidateQueries({ queryKey: ["notes"] });
 setActiveNote(data); 
 },
 });

 const deleteNote = useMutation({
 mutationFn: (noteId: string) => fetchApi(`/notes/${noteId}`, {
 method: "DELETE"
 }),
 onSuccess: (_, deletedId) => {
 queryClient.invalidateQueries({ queryKey: ["notes"] });
 if (activeNote?.id === deletedId) {
 setActiveNote(null);
 }
 },
 });

 const handleCreateNote = () => {
 addNote.mutate({ title: "Untitled Note", content: "" });
 };

 const filteredNotes = notes.filter((note: any) => 
 note.title.toLowerCase().includes(searchQuery.toLowerCase())
 );

 return (
 <div className="flex h-full w-full animate-in fade-in duration-500">
 
 {/* Sidebar / Directory */}
 <div className="w-64 border-r border-white/10 pr-6 flex flex-col flex-shrink-0">
 <div className="flex items-center justify-between mb-6">
 <h2 className="text-xl font-bold tracking-tight">Notes</h2>
 <button 
 onClick={handleCreateNote} 
 disabled={addNote.isPending}
 className="p-1.5 rounded-md hover:bg-white/10 text-white/50 hover:text-white transition-colors"
 >
 <Plus className="w-4 h-4" />
 </button>
 </div>
 
 <div className="relative mb-6">
 <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
 <input 
 type="text" 
 placeholder="Search notes..." 
 value={searchQuery}
 onChange={(e) => setSearchQuery(e.target.value)}
 className="w-full bg-white/5 border border-white/10 rounded-lg py-1.5 pl-9 pr-3 text-sm focus:outline-none focus:border-violet-500/50 transition-colors"
 />
 </div>

 <div className="flex-1 overflow-y-auto space-y-1 scrollbar-none pr-2">
 {notes.length === 0 ? (
 <div className="text-xs text-white/30 text-center mt-4">No notes found.</div>
 ) : filteredNotes.length === 0 ? (
 <div className="text-xs text-white/30 text-center mt-4">No match for "{searchQuery}"</div>
 ) : (
 filteredNotes.map((note: any) => (
 <div 
 key={note.id}
 onClick={() => setActiveNote(note)}
 className={`group flex items-center justify-between px-3 py-2 rounded-lg cursor-pointer transition-colors ${activeNote?.id === note.id ? "bg-violet-500/20 text-violet-300" : "hover:bg-white/5 text-white/70"}`}
 >
 <div className="flex items-center space-x-3 overflow-hidden">
 <FileText className="w-3.5 h-3.5 flex-shrink-0" />
 <span className="text-sm truncate font-medium">{note.title}</span>
 </div>
 <button 
 onClick={(e) => {
 e.stopPropagation();
 deleteNote.mutate(note.id);
 }}
 className="opacity-0 group-hover:opacity-100 transition-opacity p-1 hover:text-red-400 hover:bg-red-500/10 rounded"
 >
 <Trash2 className="w-3.5 h-3.5 flex-shrink-0" />
 </button>
 </div>
 ))
 )}
 </div>
 </div>

 {/* Editor Area */}
 <div className="flex-1 pl-8 flex flex-col min-w-0 overflow-y-auto">
 {activeNote ? (
 <NoteEditor note={activeNote} />
 ) : (
 <div className="flex-1 flex flex-col items-center justify-center text-white/30">
 <FileText className="w-16 h-16 mb-4 opacity-20" />
 <p className="text-sm font-medium">Select a note to view</p>
 <p className="text-xs mt-1">Or create a new one to get started</p>
 </div>
 )}
 </div>
 
 </div>
 );
}
