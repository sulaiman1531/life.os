"use client";

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { fetchApi } from "@/lib/api";
import { Flame, Check, X, Plus } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function HabitsPage() {
 const queryClient = useQueryClient();
 const [isModalOpen, setIsModalOpen] = useState(false);
 const [newHabitName, setNewHabitName] = useState("");
 const [newHabitFreq, setNewHabitFreq] = useState("daily");

 const { data: habits = [] } = useQuery({
 queryKey: ["habits"],
 queryFn: () => fetchApi("/habits/"),
 });

 const addHabit = useMutation({
 mutationFn: (newHabit: any) => fetchApi("/habits/", {
 method: "POST",
 body: JSON.stringify(newHabit)
 }),
 onSuccess: () => {
 queryClient.invalidateQueries({ queryKey: ["habits"] });
 setIsModalOpen(false);
 setNewHabitName("");
 },
 });

 const logHabit = useMutation({
 mutationFn: (habitId: string) => fetchApi(`/habits/${habitId}/log`, {
 method: "POST"
 }),
 onSuccess: () => queryClient.invalidateQueries({ queryKey: ["habits"] }),
 });

 const handleAddSubmit = (e: React.FormEvent) => {
 e.preventDefault();
 if (newHabitName.trim()) {
 addHabit.mutate({ name: newHabitName, frequency: newHabitFreq });
 }
 };

 const days = Array.from({ length: 35 }).map(() => Math.random() > 0.4);

 return (
 <div className="flex flex-col h-full space-y-8 animate-in fade-in duration-500 relative">
 
 {/* Habit Modal */}
 <AnimatePresence>
 {isModalOpen && (
 <motion.div 
 initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
 className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4"
 >
 <motion.div 
 initial={{ scale: 0.95, opacity: 0, y: 20 }} animate={{ scale: 1, opacity: 1, y: 0 }} exit={{ scale: 0.95, opacity: 0, y: 20 }}
 className="w-full max-w-md bg-[#0A0A0A] border border-white/10 rounded-2xl p-6 shadow-2xl relative overflow-hidden"
 >
 <div className="absolute top-0 right-0 w-32 h-32 bg-orange-500/10 rounded-full blur-3xl"></div>
 
 <div className="flex justify-between items-center mb-6 relative z-10">
 <h3 className="text-xl font-bold flex items-center">
 <Flame className="w-5 h-5 text-orange-500 mr-2" />
 New Habit
 </h3>
 <button onClick={() => setIsModalOpen(false)} className="text-white/40 hover:text-white transition-colors">
 <X className="w-5 h-5" />
 </button>
 </div>

 <form onSubmit={handleAddSubmit} className="relative z-10 space-y-4">
 <div>
 <input 
 type="text" autoFocus required
 placeholder="e.g., Read 20 pages..."
 className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-white/30 focus:outline-none focus:border-orange-500/50 transition-colors"
 value={newHabitName}
 onChange={(e) => setNewHabitName(e.target.value)}
 />
 </div>
 <div>
 <select 
 className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-orange-500/50 transition-colors appearance-none"
 value={newHabitFreq}
 onChange={(e) => setNewHabitFreq(e.target.value)}
 >
 <option value="daily" className="bg-black">Daily</option>
 <option value="weekly" className="bg-black">Weekly</option>
 </select>
 </div>
 <button 
 type="submit" 
 disabled={addHabit.isPending}
 className="w-full bg-orange-600 hover:bg-orange-500 text-white font-semibold py-3 rounded-xl transition-colors mt-2"
 >
 {addHabit.isPending ? "Creating..." : "Track Habit"}
 </button>
 </form>
 </motion.div>
 </motion.div>
 )}
 </AnimatePresence>

 <div className="flex justify-between items-end">
 <div>
 <h1 className="text-3xl font-bold tracking-tight text-white mb-2">Habits & Routines</h1>
 <p className="text-white/50">Consistency is the baseline of greatness.</p>
 </div>
 <button onClick={() => setIsModalOpen(true)} className="flex items-center space-x-2 text-sm text-violet-400 bg-violet-500/10 hover:bg-violet-500/20 px-3 py-1.5 rounded-lg border border-violet-500/20 transition-colors">
 <Plus className="w-4 h-4" /> <span>Add Habit</span>
 </button>
 </div>

 <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
 
 {/* Main Habits List */}
 <div className="lg:col-span-2 space-y-4">
 
 <div className="flex items-center justify-between mb-4 px-2">
 <h3 className="text-sm font-semibold text-white/50 uppercase tracking-wider">Today's Protocol</h3>
 <span className="text-xs font-bold bg-white/10 px-2 py-1 rounded text-white">{habits.length} total</span>
 </div>

 <div className="space-y-3 max-h-[500px] overflow-y-auto scrollbar-none pr-2">
 {habits.length === 0 && <p className="text-sm text-white/40 px-2">No habits tracked yet.</p>}
 {habits.map((h: any) => (
 <div key={h.id} className={`glass-card p-4 rounded-2xl flex items-center justify-between border transition-all border-white/10 hover:border-white/20 group`}>
 <div className="flex items-center space-x-4">
 <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-xl bg-white/5`}>
 🔥
 </div>
 <div>
 <h4 className={`font-semibold text-white`}>{h.name}</h4>
 <div className="flex items-center mt-1 space-x-1.5 text-xs">
 <Flame className={`w-3 h-3 ${h.streak > 0 ? 'text-orange-500' : 'text-white/30'}`} />
 <span className={h.streak > 0 ? 'text-orange-400 font-bold' : 'text-white/30'}>{h.streak} Day Streak</span>
 </div>
 </div>
 </div>
 
 <button 
 onClick={() => logHabit.mutate(h.id)}
 disabled={logHabit.isPending}
 className={`w-8 h-8 rounded-full flex items-center justify-center border transition-all border-white/20 text-transparent hover:border-emerald-500 hover:text-emerald-500 focus:outline-none`}
 >
 <Check className="w-4 h-4 opacity-0 group-hover:opacity-100" />
 </button>
 </div>
 ))}
 </div>
 </div>

 {/* Heatmap / Stats */}
 <div className="lg:col-span-1 space-y-6">
 <div className="glass-card border border-white/10 p-6 rounded-2xl relative overflow-hidden">
 <div className="absolute top-0 right-0 -mr-8 -mt-8 w-32 h-32 bg-orange-500/10 rounded-full blur-2xl"></div>
 <h3 className="font-semibold mb-6 flex items-center">
 <Flame className="w-5 h-5 text-orange-500 mr-2" />
 Activity Heatmap
 </h3>
 <div className="grid grid-cols-7 gap-2">
 {days.map((active, i) => (
 <div 
 key={i} 
 className={`aspect-square rounded-sm ${active ? 'bg-orange-500' : 'bg-white/5'} transition-all hover:scale-110 cursor-pointer`}
 title={active ? 'Completed' : 'Missed'}
 />
 ))}
 </div>
 </div>
 </div>

 </div>
 </div>
 );
}
