import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { fetchApi } from "../api";

export interface Habit {
 id: string;
 user_id: string;
 name: string;
 frequency: string;
 streak: number;
 created_at: string;
}

export function useHabits() {
 return useQuery<Habit[]>({
 queryKey: ["habits"],
 queryFn: () => fetchApi("/habits/"),
 });
}

export function useLogHabit() {
 const queryClient = useQueryClient();
 
 return useMutation({
 mutationFn: (id: string) => 
 fetchApi(`/habits/${id}/log`, {
 method: "POST",
 }),
 onSuccess: () => {
 queryClient.invalidateQueries({ queryKey: ["habits"] });
 },
 });
}
