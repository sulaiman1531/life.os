import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { fetchApi } from "../api";

export interface Task {
 id: string;
 user_id: string;
 title: string;
 description?: string;
 status: "todo" | "in_progress" | "done";
 priority: "low" | "medium" | "high";
 due_date?: string;
 created_at: string;
}

export function useTasks() {
 return useQuery<Task[]>({
 queryKey: ["tasks"],
 queryFn: () => fetchApi("/tasks/"),
 });
}

export function useCreateTask() {
 const queryClient = useQueryClient();
 
 return useMutation({
 mutationFn: (newTask: Partial<Task>) => 
 fetchApi("/tasks/", {
 method: "POST",
 body: JSON.stringify(newTask),
 }),
 onSuccess: () => {
 queryClient.invalidateQueries({ queryKey: ["tasks"] });
 },
 });
}

export function useUpdateTask() {
 const queryClient = useQueryClient();
 
 return useMutation({
 mutationFn: ({ id, ...updateData }: Partial<Task> & { id: string }) => 
 fetchApi(`/tasks/${id}`, {
 method: "PUT",
 body: JSON.stringify(updateData),
 }),
 onSuccess: () => {
 queryClient.invalidateQueries({ queryKey: ["tasks"] });
 },
 });
}

export function useDeleteTask() {
 const queryClient = useQueryClient();
 
 return useMutation({
 mutationFn: (id: string) => 
 fetchApi(`/tasks/${id}`, {
 method: "DELETE",
 }),
 onSuccess: () => {
 queryClient.invalidateQueries({ queryKey: ["tasks"] });
 },
 });
}
