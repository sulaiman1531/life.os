const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000/api";

export async function fetchApi(endpoint: string, options: RequestInit = {}) {
 const token = typeof window !== "undefined" ? localStorage.getItem("token") : null;
 
 const headers = new Headers(options.headers || {});
 if (token) {
 headers.set("Authorization", `Bearer ${token}`);
 }
 
 if (!headers.has("Content-Type") && !(options.body instanceof FormData)) {
 headers.set("Content-Type", "application/json");
 }

 const response = await fetch(`${API_BASE_URL}${endpoint}`, {
 ...options,
 headers,
 });

 if (!response.ok) {
 const errorData = await response.json().catch(() => ({}));
 throw new Error(errorData.detail || "An error occurred while fetching data");
 }

 return response.json();
}
