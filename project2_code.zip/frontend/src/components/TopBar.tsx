"use client";

import { useState, useRef, useEffect } from "react";
import { Bell, Search, Command, CheckCircle2, User, Settings, LogOut, X, Target, Play, Pause, RotateCcw, Mic, MicOff, Bot, Loader2, Volume2 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useRouter } from "next/navigation";
import { fetchApi } from "@/lib/api";

export default function TopBar() {
 const router = useRouter();
 const [isNotifOpen, setIsNotifOpen] = useState(false);
 const [isProfileOpen, setIsProfileOpen] = useState(false);
 const [isFocused, setIsFocused] = useState(false);
 const [timeLeft, setTimeLeft] = useState(25 * 60);
 const [isActive, setIsActive] = useState(false);
 const [isListening, setIsListening] = useState(false);
 const [voiceResult, setVoiceResult] = useState("");
 const [isProcessing, setIsProcessing] = useState(false);
 const recognitionRef = useRef<any>(null);
 const dropdownRef = useRef<HTMLDivElement>(null);
 const profileRef = useRef<HTMLDivElement>(null);

 useEffect(() => {
 let interval: any = null;
 if (isActive && timeLeft > 0) {
 interval = setInterval(() => setTimeLeft((t) => t - 1), 1000);
 } else if (timeLeft === 0) {
 setIsActive(false);
 }
 return () => clearInterval(interval);
 }, [isActive, timeLeft]);

 const toggleFocusMode = () => {
 setIsFocused(!isFocused);
 if (!isFocused) {
 setTimeLeft(25 * 60);
 setIsActive(true);
 } else {
 setIsActive(false);
 }
 };

 const formatTime = (seconds: number) => {
 const m = Math.floor(seconds / 60);
 const s = seconds % 60;
 return `${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
 };

 useEffect(() => {
 // Initialize Global Speech Recognition
 const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
 if (SpeechRecognition) {
 recognitionRef.current = new SpeechRecognition();
 recognitionRef.current.continuous = false;
 recognitionRef.current.interimResults = false;

 recognitionRef.current.onresult = async (event: any) => {
 const transcript = event.results[0][0].transcript;
 setVoiceResult(transcript);
 setIsListening(false);
 setIsProcessing(true);
 
 try {
 const response = await fetchApi("/chat/", {
 method: "POST",
 body: JSON.stringify({ message: transcript })
 });
 
 setVoiceResult(response.response);
 
 // Speak the response
 if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
 const utterance = new SpeechSynthesisUtterance(response.response);
 window.speechSynthesis.speak(utterance);
 }
 
 setTimeout(() => {
 setIsProcessing(false);
 setVoiceResult("");
 }, 4000);
 
 } catch (e) {
 setVoiceResult("Sorry, I could not process that.");
 setTimeout(() => {
 setIsProcessing(false);
 setVoiceResult("");
 }, 3000);
 }
 };

 recognitionRef.current.onerror = (event: any) => {
 setIsListening(false);
 setVoiceResult("Error listening.");
 setTimeout(() => setVoiceResult(""), 2000);
 };

 recognitionRef.current.onend = () => {
 if (isListening) setIsListening(false);
 };
 }
 }, []);

 const toggleVoice = () => {
 if (isListening) {
 recognitionRef.current?.stop();
 setIsListening(false);
 } else {
 if (recognitionRef.current) {
 setVoiceResult("Listening...");
 recognitionRef.current.start();
 setIsListening(true);
 } else {
 alert("Speech Recognition is not supported in this browser.");
 }
 }
 };

 // Close when clicking outside
 useEffect(() => {
 function handleClickOutside(event: MouseEvent) {
 if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
 setIsNotifOpen(false);
 }
 if (profileRef.current && !profileRef.current.contains(event.target as Node)) {
 setIsProfileOpen(false);
 }
 }
 document.addEventListener("mousedown", handleClickOutside);
 return () => document.removeEventListener("mousedown", handleClickOutside);
 }, []);

 return (
 <>
 <header className="h-16 border-b border-white/10 bg-[#0A0A0A]/80 backdrop-blur-md flex items-center justify-between px-6 sticky top-0 z-20">
 {/* Global Search Hint */}
 <div className="flex-1 max-w-md">
 <motion.button 
 whileHover={{ scale: 1.02 }}
 whileTap={{ scale: 0.98 }}
 onClick={() => window.dispatchEvent(new CustomEvent("open-command-palette"))}
 className="w-full flex items-center space-x-3 px-4 py-2 bg-white/5 hover:bg-white/10 border border-white/10 rounded-full text-sm text-white/50 transition-colors shadow-sm"
 >
 <Search className="w-4 h-4" />
 <span>Search or jump to...</span>
 <div className="ml-auto flex items-center space-x-1 font-mono text-[10px] bg-white/10 px-1.5 py-0.5 rounded">
 <Command className="w-3 h-3" />
 <span>K</span>
 </div>
 </motion.button>
 </div>

 {/* Right side icons */}
 <div className="flex items-center space-x-4">
 
 {/* Global Voice Command Toggle */}
 <motion.button 
 whileHover={{ scale: 1.1, rotate: 5 }}
 whileTap={{ scale: 0.9 }}
 onClick={toggleVoice}
 className={`relative p-2 rounded-full transition-all ${isListening ? 'bg-blue-500/20 text-blue-400 shadow-[0_0_15px_rgba(59,130,246,0.3)]' : 'bg-white/5 hover:bg-white/10 text-white/50 hover:text-white'}`}
 title="Talk to Jarvis"
 >
 {isListening ? (
 <div className="relative">
 <Mic className="w-5 h-5 relative z-10 animate-pulse" />
 <div className="absolute inset-0 bg-blue-500/40 rounded-full animate-ping"></div>
 </div>
 ) : <Mic className="w-5 h-5" />}
 </motion.button>

 {/* Zenith Focus Toggle */}
 <motion.button 
 whileHover={{ scale: 1.05 }}
 whileTap={{ scale: 0.95 }}
 onClick={toggleFocusMode}
 className="bg-white/5 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider flex items-center transition-colors shadow-[0_0_15px_rgba(16,185,129,0.1)]"
 >
 <Target className="w-3 h-3 mr-2" />
 Focus Mode
 </motion.button>

 {/* Notifications */}
 <div className="relative" ref={dropdownRef}>
 <motion.button 
 whileHover={{ scale: 1.1, rotate: 10 }}
 whileTap={{ scale: 0.9 }}
 onClick={() => setIsNotifOpen(!isNotifOpen)}
 className="relative p-2 text-white/50 hover:text-white transition-colors rounded-full hover:bg-white/5"
 >
 <Bell className="w-5 h-5" />
 <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-violet-500 rounded-full border border-[#0A0A0A]"></span>
 </motion.button>

 <AnimatePresence>
 {isNotifOpen && (
 <motion.div
 initial={{ opacity: 0, y: 10, scale: 0.95 }}
 animate={{ opacity: 1, y: 0, scale: 1 }}
 exit={{ opacity: 0, y: 10, scale: 0.95 }}
 transition={{ duration: 0.15 }}
 className="absolute right-0 top-10 w-80 bg-[#121212] border border-white/10 rounded-xl shadow-2xl overflow-hidden z-50"
 >
 <div className="p-4 border-b border-white/10 bg-white/5">
 <h3 className="font-semibold text-white">Notifications</h3>
 </div>
 <div className="p-6 flex flex-col items-center justify-center text-center">
 <div className="w-12 h-12 bg-white/5 rounded-full flex items-center justify-center mb-3">
 <CheckCircle2 className="w-6 h-6 text-emerald-500" />
 </div>
 <p className="text-white font-medium">All caught up!</p>
 <p className="text-xs text-white/40 mt-1">You have no new notifications.</p>
 </div>
 </motion.div>
 )}
 </AnimatePresence>
 </div>

 {/* Profile */}
 <div className="relative" ref={profileRef}>
 <motion.div 
 whileHover={{ scale: 1.1 }}
 whileTap={{ scale: 0.9 }}
 onClick={() => setIsProfileOpen(!isProfileOpen)}
 className="w-8 h-8 rounded-full bg-gradient-to-br from-violet-500 to-fuchsia-500 border border-white/20 cursor-pointer shadow-[0_0_15px_rgba(139,92,246,0.3)]"
 ></motion.div>

 <AnimatePresence>
 {isProfileOpen && (
 <motion.div
 initial={{ opacity: 0, y: 10, scale: 0.95 }}
 animate={{ opacity: 1, y: 0, scale: 1 }}
 exit={{ opacity: 0, y: 10, scale: 0.95 }}
 transition={{ duration: 0.15 }}
 className="absolute right-0 top-10 w-48 bg-[#121212] border border-white/10 rounded-xl shadow-2xl overflow-hidden z-50 py-1"
 >
 <div className="px-4 py-3 border-b border-white/10 mb-1">
 <p className="text-sm font-medium text-white">Admin User</p>
 <p className="text-xs text-white/50 truncate">admin@lifeos.com</p>
 </div>
 
 <button 
 onClick={() => router.push("/settings")}
 className="w-full flex items-center space-x-2 px-4 py-2 text-sm text-white/70 hover:text-white hover:bg-white/5 transition-colors"
 >
 <Settings className="w-4 h-4" />
 <span>Settings</span>
 </button>
 <button 
 onClick={() => {
 localStorage.removeItem("token");
 router.push("/login");
 }}
 className="w-full flex items-center space-x-2 px-4 py-2 text-sm text-red-400 hover:text-red-300 hover:bg-red-500/10 transition-colors"
 >
 <LogOut className="w-4 h-4" />
 <span>Log out</span>
 </button>
 </motion.div>
 )}
 </AnimatePresence>
 </div>

 </div>
 </header>

 {/* Voice Overlay Feedback */}
 <AnimatePresence>
 {(isListening || isProcessing || voiceResult) && (
 <motion.div 
 initial={{ opacity: 0, y: -20 }}
 animate={{ opacity: 1, y: 0 }}
 exit={{ opacity: 0, y: -20 }}
 className="fixed top-20 left-1/2 -translate-x-1/2 z-50 bg-[#0A0A0A] border border-blue-500/30 shadow-[0_0_30px_rgba(59,130,246,0.15)] rounded-full px-6 py-3 flex items-center space-x-3"
 >
 {isProcessing ? (
 <Loader2 className="w-5 h-5 text-blue-400 animate-spin" />
 ) : isListening ? (
 <Mic className="w-5 h-5 text-blue-400 animate-pulse" />
 ) : (
 <Bot className="w-5 h-5 text-blue-400" />
 )}
 <span className="text-sm font-medium text-white max-w-md truncate">
 {voiceResult || "Waiting for command..."}
 </span>
 </motion.div>
 )}
 </AnimatePresence>

 {/* Deep Work Mode Overlay */}
 <AnimatePresence>
 {isFocused && (
 <motion.div 
 initial={{ opacity: 0 }}
 animate={{ opacity: 1 }}
 exit={{ opacity: 0 }}
 transition={{ duration: 1 }}
 className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-black overflow-hidden"
 >
 {/* Ambient Background */}
 <div className="absolute inset-0 z-0 opacity-40">
 <div className="absolute top-1/4 left-1/4 w-[500px] h-[500px] bg-violet-900/40 rounded-full blur-[120px] animate-pulse" style={{ animationDuration: '8s' }}></div>
 <div className="absolute bottom-1/4 right-1/4 w-[600px] h-[600px] bg-fuchsia-900/30 rounded-full blur-[150px] animate-pulse" style={{ animationDuration: '12s' }}></div>
 </div>

 <button 
 onClick={() => setIsFocused(false)}
 className="absolute top-8 right-8 z-20 p-4 rounded-full bg-white/5 hover:bg-white/10 text-white/50 hover:text-white transition-colors"
 >
 <X className="w-6 h-6" />
 </button>

 <motion.div 
 initial={{ scale: 0.8, opacity: 0 }}
 animate={{ scale: 1, opacity: 1 }}
 transition={{ delay: 0.5, duration: 1 }}
 className="relative z-10 text-center flex flex-col items-center"
 >
 <div className="flex items-center justify-center space-x-3 mb-6">
 <Target className="w-6 h-6 text-violet-400" />
 <h2 className="text-violet-400 font-bold tracking-widest uppercase text-lg">Deep Work Mode</h2>
 </div>
 
 <div className="text-[12rem] font-bold text-white font-mono leading-none tracking-tighter drop-shadow-[0_0_40px_rgba(139,92,246,0.3)]">
 {formatTime(timeLeft)}
 </div>
 
 <div className="flex items-center justify-center space-x-6 mt-12 mb-12">
 <button 
 onClick={() => setIsActive(!isActive)}
 className="w-16 h-16 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors shadow-lg"
 >
 {isActive ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6 ml-1" />}
 </button>
 <button 
 onClick={() => { setTimeLeft(25 * 60); setIsActive(false); }}
 className="w-12 h-12 rounded-full bg-white/5 hover:bg-white/10 text-white/50 hover:text-white flex items-center justify-center transition-colors"
 >
 <RotateCcw className="w-4 h-4" />
 </button>
 </div>

 <div className="flex flex-col items-center space-y-4">
 <div className="flex items-center space-x-2 text-emerald-400 bg-emerald-500/10 px-4 py-2 rounded-full border border-emerald-500/20">
 <Bell className="w-4 h-4" />
 <span className="text-sm font-medium">All notifications muted</span>
 </div>
 <p className="text-white/40 text-sm">Slack status automatically set to "In Deep Work 🔴"</p>
 </div>
 </motion.div>

 {/* YouTube Lo-Fi Embed */}
 <div className="absolute bottom-12 left-1/2 -translate-x-1/2 z-20 bg-black/50 backdrop-blur-xl p-4 rounded-2xl border border-white/10 flex items-center space-x-4 shadow-2xl">
 <div className="w-10 h-10 rounded-full bg-violet-500/20 flex items-center justify-center flex-shrink-0">
 <Volume2 className="w-5 h-5 text-violet-400 animate-pulse" />
 </div>
 <div className="pr-4">
 <p className="text-sm font-medium text-white">Lofi Girl - beats to relax/study to</p>
 <div className="flex items-center mt-1 space-x-2">
 <div className="w-32 h-1 bg-white/20 rounded-full overflow-hidden">
 <div className="w-2/3 h-full bg-violet-400"></div>
 </div>
 </div>
 </div>
 <div className="w-24 h-16 ml-4 rounded overflow-hidden opacity-30 hover:opacity-100 transition-opacity">
 <iframe 
 width="100%" 
 height="100%" 
 src="https://www.youtube.com/embed/jfKfPfyJRdk?autoplay=1&mute=0&controls=0&showinfo=0&rel=0&loop=1" 
 title="lofi hip hop radio" 
 frameBorder="0" 
 allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
 allowFullScreen
 ></iframe>
 </div>
 </div>
 </motion.div>
 )}
 </AnimatePresence>
 </>
 );
}
