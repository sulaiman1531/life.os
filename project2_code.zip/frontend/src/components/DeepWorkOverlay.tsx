"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Headphones, BrainCircuit, BellOff, Volume2 } from "lucide-react";

export default function DeepWorkOverlay({ isOpen, onClose }: { isOpen: boolean, onClose: () => void }) {
 const [timeLeft, setTimeLeft] = useState(25 * 60); // 25 minutes
 const [isActive, setIsActive] = useState(false);

 useEffect(() => {
 if (isOpen && !isActive) {
 setIsActive(true);
 // Pretend to update slack status
 fetch("http://localhost:8000/api/settings/", {
 method: "PUT",
 body: JSON.stringify({ deep_work_active: true })
 }).catch(e => console.log(e));
 }
 }, [isOpen, isActive]);

 useEffect(() => {
 let interval: NodeJS.Timeout;
 if (isActive && timeLeft > 0) {
 interval = setInterval(() => {
 setTimeLeft((prev) => prev - 1);
 }, 1000);
 } else if (timeLeft === 0) {
 setIsActive(false);
 }
 return () => clearInterval(interval);
 }, [isActive, timeLeft]);

 const handleClose = () => {
 setIsActive(false);
 onClose();
 };

 const minutes = Math.floor(timeLeft / 60);
 const seconds = timeLeft % 60;

 return (
 <AnimatePresence>
 {isOpen && (
 <motion.div
 initial={{ opacity: 0 }}
 animate={{ opacity: 1 }}
 exit={{ opacity: 0 }}
 transition={{ duration: 1 }}
 className="fixed inset-0 z-[100] bg-black flex flex-col items-center justify-center overflow-hidden"
 >
 {/* Ambient Background */}
 <div className="absolute inset-0 z-0 opacity-40">
 <div className="absolute top-1/4 left-1/4 w-[500px] h-[500px] bg-violet-900/40 rounded-full blur-[120px] animate-pulse" style={{ animationDuration: '8s' }}></div>
 <div className="absolute bottom-1/4 right-1/4 w-[600px] h-[600px] bg-fuchsia-900/30 rounded-full blur-[150px] animate-pulse" style={{ animationDuration: '12s' }}></div>
 </div>

 {/* YouTube Lo-Fi Embed (Hidden or small for audio, but let's make it a nice small player at the bottom) */}
 <div className="absolute bottom-12 left-1/2 -translate-x-1/2 z-20 glass-card p-4 rounded-2xl border border-white/10 flex items-center space-x-4 bg-black/50 backdrop-blur-xl">
 <Headphones className="w-6 h-6 text-violet-400 animate-pulse" />
 <div>
 <p className="text-sm font-medium text-white">Lofi Girl - beats to relax/study to</p>
 <div className="flex items-center mt-1 space-x-2">
 <Volume2 className="w-3 h-3 text-white/50" />
 <div className="w-32 h-1 bg-white/20 rounded-full overflow-hidden">
 <div className="w-2/3 h-full bg-violet-400"></div>
 </div>
 </div>
 </div>
 <div className="w-24 h-16 ml-4 rounded overflow-hidden opacity-50 hover:opacity-100 transition-opacity">
 <iframe 
 width="100%" 
 height="100%" 
 src="https://www.youtube.com/embed/jfKfPfyJRdk?autoplay=1&mute=0&controls=0&showinfo=0&rel=0&loop=1" 
 title="lofi hip hop radio" 
 frameBorder="0" 
 allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
 allowFullScreen
 ></iframe>
 </div>
 </div>

 <button 
 onClick={handleClose}
 className="absolute top-8 right-8 z-20 p-4 rounded-full bg-white/5 hover:bg-white/10 text-white/50 hover:text-white transition-colors"
 >
 <X className="w-6 h-6" />
 </button>

 <div className="relative z-10 flex flex-col items-center">
 <motion.div 
 initial={{ scale: 0.8, opacity: 0 }}
 animate={{ scale: 1, opacity: 1 }}
 transition={{ delay: 0.5, duration: 1 }}
 className="text-center"
 >
 <div className="flex items-center justify-center space-x-3 mb-6">
 <BrainCircuit className="w-8 h-8 text-violet-400" />
 <h1 className="text-2xl font-bold tracking-widest uppercase text-white/80">Deep Work Mode</h1>
 </div>

 <div className="font-mono text-[12rem] leading-none font-bold text-white tracking-tighter drop-shadow-[0_0_40px_rgba(139,92,246,0.3)]">
 {minutes.toString().padStart(2, '0')}:{seconds.toString().padStart(2, '0')}
 </div>

 <div className="mt-12 flex flex-col items-center space-y-4">
 <div className="flex items-center space-x-2 text-emerald-400 bg-emerald-500/10 px-4 py-2 rounded-full border border-emerald-500/20">
 <BellOff className="w-4 h-4" />
 <span className="text-sm font-medium">All notifications muted</span>
 </div>
 <p className="text-white/40 text-sm">Slack status automatically set to "In Deep Work 🔴"</p>
 </div>
 </motion.div>
 </div>
 </motion.div>
 )}
 </AnimatePresence>
 );
}
