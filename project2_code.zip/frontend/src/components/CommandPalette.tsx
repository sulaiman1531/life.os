"use client";

import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Search, Loader2, Check, Sparkles } from "lucide-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { fetchApi } from "@/lib/api";

export default function CommandPalette() {
 const [isOpen, setIsOpen] = useState(false);
 const [query, setQuery] = useState("");
 const [status, setStatus] = useState<"idle" | "processing" | "success">("idle");
 const inputRef = useRef<HTMLInputElement>(null);
 const queryClient = useQueryClient();

 useEffect(() => {
 const down = (e: KeyboardEvent) => {
 if (e.key === "k" && (e.metaKey || e.ctrlKey)) {
 e.preventDefault();
 setIsOpen((open) => !open);
 }
 if (e.key === "Escape") {
 setIsOpen(false);
 }
 };
 document.addEventListener("keydown", down);
 return () => document.removeEventListener("keydown", down);
 }, []);

 useEffect(() => {
 if (isOpen) {
 setTimeout(() => inputRef.current?.focus(), 100);
 setQuery("");
 setStatus("idle");
 }
 }, [isOpen]);

 const processCommand = useMutation({
 mutationFn: async (text: string) => {
 // Create a task instantly
 return fetchApi("/tasks/", {
 method: "POST",
 body: JSON.stringify({
 title: text,
 duration: 30,
 completed: false
 })
 });
 },
 onSuccess: () => {
 queryClient.invalidateQueries({ queryKey: ["tasks"] });
 setStatus("success");
 setTimeout(() => setIsOpen(false), 1500);
 }
 });

 const handleSubmit = (e: React.FormEvent) => {
 e.preventDefault();
 if (!query.trim()) return;
 setStatus("processing");
 processCommand.mutate(query);
 };

 return (
 <AnimatePresence>
 {isOpen && (
 <>
 {/* Backdrop */}
 <motion.div
 initial={{ opacity: 0 }}
 animate={{ opacity: 1 }}
 exit={{ opacity: 0 }}
 onClick={() => setIsOpen(false)}
 className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-start justify-center pt-[20vh]"
 >
 {/* Palette */}
 <motion.div
 initial={{ opacity: 0, y: -20, scale: 0.95 }}
 animate={{ opacity: 1, y: 0, scale: 1 }}
 exit={{ opacity: 0, y: -20, scale: 0.95 }}
 transition={{ duration: 0.2 }}
 onClick={(e) => e.stopPropagation()}
 className="w-full max-w-2xl bg-[#0A0A0A]/80 backdrop-blur-2xl border border-white/10 rounded-2xl shadow-[0_20px_60px_rgba(0,0,0,0.5)] overflow-hidden relative"
 >
 {/* Animated glow */}
 <div className="absolute -top-32 -left-32 w-64 h-64 bg-violet-500/20 rounded-full blur-[80px] pointer-events-none" />
 <div className="absolute -bottom-32 -right-32 w-64 h-64 bg-blue-500/20 rounded-full blur-[80px] pointer-events-none" />
 
 <form onSubmit={handleSubmit} className="relative flex items-center px-6 py-5 border-b border-white/10 z-10">
 {status === "idle" && <Sparkles className="w-5 h-5 text-violet-400 mr-3" />}
 {status === "processing" && <Loader2 className="w-5 h-5 text-violet-400 mr-3 animate-spin" />}
 {status === "success" && <Check className="w-5 h-5 text-emerald-400 mr-3" />}
 
 <input
 ref={inputRef}
 type="text"
 value={query}
 onChange={(e) => setQuery(e.target.value)}
 placeholder="Ask Jarvis to do something, or brain dump a task..."
 disabled={status !== "idle"}
 className="flex-1 bg-transparent border-none outline-none text-white text-lg placeholder-white/30"
 />
 
 <div className="flex items-center space-x-2 ml-4">
 <span className="text-xs font-mono bg-white/10 text-white/50 px-2 py-1 rounded">esc</span>
 <span className="text-xs font-mono bg-white/10 text-white/50 px-2 py-1 rounded">↵</span>
 </div>
 </form>

 <div className="p-4 relative z-10">
 <div className="text-xs font-semibold text-white/40 uppercase tracking-wider mb-3">Suggestions</div>
 <div className="space-y-1">
 <button onClick={() => setQuery("Remind me to call John at 5pm")} className="w-full text-left px-3 py-2 rounded-lg text-white/70 hover:bg-white/10 hover:text-white transition-colors text-sm">
 "Remind me to call John at 5pm"
 </button>
 <button onClick={() => setQuery("Schedule 2 hours of deep work for tomorrow")} className="w-full text-left px-3 py-2 rounded-lg text-white/70 hover:bg-white/10 hover:text-white transition-colors text-sm">
 "Schedule 2 hours of deep work for tomorrow"
 </button>
 <button onClick={() => setQuery("Email Sarah the Q3 report")} className="w-full text-left px-3 py-2 rounded-lg text-white/70 hover:bg-white/10 hover:text-white transition-colors text-sm">
 "Email Sarah the Q3 report"
 </button>
 </div>
 </div>
 </motion.div>
 </motion.div>
 </>
 )}
 </AnimatePresence>
 );
}
