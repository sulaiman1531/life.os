"use client";

import { useEffect, useState } from "react";
import { useRouter, usePathname } from "next/navigation";
import { Loader2 } from "lucide-react";
import { AnimatePresence } from "framer-motion";
import Sidebar from "@/components/Sidebar";
import TopBar from "@/components/TopBar";
import CommandPalette from "@/components/CommandPalette";
import NotificationPanel from "@/components/NotificationPanel";
import FloatingJarvis from "@/components/FloatingJarvis";
import OnboardingOverlay from "@/components/OnboardingOverlay";

export default function ProtectedRoute({ children }: { children: React.ReactNode }) {
 const router = useRouter();
 const pathname = usePathname();
 const [isChecking, setIsChecking] = useState(true);
 const [showOnboarding, setShowOnboarding] = useState(false);

 useEffect(() => {
 const token = localStorage.getItem("token");
 const role = localStorage.getItem("role") || "employee";
 
 if (!token && pathname !== "/login") {
 router.push("/login");
 } else if (token && pathname === "/" && role === "employer") {
 router.push("/employer");
 } else {
 setIsChecking(false);
 
 // Check onboarding
 if (token && !localStorage.getItem("hasSeenOnboarding")) {
 setShowOnboarding(true);
 }
 }
 }, [pathname, router]);

 const handleOnboardingComplete = () => {
 localStorage.setItem("hasSeenOnboarding", "true");
 setShowOnboarding(false);
 };

 if (isChecking) {
 return (
 <div className="min-h-screen flex items-center justify-center bg-[#0A0A0A]">
 <Loader2 className="w-8 h-8 animate-spin text-primary" />
 </div>
 );
 }

 if (pathname === "/login") {
 return <>{children}</>;
 }

 return (
 <>
 <AnimatePresence>
 {showOnboarding && <OnboardingOverlay onComplete={handleOnboardingComplete} />}
 </AnimatePresence>
 <div className="flex h-screen w-full overflow-hidden">
 {pathname !== "/employer" && <Sidebar />}
 <div className="flex flex-col flex-1 min-w-0 overflow-hidden relative">
 <TopBar />
 <main className="flex-1 overflow-y-auto p-6 md:p-8 relative">
 {children}
 </main>
 </div>
 {pathname !== "/employer" && (
 <>
 <NotificationPanel />
 <FloatingJarvis />
 <CommandPalette />
 </>
 )}
 </div>
 </>
 );
}
