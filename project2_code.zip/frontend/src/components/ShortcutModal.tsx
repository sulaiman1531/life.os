"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Command, X } from "lucide-react";
import { useRouter } from "next/navigation";

export default function ShortcutModal() {
 const [isOpen, setIsOpen] = useState(false);
 const router = useRouter();

 useEffect(() => {
 const handleKeyDown = (e: KeyboardEvent) => {
 // Don't trigger if user is typing in an input/textarea
 if (
 document.activeElement?.tagName === "INPUT" ||
 document.activeElement?.tagName === "TEXTAREA" ||
 (document.activeElement as HTMLElement)?.isContentEditable
 ) {
 return;
 }

 switch (e.key.toLowerCase()) {
 case "?":
 e.preventDefault();
 setIsOpen((prev) => !prev);
 break;
 case "d":
 if (e.ctrlKey || e.metaKey) return;
 e.preventDefault();
 router.push("/");
 break;
 case "t":
 if (e.ctrlKey || e.metaKey) return;
 e.preventDefault();
 router.push("/tasks");
 break;
 case "n":
 if (e.ctrlKey || e.metaKey) return;
 e.preventDefault();
 router.push("/notes");
 break;
 case "escape":
 setIsOpen(false);
 break;
 }
 };

 window.addEventListener("keydown", handleKeyDown);
 return () => window.removeEventListener("keydown", handleKeyDown);
 }, [router]);

 return (
 <AnimatePresence>
 {isOpen && (
 <motion.div
 initial={{ opacity: 0 }}
 animate={{ opacity: 1 }}
 exit={{ opacity: 0 }}
 className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/60 backdrop-blur-sm p-4"
 onClick={() => setIsOpen(false)}
 >
 <motion.div
 initial={{ scale: 0.95, opacity: 0, y: 20 }}
 animate={{ scale: 1, opacity: 1, y: 0 }}
 exit={{ scale: 0.95, opacity: 0, y: 20 }}
 onClick={(e) => e.stopPropagation()}
 className="w-full max-w-lg bg-[#0A0A0A]/90 border border-white/10 rounded-2xl shadow-[0_20px_60px_rgba(0,0,0,0.5)] overflow-hidden"
 >
 <div className="flex justify-between items-center p-6 border-b border-white/10">
 <h3 className="text-xl font-bold flex items-center">
 <Command className="w-5 h-5 mr-2 text-violet-400" />
 Keyboard Shortcuts
 </h3>
 <button onClick={() => setIsOpen(false)} className="text-white/40 hover:text-white transition-colors">
 <X className="w-5 h-5" />
 </button>
 </div>

 <div className="p-6 space-y-6">
 <ShortcutSection title="Navigation" shortcuts={[
 { key: "D", description: "Go to Dashboard" },
 { key: "T", description: "Go to Tasks" },
 { key: "N", description: "Go to Notes" },
 ]} />
 
 <ShortcutSection title="Actions" shortcuts={[
 { key: "Ctrl + K", description: "Open Command Palette" },
 { key: "?", description: "Toggle this help menu" },
 ]} />
 </div>
 </motion.div>
 </motion.div>
 )}
 </AnimatePresence>
 );
}

function ShortcutSection({ title, shortcuts }: { title: string, shortcuts: { key: string, description: string }[] }) {
 return (
 <div>
 <h4 className="text-xs font-bold text-white/40 uppercase tracking-wider mb-3">{title}</h4>
 <div className="space-y-2">
 {shortcuts.map((s, i) => (
 <div key={i} className="flex justify-between items-center bg-white/5 px-4 py-2 rounded-lg border border-white/5">
 <span className="text-sm text-white/80">{s.description}</span>
 <span className="text-xs font-mono font-bold bg-white/10 text-violet-300 px-2 py-1 rounded shadow-inner">
 {s.key}
 </span>
 </div>
 ))}
 </div>
 </div>
 );
}
