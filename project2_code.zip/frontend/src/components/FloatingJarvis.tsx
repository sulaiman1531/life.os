"use client";

import { useState, useEffect, useRef } from "react";
import { Send, Bot, User, Mic, MicOff, Globe, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useQueryClient } from "@tanstack/react-query";
import { fetchApi } from "@/lib/api";
import { motion, AnimatePresence } from "framer-motion";

type Message = {
 id: string;
 role: "user" | "ai";
 content: string;
};

export default function FloatingJarvis() {
 const [isOpen, setIsOpen] = useState(false);
 const [messages, setMessages] = useState<Message[]>([
 { id: "1", role: "ai", content: "Hello! I am Jarvis. How can I assist you today?" }
 ]);
 const [input, setInput] = useState("");
 const [isLoading, setIsLoading] = useState(false);
 const [isListening, setIsListening] = useState(false);
 const [speechLanguage, setSpeechLanguage] = useState("en-US");
 const recognitionRef = useRef<any>(null);
 const queryClient = useQueryClient();
 const messagesEndRef = useRef<HTMLDivElement>(null);

 const playSound = () => {
 try {
 const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
 const oscillator = audioCtx.createOscillator();
 const gainNode = audioCtx.createGain();
 
 oscillator.type = "sine";
 oscillator.frequency.setValueAtTime(880, audioCtx.currentTime); // A5
 oscillator.frequency.exponentialRampToValueAtTime(1760, audioCtx.currentTime + 0.1); // A6
 
 gainNode.gain.setValueAtTime(0, audioCtx.currentTime);
 gainNode.gain.linearRampToValueAtTime(0.1, audioCtx.currentTime + 0.05);
 gainNode.gain.linearRampToValueAtTime(0, audioCtx.currentTime + 0.3);
 
 oscillator.connect(gainNode);
 gainNode.connect(audioCtx.destination);
 
 oscillator.start();
 oscillator.stop(audioCtx.currentTime + 0.3);
 } catch (e) {
 console.warn("Audio not supported or blocked");
 }
 };

 useEffect(() => {
 if (messagesEndRef.current) {
 messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
 }
 }, [messages, isLoading]);

 useEffect(() => {
 // Request notification permission on mount
 if ("Notification" in window && Notification.permission === "default") {
 Notification.requestPermission();
 }
 
 // Initialize Speech Recognition if supported
 const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
 if (SpeechRecognition) {
 recognitionRef.current = new SpeechRecognition();
 recognitionRef.current.continuous = false;
 recognitionRef.current.interimResults = false;

 recognitionRef.current.onresult = (event: any) => {
 const transcript = event.results[0][0].transcript;
 setInput(transcript);
 setIsListening(false);
 };

 recognitionRef.current.onerror = (event: any) => {
 console.error("Speech recognition error", event.error);
 setIsListening(false);
 };

 recognitionRef.current.onend = () => {
 setIsListening(false);
 };
 }
 }, []);

 // Proactive Morning Briefing
 useEffect(() => {
 const today = new Date().toDateString();
 const lastGreeting = localStorage.getItem("last_greeting_date");
 
 if (lastGreeting !== today) {
 // It's the first login of the day!
 const timer = setTimeout(() => {
 localStorage.setItem("last_greeting_date", today);
 setIsOpen(true);
 const greeting = "Good morning, sir. I have synced your workspace and your focus time is scheduled. Shall we begin?";
 setMessages([{ id: Date.now().toString(), role: "assistant", content: greeting }]);
 speak(greeting);
 }, 3000); // Wait 3 seconds after load to surprise them
 
 return () => clearTimeout(timer);
 }
 }, []);

 const speak = (text: string) => {
 if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
 const utterance = new SpeechSynthesisUtterance(text);
 window.speechSynthesis.speak(utterance);
 }
 };

 const toggleListening = () => {
 if (isListening) {
 recognitionRef.current?.stop();
 } else {
 if (recognitionRef.current) {
 recognitionRef.current.lang = speechLanguage;
 recognitionRef.current.start();
 setIsListening(true);
 } else {
 alert("Speech Recognition is not supported in this browser.");
 }
 }
 };

 const handleSend = async (e: React.FormEvent) => {
 e.preventDefault();
 if (!input.trim()) return;

 const userMessage: Message = {
 id: Date.now().toString(),
 role: "user",
 content: input.trim()
 };
 
 setMessages(prev => [...prev, userMessage]);
 setInput("");
 setIsLoading(true);

 try {
 const response = await fetchApi("/chat/", {
 method: "POST",
 body: JSON.stringify({ message: userMessage.content })
 });

 const aiMessage: Message = {
 id: (Date.now() + 1).toString(),
 role: "ai",
 content: response.response
 };
 
 setMessages(prev => [...prev, aiMessage]);

 // If document is hidden, play sound and show notification
 if (document.hidden) {
 playSound();
 if ("Notification" in window && Notification.permission === "granted") {
 new Notification("Jarvis", { body: response.response, icon: "/favicon.ico" });
 }
 }

 if (response.action_taken === "task_created") {
 queryClient.invalidateQueries({ queryKey: ["tasks"] });
 }

 } catch (error) {
 console.error("Chat error", error);
 setMessages(prev => [...prev, {
 id: (Date.now() + 1).toString(),
 role: "ai",
 content: "Sorry, I ran into an error processing that."
 }]);
 } finally {
 setIsLoading(false);
 }
 };

 return (
 <>
 {/* Floating Toggle Button */}
 <button 
 onClick={() => setIsOpen(!isOpen)}
 className={`fixed bottom-8 right-8 w-14 h-14 rounded-full flex items-center justify-center shadow-2xl transition-all z-50 ${isOpen ? 'bg-white/10 text-white hover:bg-white/20' : 'bg-gradient-to-r from-blue-500 to-indigo-600 text-white hover:shadow-[0_0_20px_rgba(59,130,246,0.5)] hover:scale-105'}`}
 >
 {isOpen ? <X className="w-6 h-6" /> : <Bot className="w-6 h-6" />}
 </button>

 {/* Slide-out Chat Panel */}
 <AnimatePresence>
 {isOpen && (
 <motion.div
 initial={{ opacity: 0, y: 20, scale: 0.95 }}
 animate={{ opacity: 1, y: 0, scale: 1 }}
 exit={{ opacity: 0, y: 20, scale: 0.95 }}
 transition={{ type: "spring", stiffness: 300, damping: 25 }}
 className="fixed bottom-28 right-8 w-[380px] h-[550px] z-40 flex flex-col bg-[#0A0A0A] rounded-2xl shadow-2xl border border-white/10 overflow-hidden"
 >
 {/* Header */}
 <div className="p-4 border-b border-white/10 flex items-center justify-between bg-white/5 relative overflow-hidden">
 <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/20 rounded-full blur-3xl -mr-16 -mt-16"></div>
 
 <div className="flex items-center space-x-3 relative z-10">
 <Bot className="text-blue-400 w-5 h-5" />
 <h3 className="font-bold text-md text-white tracking-wide">Jarvis <span className="text-[10px] bg-blue-500/20 text-blue-400 px-1.5 py-0.5 rounded ml-1">BETA</span></h3>
 </div>
 
 {/* Language Selector */}
 <div className="flex items-center space-x-2 relative z-10">
 <Globe className="w-4 h-4 text-white/50" />
 <select 
 value={speechLanguage} 
 onChange={(e) => setSpeechLanguage(e.target.value)}
 className="bg-transparent text-xs text-white/70 outline-none cursor-pointer appearance-none"
 >
 <option value="en-US" className="bg-[#121212]">English</option>
 <option value="hi-IN" className="bg-[#121212]">Hindi</option>
 <option value="te-IN" className="bg-[#121212]">Telugu</option>
 <option value="mr-IN" className="bg-[#121212]">Marathi</option>
 </select>
 </div>
 </div>

 {/* Messages */}
 <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gradient-to-b from-black to-[#050505]">
 {messages.map((msg) => (
 <div key={msg.id} className={`flex items-start space-x-3 ${msg.role === "user" ? "flex-row-reverse space-x-reverse" : ""}`}>
 <div className={`p-1.5 rounded-full flex-shrink-0 ${msg.role === "user" ? "bg-white text-black" : "bg-blue-500/20 text-blue-400"}`}>
 {msg.role === "user" ? <User className="w-3.5 h-3.5" /> : <Bot className="w-3.5 h-3.5" />}
 </div>
 <div className={`p-3 rounded-2xl max-w-[80%] ${msg.role === "user" ? "bg-white text-black rounded-tr-sm" : "bg-white/10 text-white rounded-tl-sm border border-white/5 shadow-lg"}`}>
 <p className="text-sm leading-relaxed">{msg.content}</p>
 </div>
 </div>
 ))}
 {isLoading && (
 <div className="flex items-start space-x-3">
 <div className="p-1.5 rounded-full flex-shrink-0 bg-blue-500/20 text-blue-400">
 <Bot className="w-3.5 h-3.5" />
 </div>
 <div className="p-4 rounded-2xl bg-white/10 border border-white/5 rounded-tl-sm flex items-center space-x-1.5 shadow-lg">
 <div className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-bounce"></div>
 <div className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-bounce" style={{animationDelay: '0.15s'}}></div>
 <div className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-bounce" style={{animationDelay: '0.3s'}}></div>
 </div>
 </div>
 )}
 <div ref={messagesEndRef} />
 </div>

 {/* Input Form */}
 <form onSubmit={handleSend} className="p-3 border-t border-white/10 bg-[#0A0A0A] flex items-center space-x-2">
 <button
 type="button"
 onClick={toggleListening}
 className={`p-2 rounded-full transition-colors flex-shrink-0 ${isListening ? 'bg-red-500/20 text-red-400 animate-pulse' : 'bg-white/5 text-white/50 hover:bg-white/10 hover:text-white'}`}
 title="Voice Command"
 >
 {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
 </button>

 <input 
 type="text" 
 placeholder={isListening ? "Listening..." : "Ask Jarvis..."}
 className="flex-1 bg-white/5 rounded-full px-4 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500/50 transition-all border border-white/10 text-white placeholder-white/40"
 value={input}
 onChange={(e) => setInput(e.target.value)}
 disabled={isLoading || isListening}
 />
 <Button type="submit" size="icon" className="rounded-full bg-blue-600 text-white hover:bg-blue-500 flex-shrink-0 w-9 h-9" disabled={!input.trim() || isLoading}>
 <Send className="w-3.5 h-3.5" />
 </Button>
 </form>
 </motion.div>
 )}
 </AnimatePresence>
 </>
 );
}
