"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
 LayoutDashboard, CheckSquare, BookOpen, Calendar,
 Target, Repeat2, DollarSign, Heart, GraduationCap,
 FolderOpen, Bot, Settings, LogOut, ChevronLeft, ChevronRight,
 Sparkles, Mail, Inbox, Flame, BarChart3, Zap
} from "lucide-react";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { fetchApi } from "@/lib/api";
import { motion } from "framer-motion";

const navItems = [
 { label: "Dashboard", icon: LayoutDashboard, href: "/" },
 { label: "AI Assistant", icon: Bot, href: "/ai", badge: "AI" },
 { label: "Automations", icon: Zap, href: "/automations" },
 { label: "Workspace", icon: Inbox, href: "/workspace" },
 { label: "Analytics", icon: BarChart3, href: "/analytics" },
 { label: "Tasks", icon: CheckSquare, href: "/tasks" },
 { label: "Planner", icon: Calendar, href: "/planner" },
 { label: "Notes", icon: BookOpen, href: "/notes" },
 { label: "Projects", icon: FolderOpen, href: "/projects" },
];

export default function Sidebar() {
 const pathname = usePathname();
 const router = useRouter();
 const [collapsed, setCollapsed] = useState(false);

 const { data: preferences = {} } = useQuery({
 queryKey: ["settings"],
 queryFn: () => fetchApi("/settings/"),
 });

 const xp = preferences.xp || 0;
 const level = Math.floor(xp / 100) + 1;
 const xpProgress = xp % 100;

 const handleLogout = () => {
 localStorage.removeItem("token");
 router.push("/login");
 };

 return (
 <aside
 className={`relative flex flex-col h-screen bg-[#0A0A0A] border-r border-white/10 transition-all duration-300 ease-in-out ${
 collapsed ? "w-[68px]" : "w-[240px]"
 } flex-shrink-0`}
 >
 {/* Logo */}
 <div className={`flex items-center px-4 h-16 border-b border-white/10 ${collapsed ? "justify-center" : "justify-between"}`}>
 {!collapsed && (
 <div className="flex items-center space-x-2">
 <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-[#A855F7] to-[#3B82F6] flex items-center justify-center flex-shrink-0">
 <Sparkles className="w-4 h-4 text-white" />
 </div>
 <span className="font-bold text-sm tracking-wide text-white">LIFE OS</span>
 </div>
 )}
 {collapsed && (
 <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-[#A855F7] to-[#3B82F6] flex items-center justify-center">
 <Sparkles className="w-4 h-4 text-white" />
 </div>
 )}
 <button
 onClick={() => setCollapsed(!collapsed)}
 className={`p-1.5 rounded-lg hover:bg-white/5 text-white/30 hover:text-white transition-all ${collapsed ? "absolute -right-3 top-5 bg-[#0A0A0A] border border-white/10 rounded-full z-10" : ""}`}
 >
 {collapsed ? <ChevronRight className="w-3 h-3" /> : <ChevronLeft className="w-3 h-3" />}
 </button>
 </div>

 {/* Nav items */}
 <nav className="flex-1 overflow-y-auto py-4 space-y-0.5 px-2 scrollbar-none">
 {navItems.map(({ label, icon: Icon, href, badge }) => {
 const active = pathname === href;
 return (
 <Link key={href} href={href} legacyBehavior>
 <motion.a
 whileHover={{ scale: 1.02, x: collapsed ? 0 : 4 }}
 whileTap={{ scale: 0.98 }}
 className={`flex items-center rounded-lg transition-colors duration-200 group relative overflow-hidden cursor-pointer
 ${collapsed ? "justify-center p-2" : "px-3 py-2 space-x-3"}
 ${active
 ? "text-white"
 : "text-white/40 hover:text-white hover:bg-white/5"
 }`}
 >
 {/* Animated active background */}
 {active && (
 <motion.div 
 layoutId="sidebar-active"
 className="absolute inset-0 bg-white/10 rounded-lg"
 transition={{ type: "spring", stiffness: 300, damping: 30 }}
 />
 )}

 <Icon className={`w-4 h-4 flex-shrink-0 relative z-10 ${active ? "text-white" : ""}`} />
 {!collapsed && (
 <>
 <span className="text-sm font-medium relative z-10">{label}</span>
 {badge && (
 <span className="ml-auto text-[10px] font-bold px-1.5 py-0.5 rounded bg-[#A855F7]/20 text-[#A855F7] border border-[#A855F7]/30 relative z-10">
 {badge}
 </span>
 )}
 </>
 )}
 {/* Active left indicator */}
 {active && (
 <motion.span 
 layoutId="sidebar-indicator"
 className="absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-5 bg-[#A855F7] rounded-r z-10" 
 />
 )}
 </motion.a>
 </Link>
 );
 })}
 </nav>

 {/* Bottom section spacing if needed, XP removed */}
 <div className="flex-1"></div>

 <div className="border-t border-white/10 p-2 space-y-0.5">
 <Link href="/settings" className={`flex items-center rounded-lg text-white/40 hover:text-white hover:bg-white/5 transition-all ${collapsed ? "justify-center p-2" : "px-3 py-2 space-x-3"}`}>
 <Settings className="w-4 h-4 flex-shrink-0" />
 {!collapsed && <span className="text-sm font-medium">Settings</span>}
 </Link>
 <button
 onClick={handleLogout}
 className={`w-full flex items-center rounded-lg text-white/40 hover:text-red-400 hover:bg-red-500/10 transition-all ${collapsed ? "justify-center p-2" : "px-3 py-2 space-x-3"}`}
 >
 <LogOut className="w-4 h-4 flex-shrink-0" />
 {!collapsed && <span className="text-sm font-medium">Log Out</span>}
 </button>
 </div>
 </aside>
 );
}
