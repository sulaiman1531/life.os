"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Fingerprint, CheckCircle2, Sparkles } from "lucide-react";

export default function OnboardingOverlay({ onComplete }: { onComplete: () => void }) {
 const [step, setStep] = useState(0);

 useEffect(() => {
 // Cinematic sequence
 const t1 = setTimeout(() => setStep(1), 2000); // Bio scan complete
 const t2 = setTimeout(() => setStep(2), 4000); // Workspace initialization
 const t3 = setTimeout(() => setStep(3), 6500); // Final welcome
 const t4 = setTimeout(() => onComplete(), 9000); // Done

 return () => {
 clearTimeout(t1);
 clearTimeout(t2);
 clearTimeout(t3);
 clearTimeout(t4);
 };
 }, [onComplete]);

 return (
 <AnimatePresence>
 <motion.div 
 className="fixed inset-0 z-[99999] bg-[#0A0A0A] flex flex-col items-center justify-center overflow-hidden"
 initial={{ opacity: 1 }}
 exit={{ opacity: 0, transition: { duration: 1.5, ease: "easeInOut" } }}
 >
 {/* Abstract Background Elements */}
 <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-violet-600/20 rounded-full blur-[120px] pointer-events-none mix-blend-screen" />
 <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-blue-600/20 rounded-full blur-[100px] pointer-events-none mix-blend-screen" />
 
 {/* Grid lines */}
 <div className="absolute inset-0 bg-[url('/grid.svg')] bg-center opacity-10 pointer-events-none" />

 <div className="relative z-10 flex flex-col items-center">
 {/* Step 0 & 1: Bio-Scan */}
 <AnimatePresence mode="wait">
 {step < 2 && (
 <motion.div 
 key="bioscan"
 initial={{ opacity: 0, scale: 0.8 }}
 animate={{ opacity: 1, scale: 1 }}
 exit={{ opacity: 0, scale: 1.1, filter: "blur(10px)" }}
 transition={{ duration: 0.8 }}
 className="flex flex-col items-center"
 >
 <div className="relative w-32 h-32 mb-8">
 <motion.div 
 className="absolute inset-0 border-2 border-violet-500/30 rounded-full"
 animate={{ scale: [1, 1.2, 1], opacity: [0.5, 0, 0.5] }}
 transition={{ duration: 2, repeat: Infinity }}
 />
 <div className="absolute inset-0 flex items-center justify-center bg-violet-500/10 rounded-full backdrop-blur-sm border border-violet-500/20 shadow-[0_0_50px_rgba(139,92,246,0.3)]">
 {step === 0 ? (
 <motion.div
 animate={{ opacity: [0.3, 1, 0.3] }}
 transition={{ duration: 1.5, repeat: Infinity }}
 >
 <Fingerprint className="w-12 h-12 text-violet-400" />
 </motion.div>
 ) : (
 <motion.div
 initial={{ scale: 0 }}
 animate={{ scale: 1 }}
 transition={{ type: "spring", bounce: 0.6 }}
 >
 <CheckCircle2 className="w-12 h-12 text-emerald-400" />
 </motion.div>
 )}
 </div>
 
 {/* Scanner line */}
 {step === 0 && (
 <motion.div 
 className="absolute left-0 right-0 h-0.5 bg-violet-400 shadow-[0_0_15px_rgba(167,139,250,1)] z-20"
 animate={{ top: ["0%", "100%", "0%"] }}
 transition={{ duration: 2, ease: "linear", repeat: Infinity }}
 />
 )}
 </div>
 
 <h2 className="text-2xl font-mono text-white tracking-[0.2em] uppercase">
 {step === 0 ? "Authenticating Bio-Signature" : "Identity Verified"}
 </h2>
 <div className="mt-6 flex space-x-2">
 {[...Array(3)].map((_, i) => (
 <motion.div
 key={i}
 className="w-1.5 h-1.5 bg-violet-500 rounded-full"
 animate={{ opacity: [0.2, 1, 0.2] }}
 transition={{ duration: 1, repeat: Infinity, delay: i * 0.2 }}
 />
 ))}
 </div>
 </motion.div>
 )}

 {/* Step 2: System Initialization */}
 {step === 2 && (
 <motion.div 
 key="init"
 initial={{ opacity: 0, y: 20 }}
 animate={{ opacity: 1, y: 0 }}
 exit={{ opacity: 0, y: -20, filter: "blur(10px)" }}
 transition={{ duration: 0.8 }}
 className="flex flex-col items-center"
 >
 <div className="flex items-center space-x-3 mb-6">
 <motion.div
 animate={{ rotate: 360 }}
 transition={{ duration: 4, ease: "linear", repeat: Infinity }}
 >
 <Sparkles className="w-10 h-10 text-blue-400" />
 </motion.div>
 </div>
 <h2 className="text-3xl font-bold text-white mb-4">Initializing Neural Link</h2>
 <div className="w-64 h-1 bg-white/10 rounded-full overflow-hidden">
 <motion.div 
 className="h-full bg-gradient-to-r from-blue-500 to-violet-500"
 initial={{ width: "0%" }}
 animate={{ width: "100%" }}
 transition={{ duration: 2, ease: "easeInOut" }}
 />
 </div>
 <div className="mt-4 font-mono text-xs text-white/40 flex flex-col items-center space-y-1">
 <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0 }}>&gt; Booting Jarvis AI Core...</motion.p>
 <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }}>&gt; Syncing external workspaces...</motion.p>
 <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.0 }}>&gt; Establishing secure connection...</motion.p>
 </div>
 </motion.div>
 )}

 {/* Step 3: Welcome */}
 {step === 3 && (
 <motion.div 
 key="welcome"
 initial={{ opacity: 0, scale: 0.9 }}
 animate={{ opacity: 1, scale: 1 }}
 exit={{ opacity: 0, scale: 1.2, filter: "blur(20px)" }}
 transition={{ duration: 1 }}
 className="flex flex-col items-center text-center"
 >
 <motion.h1 
 className="text-6xl font-black text-transparent bg-clip-text bg-gradient-to-br from-white via-white to-white/20 mb-4 tracking-tight"
 initial={{ y: 20 }}
 animate={{ y: 0 }}
 >
 Welcome to LIFE OS
 </motion.h1>
 <motion.p 
 className="text-xl text-white/50"
 initial={{ y: 20, opacity: 0 }}
 animate={{ y: 0, opacity: 1 }}
 transition={{ delay: 0.3 }}
 >
 Your professional intelligence command center is ready.
 </motion.p>
 </motion.div>
 )}
 </AnimatePresence>
 </div>
 </motion.div>
 </AnimatePresence>
 );
}
