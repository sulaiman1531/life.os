"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";

export default function CustomCursor() {
 const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
 const [isHovering, setIsHovering] = useState(false);

 useEffect(() => {
 const updateMousePosition = (e: MouseEvent) => {
 setMousePosition({ x: e.clientX, y: e.clientY });
 
 // Check if hovering over a clickable element
 const target = e.target as HTMLElement;
 if (
 window.getComputedStyle(target).cursor === "pointer" ||
 target.tagName.toLowerCase() === "button" ||
 target.tagName.toLowerCase() === "a" ||
 target.closest("button") ||
 target.closest("a")
 ) {
 setIsHovering(true);
 } else {
 setIsHovering(false);
 }
 };

 window.addEventListener("mousemove", updateMousePosition);

 return () => {
 window.removeEventListener("mousemove", updateMousePosition);
 };
 }, []);

 return (
 <>
 <motion.div
 className="fixed top-0 left-0 w-4 h-4 bg-violet-500 rounded-full pointer-events-none z-[9999] mix-blend-screen"
 animate={{
 x: mousePosition.x - 8,
 y: mousePosition.y - 8,
 scale: isHovering ? 2 : 1,
 backgroundColor: isHovering ? "rgba(167, 139, 250, 0.4)" : "rgba(139, 92, 246, 1)"
 }}
 transition={{
 type: "spring",
 stiffness: 1000,
 damping: 28,
 mass: 0.1
 }}
 />
 <motion.div
 className="fixed top-0 left-0 w-8 h-8 border border-violet-500/50 rounded-full pointer-events-none z-[9998]"
 animate={{
 x: mousePosition.x - 16,
 y: mousePosition.y - 16,
 scale: isHovering ? 1.5 : 1,
 opacity: isHovering ? 0 : 1
 }}
 transition={{
 type: "spring",
 stiffness: 150,
 damping: 15,
 mass: 0.8
 }}
 />
 </>
 );
}
