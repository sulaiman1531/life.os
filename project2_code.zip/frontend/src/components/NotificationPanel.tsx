"use client";

import { useEffect, useState } from "react";
import { Zap, Bell, CheckCircle } from "lucide-react";
import { fetchApi } from "@/lib/api";

type Notification = {
 id: string;
 type: string;
 title: string;
 message: string;
 icon: string;
 timestamp: string;
};

export default function NotificationPanel() {
 const [notifications, setNotifications] = useState<Notification[]>([]);

 const playSound = () => {
 try {
 const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
 const oscillator = audioCtx.createOscillator();
 const gainNode = audioCtx.createGain();
 
 oscillator.type = "sine";
 oscillator.frequency.setValueAtTime(880, audioCtx.currentTime); // A5
 oscillator.frequency.exponentialRampToValueAtTime(1760, audioCtx.currentTime + 0.1); // A6
 
 gainNode.gain.setValueAtTime(0, audioCtx.currentTime);
 gainNode.gain.linearRampToValueAtTime(0.1, audioCtx.currentTime + 0.05);
 gainNode.gain.linearRampToValueAtTime(0, audioCtx.currentTime + 0.3);
 
 oscillator.connect(gainNode);
 gainNode.connect(audioCtx.destination);
 
 oscillator.start();
 oscillator.stop(audioCtx.currentTime + 0.3);
 } catch (e) {
 console.warn("Audio not supported or blocked");
 }
 };

 useEffect(() => {
 // Try to get token. If it doesn't exist yet, we wait.
 const token = localStorage.getItem("token");
 if (!token) return;

 // Request browser notification permissions
 if ("Notification" in window && Notification.permission === "default") {
 Notification.requestPermission();
 }

 // Decode JWT payload to get user ID
 let userId = "default";
 try {
 const payload = JSON.parse(atob(token.split(".")[1]));
 userId = payload.sub; // assuming 'sub' is user id
 } catch (e) {
 console.error("Could not parse token");
 }

 const ws = new WebSocket(`ws://127.0.0.1:8000/ws/${userId}`);

 ws.onmessage = (event) => {
 try {
 const data = JSON.parse(event.data);
 setNotifications((prev) => [data, ...prev]);
 
 playSound();

 if ("Notification" in window && Notification.permission === "granted") {
 new Notification(data.title, { body: data.message, icon: "/favicon.ico" });
 }
 
 // Auto remove after 5 seconds
 setTimeout(() => {
 setNotifications((prev) => prev.filter(n => n.id !== data.id));
 }, 5000);
 } catch (e) {
 console.error(e);
 }
 };

 return () => {
 ws.close();
 };
 }, []);

 if (notifications.length === 0) return null;

 return (
 <div className="fixed bottom-6 right-6 z-50 flex flex-col space-y-3 pointer-events-none">
 {notifications.map((notif) => (
 <div 
 key={notif.id}
 className="pointer-events-auto w-80 glass-card bg-surface/90 border border-white/10 p-4 flex items-start space-x-3 shadow-2xl animate-in slide-in-from-right-8 fade-in duration-300"
 >
 <div className="p-2 bg-violet-500/20 text-violet-400 rounded-lg flex-shrink-0">
 {notif.icon === "zap" ? <Zap className="w-5 h-5" /> : <Bell className="w-5 h-5" />}
 </div>
 <div>
 <h4 className="text-sm font-semibold text-white">{notif.title}</h4>
 <p className="text-xs text-white/60 mt-1">{notif.message}</p>
 </div>
 </div>
 ))}
 </div>
 );
}
