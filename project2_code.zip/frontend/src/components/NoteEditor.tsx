"use client";

import { useState, useEffect } from "react";
import { Clock, Share2, MoreHorizontal, Edit3, Eye, CheckCircle2 } from "lucide-react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { fetchApi } from "@/lib/api";

export default function NoteEditor({ note }: { note: any }) {
 const queryClient = useQueryClient();
 const [isEditing, setIsEditing] = useState(false);
 const [title, setTitle] = useState(note.title);
 const [content, setContent] = useState(note.content || "");
 const [isSaved, setIsSaved] = useState(true);

 // Sync state if a different note is selected
 useEffect(() => {
 setTitle(note.title);
 setContent(note.content || "");
 setIsSaved(true);
 }, [note]);

 const updateNote = useMutation({
 mutationFn: (updated: any) => fetchApi(`/notes/${note.id}`, {
 method: "PUT",
 body: JSON.stringify(updated)
 }),
 onSuccess: () => {
 queryClient.invalidateQueries({ queryKey: ["notes"] });
 setIsSaved(true);
 }
 });

 // Debounced auto-save effect could go here, or we can just save on blur
 const handleSave = () => {
 if (title !== note.title || content !== note.content) {
 updateNote.mutate({ title, content });
 }
 };
 return (
 <div className="flex flex-col h-full animate-in fade-in slide-in-from-bottom-4 duration-500 max-w-3xl">
 {/* Top Bar */}
 <div className="flex items-center justify-between mb-8 text-white/40 text-xs font-medium uppercase tracking-wider">
 <div className="flex items-center space-x-4">
 <span className="flex items-center"><Clock className="w-3.5 h-3.5 mr-1" /> Last edited 2m ago</span>
 <span>By Malak</span>
 </div>
 <div className="flex items-center space-x-2">
 {isSaved ? (
 <span className="flex items-center text-emerald-400 mr-2"><CheckCircle2 className="w-3.5 h-3.5 mr-1" /> Saved</span>
 ) : (
 <span className="flex items-center text-amber-400 mr-2">Unsaved changes</span>
 )}
 
 <button 
 onClick={() => {
 if (isEditing) handleSave();
 setIsEditing(!isEditing);
 }} 
 className="flex items-center px-3 py-1.5 bg-white/5 hover:bg-white/10 rounded-lg transition-colors border border-white/10 text-white"
 >
 {isEditing ? <><Eye className="w-4 h-4 mr-2" /> Preview</> : <><Edit3 className="w-4 h-4 mr-2" /> Edit</>}
 </button>
 <button className="p-1.5 hover:bg-white/10 rounded transition-colors"><Share2 className="w-4 h-4" /></button>
 <button className="p-1.5 hover:bg-white/10 rounded transition-colors"><MoreHorizontal className="w-4 h-4" /></button>
 </div>
 </div>

 {/* Title */}
 {isEditing ? (
 <input
 value={title}
 onChange={(e) => {
 setTitle(e.target.value);
 setIsSaved(false);
 }}
 onBlur={handleSave}
 className="text-4xl font-bold tracking-tight text-white mb-6 outline-none bg-transparent w-full"
 placeholder="Note Title..."
 />
 ) : (
 <h1 className="text-4xl font-bold tracking-tight text-white mb-6 bg-transparent">
 {title || "Untitled Note"}
 </h1>
 )}

 {/* Editor Content */}
 <div className="flex-1 overflow-y-auto pb-20 scrollbar-none">
 {isEditing ? (
 <textarea 
 value={content}
 onChange={(e) => {
 setContent(e.target.value);
 setIsSaved(false);
 }}
 onBlur={handleSave}
 placeholder="Write using markdown..."
 className="w-full h-full min-h-[500px] text-lg text-white/80 leading-relaxed outline-none bg-transparent resize-none font-mono"
 />
 ) : (
 <div className="prose prose-invert prose-violet max-w-none text-lg text-white/80 leading-relaxed">
 {content ? (
 <ReactMarkdown remarkPlugins={[remarkGfm]}>
 {content}
 </ReactMarkdown>
 ) : (
 <p className="text-white/30 italic">Nothing written yet. Click 'Edit' to start writing.</p>
 )}
 </div>
 )}
 </div>
 </div>
 );
}
