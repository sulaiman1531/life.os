"use client";

import { useMemo } from "react";
import { motion } from "framer-motion";
import { TrendingUp } from "lucide-react";

export default function ActivityHeatmap({ tasks }: { tasks: any[] }) {
 // Generate last 60 days of data for the heatmap
 const heatmapData = useMemo(() => {
 const data = [];
 const today = new Date();
 
 // Count real completions today
 const completedToday = tasks.filter(t => t.status === "done").length;

 for (let i = 59; i >= 0; i--) {
 const d = new Date(today);
 d.setDate(today.getDate() - i);
 
 let count = 0;
 if (i === 0) {
 count = completedToday;
 } else {
 // Mock historical data for visual effect
 count = Math.random() > 0.3 ? Math.floor(Math.random() * 5) : 0;
 }
 
 data.push({
 date: d.toLocaleDateString(),
 count: count
 });
 }
 return data;
 }, [tasks]);

 const getColor = (count: number) => {
 if (count === 0) return "bg-white/5";
 if (count <= 1) return "bg-emerald-500/20";
 if (count <= 3) return "bg-emerald-500/40";
 if (count <= 5) return "bg-emerald-500/70";
 return "bg-emerald-500";
 };

 return (
 <div className="glass-card p-6 border border-white/10 relative overflow-hidden group hover:border-emerald-500/30 transition-colors">
 <div className="absolute top-0 right-0 -mr-8 -mt-8 w-32 h-32 bg-emerald-500/10 rounded-full blur-2xl group-hover:bg-emerald-500/20 transition-all"></div>
 
 <div className="flex items-center justify-between mb-4 relative z-10">
 <div className="flex items-center space-x-3 text-emerald-400">
 <TrendingUp className="w-5 h-5" />
 <h3 className="font-semibold text-sm">Activity Map</h3>
 </div>
 <span className="text-xs text-white/40 font-mono">Last 60 Days</span>
 </div>

 <div className="flex flex-col relative z-10">
 <div className="flex flex-wrap gap-1.5 justify-end">
 {heatmapData.map((day, i) => (
 <motion.div
 key={i}
 initial={{ opacity: 0, scale: 0 }}
 animate={{ opacity: 1, scale: 1 }}
 transition={{ delay: i * 0.01 }}
 className={`w-3 h-3 rounded-sm ${getColor(day.count)} cursor-help transition-colors hover:ring-2 ring-emerald-400/50 ring-offset-1 ring-offset-[#0A0A0A]`}
 title={`${day.count} tasks on ${day.date}`}
 />
 ))}
 </div>
 <div className="flex justify-between items-center mt-3 text-[10px] text-white/30 uppercase tracking-widest font-bold">
 <span>Less</span>
 <div className="flex space-x-1.5">
 <div className="w-2.5 h-2.5 rounded-sm bg-white/5"></div>
 <div className="w-2.5 h-2.5 rounded-sm bg-emerald-500/20"></div>
 <div className="w-2.5 h-2.5 rounded-sm bg-emerald-500/40"></div>
 <div className="w-2.5 h-2.5 rounded-sm bg-emerald-500/70"></div>
 <div className="w-2.5 h-2.5 rounded-sm bg-emerald-500"></div>
 </div>
 <span>More</span>
 </div>
 </div>
 </div>
 );
}
