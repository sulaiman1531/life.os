import { create } from 'zustand';

interface User {
 id: string;
 email: string;
 full_name?: string;
}

interface AppState {
 user: User | null;
 setUser: (user: User | null) => void;
 isSidebarOpen: boolean;
 toggleSidebar: () => void;
}

export const useStore = create<AppState>((set) => ({
 user: null,
 setUser: (user) => set({ user }),
 isSidebarOpen: true,
 toggleSidebar: () => set((state) => ({ isSidebarOpen: !state.isSidebarOpen })),
}));
